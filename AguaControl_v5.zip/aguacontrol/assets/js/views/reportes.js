// Reportes de ventas y compras (admin y contabilidad) con exportación a Excel.
import { api, apiUrl } from '../api.js';
import { $, esc, money, num, pct, fmtDate, monthStart, today, isoDate, debounce, downloadFile, zoneColor, icon } from '../utils.js';
import { kpi, tableHtml, columnChart, barList, toast } from '../ui.js';

const TABS = [['resumen', 'Resumen'], ['vendedores', 'Por vendedor'], ['detalle', 'Detalle de ventas'], ['compras', 'Compras']];

export default async function ({ el, state }) {
  const cat = state.cat;
  const opts = (items, label) => items.map((i) => `<option value="${i.id}">${esc(label(i))}</option>`).join('');
  el.innerHTML = `
    <div class="page-head">
      <div><h2>Reportes de ventas</h2><p>Elige el periodo y, si quieres, una zona o un vendedor. El Excel incluye todas las hojas con los mismos filtros.</p></div>
      <button class="btn btn-primary" id="btnExcel">${icon('download')}Exportar a Excel</button>
    </div>
    <section class="card" style="margin-bottom:16px">
      <form class="toolbar" id="filters" style="margin:0">
        <label class="field"><span>Desde</span><input type="date" name="desde" value="${monthStart()}" max="${today()}"></label>
        <label class="field"><span>Hasta</span><input type="date" name="hasta" value="${today()}" max="${today()}"></label>
        <label class="field"><span>Zona</span><select name="zona_id"><option value="">Todas</option>${opts(cat.zonas, (z) => z.nombre)}</select></label>
        <label class="field"><span>Vendedor</span><select name="vendedor_id"><option value="">Todos</option>${opts(cat.vendedores || [], (v) => `${v.nombre} (${v.codigo})`)}</select></label>
        <div class="spacer"></div>
        <div class="segmented" role="group" aria-label="Periodo rápido">
          <label><input type="radio" name="rango" value="hoy"><span>Hoy</span></label>
          <label><input type="radio" name="rango" value="7"><span>7 días</span></label>
          <label><input type="radio" name="rango" value="mes" checked><span>Este mes</span></label>
          <label><input type="radio" name="rango" value="anterior"><span>Mes anterior</span></label>
        </div>
      </form>
    </section>
    <div class="segmented tabs" role="tablist" id="tabs" style="margin-bottom:16px">${TABS.map(([k, l], i) => `<label><input type="radio" name="tab" value="${k}" ${i === 0 ? 'checked' : ''}><span>${l}</span></label>`).join('')}</div>
    <div id="body"><div class="skeleton"></div></div>`;

  const form = $('#filters', el);
  let data = null;
  const query = () => { const q = Object.fromEntries(new FormData(form)); delete q.rango; return q; };

  form.addEventListener('change', (e) => {
    if (e.target.name !== 'rango') return;
    const d = new Date(), set = (a, b) => { form.elements.namedItem('desde').value = a; form.elements.namedItem('hasta').value = b; };
    if (e.target.value === 'hoy') set(today(), today());
    if (e.target.value === '7') set(isoDate(new Date(d.getFullYear(), d.getMonth(), d.getDate() - 6)), today());
    if (e.target.value === 'mes') set(monthStart(), today());
    if (e.target.value === 'anterior') set(isoDate(new Date(d.getFullYear(), d.getMonth() - 1, 1)), isoDate(new Date(d.getFullYear(), d.getMonth(), 0)));
  });

  function paint() {
    const tab = $('#tabs [name=tab]:checked', el).value, d = data, t = d.totales;
    const body = $('#body', el);
    const strip = `<div class="kpis" style="margin-bottom:16px">
      ${kpi('Ingresos', money(t.ingresos), `${num(t.ventas)} ventas, ${num(t.unidades)} unidades`)}
      ${kpi('Utilidad estimada', money(t.utilidad), `Margen de ${pct(t.margen)}`, t.utilidad < 0 ? 'danger' : 'ok')}
      ${kpi('Ticket promedio', money(t.ticket_promedio), 'Ingreso por venta')}
      ${kpi('Compras', money(d.compras.total), `${num(d.compras.num)} compras de insumos`)}
    </div>`;

    if (tab === 'resumen') {
      const zones = d.por_zona.map((z) => z.zona);
      body.innerHTML = strip + `
        <div class="grid-main" style="margin-bottom:16px">
          <section class="card"><div class="card-head"><div><h3>Ingresos por día</h3><p>Cada color es una zona</p></div></div>
            ${columnChart(d.diario.map((x) => ({ fecha: x.fecha, valores: x.por_zona })), zones, (k) => zoneColor(k))}</section>
          <section class="card"><div class="card-head"><div><h3>Por zona</h3><p>Participación en los ingresos</p></div></div>
            ${barList(d.por_zona, { label: 'zona', value: 'ingresos', color: (i) => zoneColor(i.zona) })}
            <div class="mini-list" style="margin-top:14px">${d.por_zona.map((z) => `<div class="mini-row"><span class="zone-tag" style="--zc:${zoneColor(z.zona)}">${esc(z.zona)}</span><span>${pct(z.participacion)}, ${num(z.ventas)} venta${z.ventas === 1 ? '' : 's'}, utilidad ${money(z.utilidad)}</span></div>`).join('')}</div></section>
        </div>
        <div class="grid-2">
          <section class="card"><div class="card-head"><div><h3>Por producto</h3></div></div>
            ${tableHtml({ label: 'Ventas por producto', rows: d.por_producto, columns: [
              { key: 'producto', label: 'Producto', render: (r) => `<b>${esc(r.producto)}</b>` },
              { key: 'unidades', label: 'Unidades', num: true, render: (r) => num(r.unidades) },
              { key: 'precio_promedio', label: 'Precio prom.', num: true, render: (r) => money(r.precio_promedio) },
              { key: 'ingresos', label: 'Ingresos', num: true, render: (r) => money(r.ingresos) },
              { key: 'utilidad', label: 'Utilidad', num: true, render: (r) => `<span style="color:${r.utilidad < 0 ? 'var(--error)' : 'inherit'}">${money(r.utilidad)}</span>` },
            ] })}</section>
          <section class="card"><div class="card-head"><div><h3>Mejores clientes</h3><p>Los 20 con más compras</p></div></div>
            ${d.clientes.length ? `<div class="mini-list">${d.clientes.map((c) => `<div class="mini-row"><span><b>${esc(c.cliente)}</b><br><span class="muted" style="font-size:12.5px">${esc(c.vendedores)}, ${num(c.ventas)} compra${c.ventas === 1 ? '' : 's'}, última el ${fmtDate(c.ultima)}</span></span><b>${money(c.ingresos)}</b></div>`).join('')}</div>` : '<div class="empty">Las ventas no tienen cliente registrado.</div>'}</section>
        </div>`;
    }

    if (tab === 'vendedores') {
      body.innerHTML = strip + `<section class="card"><div class="card-head"><div><h3>Rendimiento por vendedor</h3><p>Costo y utilidad calculados con los costos configurados</p></div></div>
        ${tableHtml({ label: 'Ventas por vendedor', rows: d.por_vendedor, columns: [
          { key: 'vendedor', label: 'Vendedor', render: (r) => `<b>${esc(r.vendedor)}</b>${r.codigo ? ` <span class="muted">${esc(r.codigo)}</span>` : ''}` },
          { key: 'zona', label: 'Zona', render: (r) => `<span class="zone-tag" style="--zc:${zoneColor(r.zona)}">${esc(r.zona)}</span>` },
          { key: 'camiones', label: 'Camión', render: (r) => esc(r.camiones || '—') },
          { key: 'ventas', label: 'Ventas', num: true },
          { key: 'unidades', label: 'Unidades', num: true, render: (r) => num(r.unidades) },
          { key: 'ingresos', label: 'Ingresos', num: true, render: (r) => `<b>${money(r.ingresos)}</b>` },
          { key: 'participacion', label: 'Del total', num: true, render: (r) => pct(r.participacion) },
          { key: 'ticket_promedio', label: 'Ticket', num: true, render: (r) => money(r.ticket_promedio) },
          { key: 'clientes', label: 'Clientes', num: true },
          { key: 'dias_activos', label: 'Días', num: true },
          { key: 'combustible', label: 'Combustible', num: true, render: (r) => money(r.combustible) },
          { key: 'utilidad', label: 'Utilidad', num: true, render: (r) => `<span style="color:${r.utilidad < 0 ? 'var(--error)' : 'var(--ok)'}">${money(r.utilidad)}</span>` },
          { key: 'margen', label: 'Margen', num: true, render: (r) => pct(r.margen) },
          { key: 'ultima', label: 'Última venta', render: (r) => fmtDate(r.ultima) },
        ], foot: d.por_vendedor.length ? { ventas: num(t.ventas), unidades: num(t.unidades), ingresos: `<b>${money(t.ingresos)}</b>`, combustible: money(t.combustible), utilidad: money(t.utilidad) } : null })}</section>`;
    }

    if (tab === 'detalle') {
      body.innerHTML = strip + `<section class="card"><div class="card-head"><div><h3>Detalle de cada venta</h3><p>${num(d.total_registros)} ventas${d.total_registros > d.detalle.length ? `; aquí se ven las ${d.detalle.length} más recientes y el Excel trae todas` : ''}</p></div></div>
        ${tableHtml({ label: 'Detalle de ventas', rows: d.detalle, columns: [
          { key: 'fecha', label: 'Fecha', render: (r) => fmtDate(r.fecha) },
          { key: 'creado_en', label: 'Hora', render: (r) => esc((r.creado_en || '').slice(11, 16)) },
          { key: 'zona', label: 'Zona', render: (r) => `<span class="zone-tag" style="--zc:${zoneColor(r.zona)}">${esc(r.zona)}</span>` },
          { key: 'vendedor', label: 'Vendedor', render: (r) => `<b>${esc(r.vendedor)}</b>` },
          { key: 'camion', label: 'Camión', render: (r) => esc(r.camion || 'Planta') },
          { key: 'cliente', label: 'Cliente' },
          { key: 'producto', label: 'Producto' },
          { key: 'cantidad', label: 'Cant.', num: true, render: (r) => num(r.cantidad) },
          { key: 'precio_unitario', label: 'Precio', num: true, render: (r) => money(r.precio_unitario) },
          { key: 'total', label: 'Total', num: true, render: (r) => `<b>${money(r.total)}</b>` },
          { key: 'combustible', label: 'Combustible', num: true, render: (r) => money(r.combustible) },
          { key: 'utilidad', label: 'Utilidad', num: true, render: (r) => `<span style="color:${r.utilidad < 0 ? 'var(--error)' : 'inherit'}">${money(r.utilidad)}</span>` },
          { key: 'registrado_por', label: 'Registró' },
        ] })}</section>`;
    }

    if (tab === 'compras') {
      const k = d.compras;
      body.innerHTML = strip + `<div class="grid-main">
        <section class="card"><div class="card-head"><div><h3>Detalle de compras</h3><p>${num(k.num)} compras en el periodo</p></div></div>
          ${tableHtml({ label: 'Compras', rows: k.detalle, empty: 'No hay compras en el periodo.', columns: [
            { key: 'fecha', label: 'Fecha', render: (r) => fmtDate(r.fecha) },
            { key: 'proveedor', label: 'Proveedor', render: (r) => esc(r.proveedor || '—') },
            { key: 'tipo', label: 'Insumo' },
            { key: 'cantidad', label: 'Cantidad', num: true, render: (r) => num(r.cantidad) },
            { key: 'costo_unitario', label: 'Costo unit.', num: true, render: (r) => money(r.costo_unitario) },
            { key: 'total', label: 'Total', num: true, render: (r) => `<b>${money(r.total)}</b>` },
            { key: 'registrado_por', label: 'Registró' },
          ], foot: k.detalle.length ? { total: `<b>${money(k.total)}</b>` } : null })}</section>
        <section class="card"><div class="card-head"><div><h3>Por insumo</h3></div></div>
          ${barList(k.por_tipo, { label: 'tipo', value: 'total', color: () => 'var(--gris)' })}</section>
      </div>`;
    }
  }

  async function load() {
    const q = query();
    if (q.desde > q.hasta) { $('#body', el).innerHTML = '<div class="notice warn">La fecha inicial es posterior a la final.</div>'; return; }
    data = await api('reportes', { query: q });
    paint();
  }

  $('#btnExcel', el).addEventListener('click', async (e) => {
    const b = e.currentTarget, label = b.innerHTML;
    b.disabled = true; b.textContent = 'Preparando Excel…';
    try { await downloadFile(apiUrl('reportes/excel', Object.fromEntries(Object.entries(query()).filter(([, v]) => v))), 'reporte.xlsx'); toast('Excel descargado.'); }
    catch (err) { toast(err.message, 'error'); }
    finally { b.disabled = false; b.innerHTML = label; }
  });
  $('#tabs', el).addEventListener('change', () => data && paint());
  const reload = debounce(() => load().catch((e) => toast(e.message, 'error')));
  form.addEventListener('input', reload);
  form.addEventListener('change', reload);
  await load();
}
