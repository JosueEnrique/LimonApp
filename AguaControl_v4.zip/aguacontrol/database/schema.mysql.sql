-- AguaControl · esquema MySQL / MariaDB v3 (XAMPP)
-- 1) phpMyAdmin → pestaña SQL → pega y ejecuta este archivo.
-- 2) En config/config.php cambia 'driver' => 'mysql'.
-- 3) Ejecuta una vez:  php database/install.php   (crea zonas, productos, camiones, vendedores, costos y usuarios)

CREATE DATABASE IF NOT EXISTS aguacontrol CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE aguacontrol;

CREATE TABLE meta (
  clave VARCHAR(40) PRIMARY KEY,
  valor VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE zonas (
  id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre    VARCHAR(60) NOT NULL UNIQUE,
  activo    TINYINT(1)  NOT NULL DEFAULT 1,
  creado_en DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE camiones (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo      VARCHAR(20)  NOT NULL UNIQUE,
  placa       VARCHAR(20)  NOT NULL DEFAULT '',
  descripcion VARCHAR(120) NOT NULL DEFAULT '',
  activo      TINYINT(1)   NOT NULL DEFAULT 1,
  creado_en   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE usuarios (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(32)  NOT NULL UNIQUE,
  nombre        VARCHAR(60)  NOT NULL,
  rol           ENUM('admin','contabilidad','despacho','supervisor') NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  zona_id       INT UNSIGNED NULL,
  activo        TINYINT(1)   NOT NULL DEFAULT 1,
  ultimo_acceso DATETIME     NULL,
  creado_en     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (zona_id) REFERENCES zonas(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE vendedores (
  id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo    VARCHAR(20)  NOT NULL UNIQUE,
  nombre    VARCHAR(60)  NOT NULL,
  telefono  VARCHAR(20)  NOT NULL DEFAULT '',
  zona_id   INT UNSIGNED NOT NULL,
  camion_id INT UNSIGNED NULL,
  activo    TINYINT(1)   NOT NULL DEFAULT 1,
  creado_en DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (zona_id),
  FOREIGN KEY (zona_id)   REFERENCES zonas(id),
  FOREIGN KEY (camion_id) REFERENCES camiones(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE productos (
  id     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(60) NOT NULL UNIQUE,
  clave  VARCHAR(30) NOT NULL UNIQUE,
  litros DECIMAL(10,3) NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE entradas (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fecha          DATE          NOT NULL,
  proveedor      VARCHAR(80)   NOT NULL DEFAULT '',
  tipo           VARCHAR(40)   NOT NULL,
  cantidad       DECIMAL(14,3) NOT NULL,
  costo_unitario DECIMAL(14,4) NOT NULL,
  total          DECIMAL(14,2) NOT NULL,
  notas          VARCHAR(500)  NOT NULL DEFAULT '',
  usuario_id     INT UNSIGNED  NULL,
  creado_en      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (fecha),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE produccion (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fecha       DATE          NOT NULL,
  turno       ENUM('Mañana','Tarde','Noche') NOT NULL,
  producto_id INT UNSIGNED  NOT NULL,
  cantidad    DECIMAL(14,3) NOT NULL,
  desperdicio DECIMAL(14,3) NOT NULL DEFAULT 0,
  lote        VARCHAR(40)   NOT NULL DEFAULT '',
  notas       VARCHAR(500)  NOT NULL DEFAULT '',
  usuario_id  INT UNSIGNED  NULL,
  creado_en   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (fecha, turno),
  FOREIGN KEY (producto_id) REFERENCES productos(id),
  FOREIGN KEY (usuario_id)  REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE cargas (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fecha       DATE          NOT NULL,
  vendedor_id INT UNSIGNED  NULL,
  camion_id   INT UNSIGNED  NOT NULL,
  producto_id INT UNSIGNED  NOT NULL,
  cantidad    DECIMAL(14,3) NOT NULL,
  notas       VARCHAR(500)  NOT NULL DEFAULT '',
  usuario_id  INT UNSIGNED  NULL,
  creado_en   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (camion_id, fecha),
  INDEX (vendedor_id, fecha),
  FOREIGN KEY (vendedor_id) REFERENCES vendedores(id),
  FOREIGN KEY (camion_id)   REFERENCES camiones(id),
  FOREIGN KEY (producto_id) REFERENCES productos(id),
  FOREIGN KEY (usuario_id)  REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE ventas (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fecha           DATE          NOT NULL,
  cliente         VARCHAR(80)   NOT NULL DEFAULT '',
  producto_id     INT UNSIGNED  NOT NULL,
  cantidad        DECIMAL(14,3) NOT NULL,
  precio_unitario DECIMAL(14,4) NOT NULL,
  total           DECIMAL(14,2) NOT NULL,
  combustible     DECIMAL(14,2) NOT NULL DEFAULT 0,
  camion_id       INT UNSIGNED  NULL,
  vendedor_id     INT UNSIGNED  NULL,
  usuario_id      INT UNSIGNED  NULL,
  notas           VARCHAR(500)  NOT NULL DEFAULT '',
  creado_en       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (fecha),
  INDEX (vendedor_id, fecha),
  FOREIGN KEY (producto_id) REFERENCES productos(id),
  FOREIGN KEY (camion_id)   REFERENCES camiones(id),
  FOREIGN KEY (vendedor_id) REFERENCES vendedores(id),
  FOREIGN KEY (usuario_id)  REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE costos (
  clave VARCHAR(30) PRIMARY KEY,
  valor DECIMAL(14,4) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE login_intentos (
  id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username  VARCHAR(64) NOT NULL,
  ip        VARCHAR(45) NOT NULL,
  creado_en DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (username, creado_en)
) ENGINE=InnoDB;
