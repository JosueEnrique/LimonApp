<?php
declare(strict_types=1);

/**
 * Datos iniciales. Las contraseñas se guardan solo como hash bcrypt;
 * las contraseñas en texto se entregaron aparte al administrador.
 */
function seed_database(PDO $pdo): void
{
    $pdo->beginTransaction();
    $now = now_local();

    $st = $pdo->prepare('INSERT INTO zonas (nombre, creado_en) VALUES (?, ?)');
    foreach (DEFAULT_ZONES as $z) $st->execute([$z, $now]);

    $productos = [
        // nombre,               clave,      litros
        ['Botella 600 ml',      'b600',     0.6],
        ['Botella 1 L',         'b1l',      1],
        ['Fardo 25 unidades',   'fardo',    15],
        ['Galón',               'galon',    3.785],
        ['Garrafón',            'garrafon', 20],
    ];
    $st = $pdo->prepare('INSERT INTO productos (nombre, clave, litros) VALUES (?, ?, ?)');
    foreach ($productos as $p) $st->execute($p);

    $camiones = [
        ['CAM-01', '', 'Ruta Planta'],
        ['CAM-02', '', 'Ruta Planta'],
        ['CAM-03', '', 'Camión de reserva'],
        ['CAM-04', '', 'Ruta San Miguel (Luis)'],
        ['CAM-05', '', 'Ruta San Miguel (Julio)'],
    ];
    $st = $pdo->prepare('INSERT INTO camiones (codigo, placa, descripcion, creado_en) VALUES (?, ?, ?, ?)');
    foreach ($camiones as $c) $st->execute([...$c, $now]);

    // Vendedores de ruta (no entran al sistema): código, nombre, zona, camión
    $vendedores = [
        ['V-01', 'Juan',  'Planta',     'CAM-01'],
        ['V-02', 'Pedro', 'Planta',     'CAM-02'],
        ['V-03', 'Luis',  'San Miguel', 'CAM-04'],
        ['V-04', 'Julio', 'San Miguel', 'CAM-05'],
    ];
    $st = $pdo->prepare('INSERT INTO vendedores (codigo, nombre, zona_id, camion_id, creado_en)
                         VALUES (?, ?, (SELECT id FROM zonas WHERE nombre = ?), (SELECT id FROM camiones WHERE codigo = ?), ?)');
    foreach ($vendedores as $v) $st->execute([...$v, $now]);

    $usuarios = [
        // usuario, nombre, rol, hash, zona (solo despacho)
        ['admin', 'Administrador', 'admin', '$2y$10$4VgZsAEgNNXhvdpr6B/Lbuu59pwwGII/jCHU2XtKTsAAzck.mdrC6', null],
        ['contabilidad', 'Contabilidad', 'contabilidad', '$2y$10$vN7s6cnksk6K0HLCdqy/E.lS4fKltlaSr0u7.qTyueaf2A0IRPphS', null],
        ['despacho1', 'Walner Sosa', 'despacho', '$2y$10$VtASkB9QnOpywikZgd4Msezr.ox8KeOK9A7C6Rnn5XUlHOU46E/a.', 'Planta'],
        ['despacho2', 'Ezequiel', 'despacho', '$2y$10$2MO9zx4gcF3YdbTFnHKcq.7W1.gZbmu/snSCcZrRUCRVQQB6xfEk.', 'San Miguel'],
        ['salvador', 'Salvador', 'supervisor', '$2y$10$nRVYEn68If3B0xvG0Yk3eeWE0TpljZXkU.xXnjwZXWXNN9eewG.aW', null],
    ];
    $st = $pdo->prepare('INSERT INTO usuarios (username, nombre, rol, password_hash, zona_id, creado_en)
                         VALUES (?, ?, ?, ?, (SELECT id FROM zonas WHERE nombre = ?), ?)');
    foreach ($usuarios as $u) $st->execute([...$u, $now]);

    $st = $pdo->prepare('INSERT INTO costos (clave, valor) VALUES (?, ?)');
    foreach (DEFAULT_COSTS as $k => $v) $st->execute([$k, $v]);

    $pdo->prepare('INSERT INTO meta (clave, valor) VALUES (?, ?)')->execute(['schema_version', (string) SCHEMA_VERSION]);
    $pdo->prepare('INSERT INTO meta (clave, valor) VALUES (?, ?)')->execute(['patch_planta_sanmiguel_2026_10', $now]); // ya incluido arriba
    $pdo->prepare('INSERT INTO meta (clave, valor) VALUES (?, ?)')->execute(['patch_un_supervisor_2026_10', $now]);
    $pdo->commit();
}
