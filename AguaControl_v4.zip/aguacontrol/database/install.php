<?php
/**
 * Instalador para MySQL (XAMPP). Uso, desde la carpeta del proyecto:
 *     php database/install.php
 * Requiere haber ejecutado antes database/schema.mysql.sql.
 * Con SQLite no hace falta: la base se crea sola al abrir el sistema.
 */
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Solo desde la línea de comandos.'); }

require __DIR__ . '/../src/bootstrap.php';
require __DIR__ . '/seed.php';

$pdo = Database::pdo();
if (Database::driver() === 'sqlite') { echo "SQLite listo en data/ (no hace falta instalar).\n"; exit; }
if ((int) Database::value('SELECT COUNT(*) FROM usuarios') > 0) { echo "La base ya tiene datos; no se modificó nada.\n"; exit; }

seed_database($pdo);
echo "Listo: productos, camiones, costos y usuarios iniciales creados.\n";
