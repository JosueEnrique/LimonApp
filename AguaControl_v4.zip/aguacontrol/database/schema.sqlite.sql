-- AguaControl · esquema SQLite v3 (se crea solo la primera vez que abres el sistema)

CREATE TABLE meta (
  clave TEXT PRIMARY KEY,
  valor TEXT NOT NULL
);

CREATE TABLE zonas (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre    TEXT NOT NULL UNIQUE,                 -- Planta, Morazán, San Miguel…
  activo    INTEGER NOT NULL DEFAULT 1,
  creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE camiones (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  codigo      TEXT NOT NULL UNIQUE,               -- ej. CAM-01
  placa       TEXT NOT NULL DEFAULT '',
  descripcion TEXT NOT NULL DEFAULT '',
  activo      INTEGER NOT NULL DEFAULT 1,
  creado_en   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Personas que entran al sistema.
CREATE TABLE usuarios (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
  nombre        TEXT NOT NULL,
  rol           TEXT NOT NULL CHECK (rol IN ('admin','contabilidad','despacho','supervisor')),
  password_hash TEXT NOT NULL,
  zona_id       INTEGER REFERENCES zonas(id) ON DELETE SET NULL,   -- obligatoria para despacho
  activo        INTEGER NOT NULL DEFAULT 1,
  ultimo_acceso TEXT,
  creado_en     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Vendedores de ruta: no entran al sistema; los registra el administrador.
CREATE TABLE vendedores (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  codigo    TEXT NOT NULL UNIQUE,                 -- ej. V-01
  nombre    TEXT NOT NULL,
  telefono  TEXT NOT NULL DEFAULT '',
  zona_id   INTEGER NOT NULL REFERENCES zonas(id),
  camion_id INTEGER REFERENCES camiones(id) ON DELETE SET NULL,
  activo    INTEGER NOT NULL DEFAULT 1,
  creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE productos (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre  TEXT NOT NULL UNIQUE,
  clave   TEXT NOT NULL UNIQUE,
  litros  REAL NOT NULL CHECK (litros > 0),
  activo  INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE entradas (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  fecha          TEXT NOT NULL,
  proveedor      TEXT NOT NULL DEFAULT '',
  tipo           TEXT NOT NULL,
  cantidad       REAL NOT NULL CHECK (cantidad > 0),
  costo_unitario REAL NOT NULL CHECK (costo_unitario >= 0),
  total          REAL NOT NULL,
  notas          TEXT NOT NULL DEFAULT '',
  usuario_id     INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  creado_en      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE produccion (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  fecha       TEXT NOT NULL,
  turno       TEXT NOT NULL CHECK (turno IN ('Mañana','Tarde','Noche')),
  producto_id INTEGER NOT NULL REFERENCES productos(id),
  cantidad    REAL NOT NULL CHECK (cantidad > 0),
  desperdicio REAL NOT NULL DEFAULT 0 CHECK (desperdicio >= 0),
  lote        TEXT NOT NULL DEFAULT '',
  notas       TEXT NOT NULL DEFAULT '',
  usuario_id  INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  creado_en   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE cargas (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  fecha       TEXT NOT NULL,
  vendedor_id INTEGER REFERENCES vendedores(id),   -- a quién se le cargó
  camion_id   INTEGER NOT NULL REFERENCES camiones(id),
  producto_id INTEGER NOT NULL REFERENCES productos(id),
  cantidad    REAL NOT NULL CHECK (cantidad > 0),
  notas       TEXT NOT NULL DEFAULT '',
  usuario_id  INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,   -- quién la registró
  creado_en   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE ventas (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  fecha           TEXT NOT NULL,
  cliente         TEXT NOT NULL DEFAULT '',
  producto_id     INTEGER NOT NULL REFERENCES productos(id),
  cantidad        REAL NOT NULL CHECK (cantidad > 0),
  precio_unitario REAL NOT NULL CHECK (precio_unitario >= 0),
  total           REAL NOT NULL,
  combustible     REAL NOT NULL DEFAULT 0 CHECK (combustible >= 0),
  camion_id       INTEGER REFERENCES camiones(id),     -- NULL = venta directa en planta
  vendedor_id     INTEGER REFERENCES vendedores(id),   -- NULL = venta directa
  usuario_id      INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,   -- quién la registró
  notas           TEXT NOT NULL DEFAULT '',
  creado_en       TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE costos (
  clave TEXT PRIMARY KEY,
  valor REAL NOT NULL CHECK (valor >= 0)
);

CREATE TABLE login_intentos (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  username  TEXT NOT NULL,
  ip        TEXT NOT NULL,
  creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX ix_produccion_fecha ON produccion(fecha, turno);
CREATE INDEX ix_ventas_fecha     ON ventas(fecha);
CREATE INDEX ix_ventas_vendedor  ON ventas(vendedor_id, fecha);
CREATE INDEX ix_cargas_camion    ON cargas(camion_id, fecha);
CREATE INDEX ix_cargas_vendedor  ON cargas(vendedor_id, fecha);
CREATE INDEX ix_entradas_fecha   ON entradas(fecha);
CREATE INDEX ix_vendedores_zona  ON vendedores(zona_id);
CREATE INDEX ix_login_user       ON login_intentos(username, creado_en);
