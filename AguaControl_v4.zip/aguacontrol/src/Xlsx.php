<?php
declare(strict_types=1);

/**
 * Generador mínimo de archivos Excel (.xlsx) sin dependencias.
 * Arma el paquete ZIP a mano (método "store"), así funciona aunque XAMPP no tenga la extensión zip.
 *
 *   $x = new Xlsx();
 *   $x->sheet('Ventas', 'Ventas del periodo', [['Fecha','date'], ['Total','money',true]], $rows);
 *   $x->download('ventas.xlsx');
 *
 * Tipos de columna: text, int, num, money, date (AAAA-MM-DD). El tercer valor true agrega total al final.
 */
final class Xlsx
{
    private array $sheets = [];
    // Estilos (índice en cellXfs): 0 normal, 1 encabezado, 2 dinero, 3 número, 4 fecha, 5 total texto, 6 total dinero, 7 título, 8 subtítulo, 9 total número, 10 entero
    private const STYLE = ['text' => 0, 'money' => 2, 'num' => 3, 'date' => 4, 'int' => 10];

    public function sheet(string $name, string $title, array $columns, array $rows, string $subtitle = ''): self
    {
        $this->sheets[] = compact('name', 'title', 'subtitle', 'columns', 'rows');
        return $this;
    }

    public function download(string $filename): never
    {
        $bin = $this->build();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($bin));
        echo $bin;
        exit;
    }

    public function build(): string
    {
        if (!$this->sheets) $this->sheet('Hoja1', 'Sin datos', [['Mensaje', 'text']], [['No hay datos en el periodo']]);
        $files = [];
        $n = count($this->sheets);
        $ov = ''; $rels = ''; $wbSheets = '';
        foreach ($this->sheets as $i => $s) {
            $k = $i + 1;
            $ov .= "<Override PartName=\"/xl/worksheets/sheet$k.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>";
            $rels .= "<Relationship Id=\"rId$k\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet$k.xml\"/>";
            $wbSheets .= '<sheet name="' . self::x(self::sheetName($s['name'], $i)) . "\" sheetId=\"$k\" r:id=\"rId$k\"/>";
            $files["xl/worksheets/sheet$k.xml"] = $this->sheetXml($s);
        }
        $files['[Content_Types].xml'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>' . $ov . '</Types>';
        $files['_rels/.rels'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>';
        $files['docProps/core.xml'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            . '<dc:title>AguaControl</dc:title><dc:creator>AguaControl</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">' . gmdate('Y-m-d\TH:i:s\Z') . '</dcterms:created></cp:coreProperties>';
        $files['xl/workbook.xml'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets>' . $wbSheets . '</sheets></workbook>';
        $files['xl/_rels/workbook.xml.rels'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . $rels . '<Relationship Id="rId' . ($n + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
        $files['xl/styles.xml'] = self::styles();
        return self::zip($files);
    }

    private function sheetXml(array $s): string
    {
        $cols = $s['columns'];
        $nc = count($cols);
        $last = self::col($nc - 1);
        $xml = '';
        $r = 1;
        $xml .= "<row r=\"$r\" ht=\"22\" customHeight=\"1\">" . self::cell("A$r", $s['title'], 7) . '</row>'; $r++;
        if ($s['subtitle'] !== '') { $xml .= "<row r=\"$r\">" . self::cell("A$r", $s['subtitle'], 8) . '</row>'; }
        $r++;
        $head = $r;
        $xml .= "<row r=\"$r\">";
        foreach ($cols as $i => $c) $xml .= self::cell(self::col($i) . $r, $c[0], 1);
        $xml .= '</row>';
        $first = $r + 1;
        foreach ($s['rows'] as $row) {
            $r++;
            $xml .= "<row r=\"$r\">";
            foreach (array_values($row) as $i => $v) {
                $type = $cols[$i][1] ?? 'text';
                $xml .= self::cell(self::col($i) . $r, $v, self::STYLE[$type] ?? 0, $type);
            }
            $xml .= '</row>';
        }
        $lastData = $r;
        $hasTotals = (bool) array_filter($cols, fn($c) => !empty($c[2]));
        if ($hasTotals && $s['rows']) {
            $r++;
            $xml .= "<row r=\"$r\">";
            foreach ($cols as $i => $c) {
                $ref = self::col($i) . $r;
                if (!empty($c[2])) {
                    $L = self::col($i);
                    $xml .= "<c r=\"$ref\" s=\"" . ($c[1] === 'money' ? 6 : 9) . "\"><f>SUM({$L}{$first}:{$L}{$lastData})</f></c>";
                } else {
                    $xml .= self::cell($ref, $i === 0 ? 'Total' : '', 5);
                }
            }
            $xml .= '</row>';
        }

        $widths = '';
        foreach ($cols as $i => $c) {
            $w = $c[3] ?? max(10, min(48, mb_strlen($c[0]) + 4));
            if (!isset($c[3])) foreach (array_slice($s['rows'], 0, 300) as $row) { $v = array_values($row)[$i] ?? ''; $w = max($w, min(48, mb_strlen((string) $v) + 3)); }
            $k = $i + 1;
            $widths .= "<col min=\"$k\" max=\"$k\" width=\"$w\" customWidth=\"1\"/>";
        }
        $filter = $s['rows'] ? "<autoFilter ref=\"A$head:$last$lastData\"/>" : '';
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheetViews><sheetView workbookViewId="0"><pane ySplit="' . $head . '" topLeftCell="A' . ($head + 1) . '" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
            . "<cols>$widths</cols><sheetData>$xml</sheetData>$filter</worksheet>";
    }

    private static function cell(string $ref, $v, int $style, string $type = 'text'): string
    {
        if ($v === null || $v === '') return "<c r=\"$ref\" s=\"$style\"/>";
        if ($type === 'date' && is_string($v) && preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $v, $m)) {
            $serial = (int) floor(gmmktime(0, 0, 0, (int) $m[2], (int) $m[3], (int) $m[1]) / 86400) + 25569;
            return "<c r=\"$ref\" s=\"$style\"><v>$serial</v></c>";
        }
        if (in_array($type, ['money', 'num', 'int'], true) && is_numeric($v)) {
            return "<c r=\"$ref\" s=\"$style\"><v>" . (0 + $v) . '</v></c>';
        }
        // Texto: nunca se interpreta como fórmula.
        return "<c r=\"$ref\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">" . self::x((string) $v) . '</t></is></c>';
    }

    private static function styles(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<numFmts count="3"><numFmt numFmtId="164" formatCode="&quot;$&quot;#,##0.00"/><numFmt numFmtId="165" formatCode="#,##0.###"/><numFmt numFmtId="166" formatCode="dd/mm/yyyy"/></numFmts>'
            . '<fonts count="5"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'
            . '<font><b/><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="14"/><color rgb="FF14305A"/><name val="Calibri"/></font><font><i/><sz val="10"/><color rgb="FF5B6B80"/><name val="Calibri"/></font></fonts>'
            . '<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FF1F4FA3"/><bgColor indexed="64"/></patternFill></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FFE8EEF7"/><bgColor indexed="64"/></patternFill></fill></fills>'
            . '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left/><right/><top style="thin"><color rgb="FF14305A"/></top><bottom/><diagonal/></border></borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="11">'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            . '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>'
            . '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            . '<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            . '<xf numFmtId="166" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            . '<xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>'
            . '<xf numFmtId="164" fontId="2" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/>'
            . '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
            . '<xf numFmtId="0" fontId="4" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
            . '<xf numFmtId="165" fontId="2" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"/>'
            . '<xf numFmtId="1" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
            . '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
    }

    private static function col(int $i): string
    {
        $s = '';
        for ($i++; $i > 0; $i = intdiv($i - 1, 26)) $s = chr(65 + ($i - 1) % 26) . $s;
        return $s;
    }

    private static function sheetName(string $name, int $i): string
    {
        $n = trim(preg_replace('/[\\\\\/\?\*\[\]:]/', ' ', $name));
        return mb_substr($n !== '' ? $n : 'Hoja' . ($i + 1), 0, 31);
    }

    private static function x(string $s): string
    {
        $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', '', $s) ?? '';
        return htmlspecialchars($s, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    /** ZIP sin compresión (suficiente para estos archivos y no requiere extensiones). */
    private static function zip(array $files): string
    {
        $data = ''; $central = ''; $offset = 0;
        $t = getdate();
        $dosTime = ($t['hours'] << 11) | ($t['minutes'] << 5) | intdiv($t['seconds'], 2);
        $dosDate = (($t['year'] - 1980) << 9) | ($t['mon'] << 5) | $t['mday'];
        foreach ($files as $name => $content) {
            $crc = crc32($content); $len = strlen($content); $nlen = strlen($name);
            $local = pack('VvvvvvVVVvv', 0x04034b50, 20, 0x0800, 0, $dosTime, $dosDate, $crc, $len, $len, $nlen, 0) . $name;
            $central .= pack('VvvvvvvVVVvvvvvVV', 0x02014b50, 20, 20, 0x0800, 0, $dosTime, $dosDate, $crc, $len, $len, $nlen, 0, 0, 0, 0, 0, $offset) . $name;
            $data .= $local . $content;
            $offset += strlen($local) + $len;
        }
        return $data . $central . pack('VvvvvVVv', 0x06054b50, 0, 0, count($files), count($files), strlen($central), $offset, 0);
    }
}
