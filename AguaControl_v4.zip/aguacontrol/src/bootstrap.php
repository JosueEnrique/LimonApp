<?php
declare(strict_types=1);

// Los errores van al log de PHP, nunca a la pantalla del usuario.
ini_set('display_errors', '0');
ini_set('log_errors', '1');

require __DIR__ . '/helpers.php';
date_default_timezone_set(app_config('timezone'));
mb_internal_encoding('UTF-8');

require __DIR__ . '/Database.php';
require __DIR__ . '/Validator.php';
require __DIR__ . '/Auth.php';
require __DIR__ . '/Inventory.php';
require __DIR__ . '/Xlsx.php';
foreach (glob(__DIR__ . '/controllers/*.php') as $file) require $file;
