<?php
declare(strict_types=1);

/**
 * Ajustes de datos que se aplican una sola vez a una base existente.
 * Cada ajuste queda anotado en la tabla meta para no repetirse.
 */
final class DataPatches
{
    private const PATCHES = [
        'patch_planta_sanmiguel_2026_10' => 'sellersPlantaAndSanMiguel',
        'patch_un_supervisor_2026_10'    => 'singleSupervisor',
    ];

    public static function apply(PDO $pdo): void
    {
        try {
            $done = $pdo->query("SELECT clave FROM meta WHERE clave LIKE 'patch_%'")->fetchAll(PDO::FETCH_COLUMN);
        } catch (Throwable) {
            return; // base sin instalar todavía (MySQL antes de install.php)
        }
        foreach (self::PATCHES as $key => $method) {
            if (in_array($key, $done, true)) continue;
            $pdo->beginTransaction();
            try {
                self::$method($pdo);
                $pdo->prepare('INSERT INTO meta (clave, valor) VALUES (?, ?)')->execute([$key, now_local()]);
                $pdo->commit();
            } catch (Throwable $e) {
                $pdo->rollBack();
                error_log("[AguaControl] Ajuste $key no aplicado: " . $e->getMessage());
            }
        }
    }

    /** Un solo supervisor de producción activo (se prefiere a salvador; los demás se desactivan y conservan su historial). */
    private static function singleSupervisor(PDO $pdo): void
    {
        $ids = $pdo->query("SELECT id FROM usuarios WHERE rol = 'supervisor' AND activo = 1
                            ORDER BY CASE WHEN username = 'salvador' THEN 0 ELSE 1 END, id")->fetchAll(PDO::FETCH_COLUMN);
        if (count($ids) <= 1) return;
        $keep = (int) array_shift($ids);
        $pdo->exec("UPDATE usuarios SET activo = 0 WHERE rol = 'supervisor' AND id <> $keep");
    }

    /** Juan y Pedro en Planta con sus camiones; Luis y Julio nuevos en San Miguel con camiones nuevos. */
    private static function sellersPlantaAndSanMiguel(PDO $pdo): void
    {
        $zone = function (string $name) use ($pdo): int {
            $id = $pdo->query('SELECT id FROM zonas WHERE nombre = ' . $pdo->quote($name))->fetchColumn();
            if (!$id) { $pdo->prepare('INSERT INTO zonas (nombre, creado_en) VALUES (?, ?)')->execute([$name, now_local()]); $id = $pdo->lastInsertId(); }
            return (int) $id;
        };
        $truck = function (string $code, string $desc) use ($pdo): int {
            $id = $pdo->query('SELECT id FROM camiones WHERE codigo = ' . $pdo->quote($code))->fetchColumn();
            if (!$id) { $pdo->prepare('INSERT INTO camiones (codigo, placa, descripcion, creado_en) VALUES (?, ?, ?, ?)')->execute([$code, '', $desc, now_local()]); $id = $pdo->lastInsertId(); }
            $pdo->prepare('UPDATE camiones SET activo = 1 WHERE id = ?')->execute([$id]);
            return (int) $id;
        };
        $nextCode = function () use ($pdo): string {
            $n = 0;
            foreach ($pdo->query("SELECT codigo FROM vendedores WHERE codigo LIKE 'V-%'")->fetchAll(PDO::FETCH_COLUMN) as $c) $n = max($n, (int) substr($c, 2));
            return sprintf('V-%02d', $n + 1);
        };
        /** Pone el camión al vendedor, quitándoselo a cualquier otro que lo tuviera. */
        $assign = function (int $sellerId, int $truckId, int $zoneId) use ($pdo): void {
            $pdo->prepare('UPDATE vendedores SET camion_id = NULL WHERE camion_id = ? AND id <> ?')->execute([$truckId, $sellerId]);
            $pdo->prepare('UPDATE vendedores SET zona_id = ?, camion_id = ?, activo = 1 WHERE id = ?')->execute([$zoneId, $truckId, $sellerId]);
        };
        $find = fn(string $name) => $pdo->query('SELECT id FROM vendedores WHERE nombre = ' . $pdo->quote($name) . ' ORDER BY id LIMIT 1')->fetchColumn();

        $planta = $zone('Planta');
        $sanMiguel = $zone('San Miguel');

        foreach ([['Juan', 'CAM-01'], ['Pedro', 'CAM-02']] as [$name, $code]) {
            $id = $find($name);
            $t = $truck($code, 'Ruta Planta');
            if (!$id) {
                $pdo->prepare('INSERT INTO vendedores (codigo, nombre, zona_id, camion_id, creado_en) VALUES (?, ?, ?, ?, ?)')->execute([$nextCode(), $name, $planta, $t, now_local()]);
                $id = $pdo->lastInsertId();
            }
            $assign((int) $id, $t, $planta);
            $pdo->prepare('UPDATE camiones SET descripcion = ? WHERE id = ?')->execute(['Ruta Planta', $t]);
        }

        // Camiones nuevos para San Miguel: los siguientes códigos libres después de los existentes.
        foreach (['Luis', 'Julio'] as $name) {
            if ($find($name)) continue;
            $n = 0;
            foreach ($pdo->query("SELECT codigo FROM camiones WHERE codigo LIKE 'CAM-%'")->fetchAll(PDO::FETCH_COLUMN) as $c) $n = max($n, (int) substr($c, 4));
            $t = $truck(sprintf('CAM-%02d', $n + 1), "Ruta San Miguel ($name)");
            $pdo->prepare('INSERT INTO vendedores (codigo, nombre, zona_id, camion_id, creado_en) VALUES (?, ?, ?, ?, ?)')->execute([$nextCode(), $name, $sanMiguel, $t, now_local()]);
        }
    }
}
