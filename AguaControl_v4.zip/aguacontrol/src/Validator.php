<?php
declare(strict_types=1);

/**
 * Valida y limpia los datos que llegan del navegador.
 * Junta todos los errores y responde 422 con un mensaje por campo.
 *
 *   $d = Validator::of($input)->date('fecha')->num('cantidad', 0.001, 1e6)->validate();
 */
final class Validator
{
    private array $out = [];
    private array $errors = [];

    private function __construct(private array $in) {}
    public static function of(array $in): self { return new self($in); }

    private function raw(string $f) { return array_key_exists($f, $this->in) ? $this->in[$f] : null; }
    private function blank($v): bool { return $v === null || (is_string($v) && trim($v) === ''); }
    private function fail(string $f, string $msg): self { $this->errors[$f] ??= $msg; return $this; }

    public function date(string $f, bool $required = true, string $label = 'La fecha'): self
    {
        $v = $this->raw($f);
        if ($this->blank($v)) return $required ? $this->fail($f, "$label es obligatoria.") : $this->set($f, null);
        $d = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $v);
        if (!$d || $d->format('Y-m-d') !== $v) return $this->fail($f, "$label no es válida (use AAAA-MM-DD).");
        if ($v < '2000-01-01') return $this->fail($f, "$label es demasiado antigua.");
        if ($v > date('Y-m-d', strtotime('+1 day'))) return $this->fail($f, "$label no puede estar en el futuro.");
        return $this->set($f, $v);
    }

    public function num(string $f, float $min, float $max, bool $required = true, ?float $default = null, string $label = 'El valor', int $decimals = 4): self
    {
        $v = $this->raw($f);
        if ($this->blank($v)) {
            if ($required) return $this->fail($f, "$label es obligatorio.");
            return $this->set($f, $default);
        }
        if (is_string($v)) $v = str_replace(',', '.', trim($v));
        if (!is_numeric($v) || !is_finite((float) $v)) return $this->fail($f, "$label debe ser un número.");
        $n = round((float) $v, $decimals);
        if ($n < $min) return $this->fail($f, "$label debe ser como mínimo " . rtrim(rtrim(number_format($min, 4, '.', ''), '0'), '.') . '.');
        if ($n > $max) return $this->fail($f, "$label es demasiado grande (máximo " . number_format($max, 0, '.', ',') . ').');
        return $this->set($f, $n);
    }

    public function int(string $f, bool $required = true, string $label = 'El valor'): self
    {
        $v = $this->raw($f);
        if ($this->blank($v)) return $required ? $this->fail($f, "$label es obligatorio.") : $this->set($f, null);
        if (filter_var($v, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) === false) return $this->fail($f, "$label no es válido.");
        return $this->set($f, (int) $v);
    }

    public function str(string $f, int $max, bool $required = false, string $label = 'El texto', ?string $pattern = null, string $patternMsg = ''): self
    {
        $v = $this->raw($f);
        if (!$this->blank($v) && !is_scalar($v)) return $this->fail($f, "$label no es válido.");
        $s = trim(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', (string) ($v ?? '')) ?? '');
        if ($s === '' && $required) return $this->fail($f, "$label es obligatorio.");
        if (mb_strlen($s) > $max) return $this->fail($f, "$label admite como máximo $max caracteres.");
        if ($s !== '' && $pattern && !preg_match($pattern, $s)) return $this->fail($f, $patternMsg ?: "$label tiene un formato no válido.");
        return $this->set($f, $s);
    }

    public function enum(string $f, array $allowed, bool $required = true, string $label = 'La opción'): self
    {
        $v = $this->raw($f);
        if ($this->blank($v)) return $required ? $this->fail($f, "$label es obligatoria.") : $this->set($f, null);
        if (!in_array($v, $allowed, true)) return $this->fail($f, "$label no es válida.");
        return $this->set($f, $v);
    }

    public function bool(string $f): self
    {
        return $this->set($f, filter_var($this->raw($f), FILTER_VALIDATE_BOOLEAN) ? 1 : 0);
    }

    /** Verifica que el id exista (y esté activo si la tabla tiene esa columna). */
    public function exists(string $f, string $table, bool $required = true, string $label = 'El registro', bool $activeOnly = true): self
    {
        $this->int($f, $required, $label);
        if (isset($this->errors[$f]) || ($this->out[$f] ?? null) === null) return $this;
        $sql = "SELECT 1 FROM $table WHERE id = ?" . ($activeOnly ? ' AND activo = 1' : '');
        if (!Database::value($sql, [$this->out[$f]])) $this->fail($f, "$label seleccionado no existe o está inactivo.");
        return $this;
    }

    public function check(bool $ok, string $f, string $msg): self { return $ok ? $this : $this->fail($f, $msg); }
    public function get(string $f) { return $this->out[$f] ?? null; }
    public function set(string $f, $v): self { $this->out[$f] = $v; return $this; }

    public function validate(): array
    {
        if ($this->errors) {
            throw new HttpError(422, reset($this->errors), ['errors' => $this->errors]);
        }
        return $this->out;
    }
}
