<?php
declare(strict_types=1);

const SCHEMA_VERSION = 3;
const ROLES = ['admin' => 'Administrador', 'contabilidad' => 'Contabilidad', 'despacho' => 'Despacho', 'supervisor' => 'Supervisor de producción'];
const DEFAULT_ZONES = ['Planta', 'Morazán', 'San Miguel'];
const TURNOS = ['Mañana', 'Tarde', 'Noche'];
const INSUMOS = ['Agua cruda', 'Botella 600 ml', 'Botella 1 L', 'Galón', 'Garrafón', 'Tapón', 'Etiqueta',
                 'Empaque fardo', 'Cloro', 'Filtro', 'Combustible', 'Mantenimiento', 'Otro'];
const DEFAULT_COSTS = [
    'agua' => 0.05, 'mano_obra' => 0.02, 'energia' => 0.01, 'mantenimiento' => 0.01, 'margen' => 30,
    'b600' => 0.15, 'b1l' => 0.20, 'galon' => 0.75, 'garrafon' => 2.50, 'tapon' => 0.02, 'etiqueta' => 0.03, 'empaque' => 0.50,
];

/** Error controlado que se devuelve al navegador como JSON. */
final class HttpError extends RuntimeException
{
    public function __construct(int $status, string $message, public array $extra = [])
    {
        parent::__construct($message, $status);
    }
}

function app_config(?string $key = null)
{
    static $cfg = null;
    $cfg ??= require __DIR__ . '/../config/config.php';
    return $key === null ? $cfg : ($cfg[$key] ?? null);
}

function now_local(): string { return date('Y-m-d H:i:s'); }
function today(): string { return date('Y-m-d'); }

function json_out(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION);
    exit;
}

function request_body(): array
{
    static $body = null;
    if ($body !== null) return $body;
    $raw = file_get_contents('php://input') ?: '';
    if ($raw === '') return $body = [];
    if (strlen($raw) > 8 * 1024 * 1024) throw new HttpError(413, 'El contenido enviado es demasiado grande.');
    $data = json_decode($raw, true);
    if (!is_array($data)) throw new HttpError(400, 'El contenido enviado no es JSON válido.');
    return $body = $data;
}

function client_ip(): string { return substr((string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45); }

/** Convierte las filas numéricas que PDO devuelve como texto en números reales. */
function numeric_rows(array $rows, array $fields): array
{
    foreach ($rows as &$r) foreach ($fields as $f) if (isset($r[$f])) $r[$f] = $r[$f] + 0;
    return $rows;
}
