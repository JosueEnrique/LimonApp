<?php
declare(strict_types=1);

final class Auth
{
    private static ?array $user = null;

    public static function start(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) return;
        $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
        session_name(app_config('session')['name']);
        session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'secure' => $https, 'samesite' => 'Strict']);
        ini_set('session.use_strict_mode', '1');
        session_start();

        $idle = app_config('session')['idle_minutes'] * 60;
        if (isset($_SESSION['uid'], $_SESSION['last']) && time() - $_SESSION['last'] > $idle) {
            self::logout();
            session_start();
        }
        $_SESSION['last'] = time();
        $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
    }

    public static function csrf(): string { return $_SESSION['csrf']; }

    public static function checkCsrf(): void
    {
        $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!is_string($sent) || !hash_equals($_SESSION['csrf'] ?? '', $sent)) {
            throw new HttpError(419, 'La sesión expiró. Recarga la página.');
        }
    }

    /** Usuario actual, releído de la base para que un cambio de rol o desactivación aplique de inmediato. */
    public static function user(): ?array
    {
        if (self::$user) return self::$user;
        if (empty($_SESSION['uid'])) return null;
        $u = Database::one('SELECT u.id, u.username, u.nombre, u.rol, u.zona_id, z.nombre AS zona
                            FROM usuarios u LEFT JOIN zonas z ON z.id = u.zona_id
                            WHERE u.id = ? AND u.activo = 1', [$_SESSION['uid']]);
        if (!$u) { self::logout(); return null; }
        $u['id'] = (int) $u['id'];
        $u['zona_id'] = $u['zona_id'] !== null ? (int) $u['zona_id'] : null;
        return self::$user = $u;
    }

    public static function require(string ...$roles): array
    {
        $u = self::user();
        if (!$u) throw new HttpError(401, 'Tu sesión terminó. Vuelve a iniciar sesión.');
        if ($roles && !in_array($u['rol'], $roles, true)) throw new HttpError(403, 'No tienes permiso para esta acción.');
        return $u;
    }

    public static function isAdmin(): bool { return (self::user()['rol'] ?? '') === 'admin'; }

    public static function attempt(string $username, string $password): array
    {
        $sec = app_config('security');
        $username = mb_strtolower(trim($username));
        $since = date('Y-m-d H:i:s', time() - $sec['lockout_minutes'] * 60);
        $byUser = (int) Database::value('SELECT COUNT(*) FROM login_intentos WHERE username = ? AND creado_en >= ?', [$username, $since]);
        $byIp   = (int) Database::value('SELECT COUNT(*) FROM login_intentos WHERE ip = ? AND creado_en >= ?', [client_ip(), $since]);
        if ($byUser >= $sec['max_login_attempts'] || $byIp >= $sec['max_login_attempts'] * 3) {
            throw new HttpError(429, "Demasiados intentos fallidos. Espera {$sec['lockout_minutes']} minutos e inténtalo de nuevo.");
        }

        $u = Database::one('SELECT id, password_hash FROM usuarios WHERE username = ? AND activo = 1', [$username]);
        // Si el usuario no existe se verifica igual contra un hash falso para no revelar qué usuarios existen por el tiempo de respuesta.
        $hash = $u['password_hash'] ?? password_hash(random_bytes(8), PASSWORD_DEFAULT);
        if (!password_verify($password, $hash) || !$u) {
            Database::insert('login_intentos', ['username' => $username, 'ip' => client_ip()]);
            throw new HttpError(401, 'Usuario o contraseña incorrectos.');
        }

        if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) {
            Database::update('usuarios', (int) $u['id'], ['password_hash' => password_hash($password, PASSWORD_DEFAULT)]);
        }
        Database::run('DELETE FROM login_intentos WHERE username = ?', [$username]);
        Database::run('UPDATE usuarios SET ultimo_acceso = ? WHERE id = ?', [now_local(), $u['id']]);

        session_regenerate_id(true);
        $_SESSION['uid'] = (int) $u['id'];
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        self::$user = null;
        return self::user();
    }

    public static function logout(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', ['expires' => time() - 42000, 'path' => $p['path'], 'httponly' => true, 'samesite' => 'Strict']);
        }
        if (session_status() === PHP_SESSION_ACTIVE) session_destroy();
        self::$user = null;
    }
}
