<?php
declare(strict_types=1);

/** Vendedores de ruta (no entran al sistema). Cada uno tiene zona y, para vender, un camión. */
final class SellersController
{
    public static function list(): array
    {
        $u = Auth::require('admin', 'contabilidad', 'despacho');
        $rows = CatalogController::sellers($u, false);
        $mes = date('Y-m-01');
        $stats = [];
        foreach (Database::all('SELECT vendedor_id, COUNT(*) ventas, SUM(total) ingresos, MAX(fecha) ultima FROM ventas WHERE vendedor_id IS NOT NULL GROUP BY vendedor_id') as $r) $stats[$r['vendedor_id']] = $r;
        $month = [];
        foreach (Database::all('SELECT vendedor_id, SUM(total) ingresos FROM ventas WHERE vendedor_id IS NOT NULL AND fecha >= ? GROUP BY vendedor_id', [$mes]) as $r) $month[$r['vendedor_id']] = (float) $r['ingresos'];
        foreach ($rows as &$r) {
            $s = $stats[$r['id']] ?? null;
            $r['ventas_total'] = (int) ($s['ventas'] ?? 0);
            $r['ingresos_total'] = round((float) ($s['ingresos'] ?? 0), 2);
            $r['ingresos_mes'] = round($month[$r['id']] ?? 0, 2);
            $r['ultima_venta'] = $s['ultima'] ?? null;
            $r['stock'] = $r['camion_id'] ? (Inventory::trucks($r['camion_id'])[0]['productos'] ?? []) : [];
        }
        return ['items' => $rows, 'siguiente' => self::nextCode()];
    }

    private static function input(?int $id): array
    {
        $in = request_body();
        $in['codigo'] = strtoupper(trim((string) ($in['codigo'] ?? '')));
        if ($in['codigo'] === '') $in['codigo'] = self::nextCode();
        $d = Validator::of($in)
            ->str('codigo', 20, true, 'El código', '/^[A-Z0-9-]{2,20}$/', 'El código solo admite letras, números y guiones (ej. V-03).')
            ->str('nombre', 60, true, 'El nombre')
            ->str('telefono', 20, false, 'El teléfono', '/^[0-9 +()-]+$/', 'El teléfono solo admite números, espacios, +, guiones y paréntesis.')
            ->exists('zona_id', 'zonas', true, 'La zona')->exists('camion_id', 'camiones', false, 'El camión')->bool('activo')->validate();
        if (!array_key_exists('activo', $in)) $d['activo'] = 1;
        if (Database::value('SELECT 1 FROM vendedores WHERE codigo = ? AND id <> ?', [$d['codigo'], $id ?? 0])) throw new HttpError(422, 'Ya existe un vendedor con ese código.', ['errors' => ['codigo' => 'Repetido.']]);
        if ($d['camion_id'] && $d['activo']) {
            $other = Database::one('SELECT nombre FROM vendedores WHERE camion_id = ? AND activo = 1 AND id <> ?', [$d['camion_id'], $id ?? 0]);
            if ($other) throw new HttpError(422, "Ese camión ya lo usa {$other['nombre']}. Quítaselo primero.", ['errors' => ['camion_id' => 'Ya asignado.']]);
        }
        if (!$d['activo']) $d['camion_id'] = null;
        return $d;
    }

    public static function create(): array
    {
        Auth::require('admin');
        $id = Database::insert('vendedores', self::input(null));
        return ['ok' => true, 'id' => $id, 'message' => 'Vendedor agregado.'];
    }

    public static function update(int $id): array
    {
        Auth::require('admin');
        if (!Database::value('SELECT 1 FROM vendedores WHERE id = ?', [$id])) throw new HttpError(404, 'El vendedor no existe.');
        Database::update('vendedores', $id, self::input($id));
        return ['ok' => true, 'message' => 'Vendedor actualizado.'];
    }

    public static function delete(int $id): array
    {
        Auth::require('admin');
        if (!Database::value('SELECT 1 FROM vendedores WHERE id = ?', [$id])) throw new HttpError(404, 'El vendedor no existe.');
        $used = (int) Database::value('SELECT (SELECT COUNT(*) FROM ventas WHERE vendedor_id = ?) + (SELECT COUNT(*) FROM cargas WHERE vendedor_id = ?)', [$id, $id]);
        if ($used) {
            Database::update('vendedores', $id, ['activo' => 0, 'camion_id' => null]);
            return ['ok' => true, 'message' => 'El vendedor tiene ventas o cargas, así que se desactivó y se conserva su historial.'];
        }
        Database::run('DELETE FROM vendedores WHERE id = ?', [$id]);
        return ['ok' => true, 'message' => 'Vendedor eliminado.'];
    }

    private static function nextCode(): string
    {
        $n = 0;
        foreach (Database::all("SELECT codigo FROM vendedores WHERE codigo LIKE 'V-%'") as $r) $n = max($n, (int) substr($r['codigo'], 2));
        return sprintf('V-%02d', $n + 1);
    }
}

/** Zonas de trabajo (Planta, Morazán, San Miguel…). */
final class ZonesController
{
    public static function list(): array
    {
        Auth::require('admin');
        $rows = Database::all('SELECT z.*, (SELECT COUNT(*) FROM vendedores v WHERE v.zona_id = z.id AND v.activo = 1) vendedores,
                               (SELECT COUNT(*) FROM usuarios u WHERE u.zona_id = z.id AND u.activo = 1) encargados FROM zonas z ORDER BY z.id');
        return ['items' => numeric_rows($rows, ['id', 'activo', 'vendedores', 'encargados'])];
    }

    private static function input(?int $id): array
    {
        $in = request_body();
        $d = Validator::of($in)->str('nombre', 60, true, 'El nombre de la zona')->bool('activo')->validate();
        if (!array_key_exists('activo', $in)) $d['activo'] = 1;
        if (Database::value('SELECT 1 FROM zonas WHERE nombre = ? AND id <> ?', [$d['nombre'], $id ?? 0])) throw new HttpError(422, 'Ya existe una zona con ese nombre.', ['errors' => ['nombre' => 'Repetida.']]);
        return $d;
    }

    public static function create(): array
    {
        Auth::require('admin');
        $id = Database::insert('zonas', self::input(null));
        return ['ok' => true, 'id' => $id, 'message' => 'Zona creada.'];
    }

    public static function update(int $id): array
    {
        Auth::require('admin');
        if (!Database::value('SELECT 1 FROM zonas WHERE id = ?', [$id])) throw new HttpError(404, 'La zona no existe.');
        $d = self::input($id);
        if (!$d['activo'] && Database::value('SELECT 1 FROM vendedores WHERE zona_id = ? AND activo = 1', [$id])) {
            throw new HttpError(422, 'Mueve primero a los vendedores activos de esta zona a otra zona.');
        }
        Database::update('zonas', $id, $d);
        return ['ok' => true, 'message' => 'Zona actualizada.'];
    }
}
