<?php
declare(strict_types=1);

/** Cuentas que entran al sistema (admin, contabilidad, despacho, supervisor). */
final class UsersController
{
    private const USER_RE = '/^[a-z0-9_.-]{3,32}$/';

    public static function list(): array
    {
        Auth::require('admin');
        $rows = Database::all('SELECT u.id, u.username, u.nombre, u.rol, u.zona_id, z.nombre AS zona, u.activo, u.ultimo_acceso, u.creado_en
                               FROM usuarios u LEFT JOIN zonas z ON z.id = u.zona_id ORDER BY u.activo DESC, u.rol, u.nombre');
        return ['items' => numeric_rows($rows, ['id', 'zona_id', 'activo'])];
    }

    /** Solo una persona usa el rol de supervisor de producción. */
    private static function singleSupervisor(array $d, ?int $id): void
    {
        if ($d['rol'] !== 'supervisor' || (array_key_exists('activo', $d) && !$d['activo'])) return;
        $other = Database::one("SELECT nombre, username FROM usuarios WHERE rol = 'supervisor' AND activo = 1 AND id <> ?", [$id ?? 0]);
        if ($other) throw new HttpError(422, "Ya hay un supervisor de producción activo: {$other['nombre']} (@{$other['username']}). Desactívalo primero o cambia su contraseña si otra persona tomará el puesto.", ['errors' => ['rol' => 'Ya existe un supervisor activo.']]);
    }

    private static function zoneRule(array $d): array
    {
        if ($d['rol'] === 'despacho' && !$d['zona_id']) {
            throw new HttpError(422, 'Un encargado de despacho necesita una zona.', ['errors' => ['zona_id' => 'Obligatoria para despacho.']]);
        }
        if ($d['rol'] !== 'despacho') $d['zona_id'] = null;
        return $d;
    }

    public static function create(): array
    {
        Auth::require('admin');
        $in = request_body();
        $in['username'] = mb_strtolower(trim((string) ($in['username'] ?? '')));
        $d = Validator::of($in)
            ->str('username', 32, true, 'El usuario', self::USER_RE, 'El usuario debe tener 3 a 32 caracteres: letras minúsculas, números, punto, guion o guion bajo.')
            ->str('nombre', 60, true, 'El nombre')->enum('rol', array_keys(ROLES), true, 'El rol')
            ->exists('zona_id', 'zonas', false, 'La zona')->validate();
        $d = self::zoneRule($d);
        self::singleSupervisor($d, null);
        if (Database::value('SELECT 1 FROM usuarios WHERE username = ?', [$d['username']])) throw new HttpError(422, 'Ese nombre de usuario ya existe.', ['errors' => ['username' => 'Ya existe.']]);
        AuthController::checkStrength((string) ($in['password'] ?? ''), $d['username'], app_config('security')['min_password']);
        $d['password_hash'] = password_hash((string) $in['password'], PASSWORD_DEFAULT);
        $id = Database::insert('usuarios', $d);
        return ['ok' => true, 'id' => $id, 'message' => 'Usuario creado.'];
    }

    public static function update(int $id): array
    {
        $me = Auth::require('admin');
        $old = Database::one('SELECT * FROM usuarios WHERE id = ?', [$id]) ?? throw new HttpError(404, 'El usuario no existe.');
        $d = Validator::of(request_body())->str('nombre', 60, true, 'El nombre')->enum('rol', array_keys(ROLES), true, 'El rol')
            ->exists('zona_id', 'zonas', false, 'La zona')->bool('activo')->validate();
        $d = self::zoneRule($d);
        self::singleSupervisor($d, $id);
        if ($id === $me['id'] && ($d['rol'] !== 'admin' || !$d['activo'])) throw new HttpError(422, 'No puedes quitarte el rol de administrador ni desactivarte a ti mismo.');
        if ($old['rol'] === 'admin' && ($d['rol'] !== 'admin' || !$d['activo']) && self::activeAdmins() <= 1) throw new HttpError(422, 'Debe quedar al menos un administrador activo.');
        Database::update('usuarios', $id, $d);
        return ['ok' => true, 'message' => 'Usuario actualizado.'];
    }

    public static function resetPassword(int $id): array
    {
        Auth::require('admin');
        $u = Database::one('SELECT username FROM usuarios WHERE id = ?', [$id]) ?? throw new HttpError(404, 'El usuario no existe.');
        $pw = (string) (request_body()['password'] ?? '');
        AuthController::checkStrength($pw, $u['username'], app_config('security')['min_password']);
        Database::update('usuarios', $id, ['password_hash' => password_hash($pw, PASSWORD_DEFAULT)]);
        Database::run('DELETE FROM login_intentos WHERE username = ?', [$u['username']]);
        return ['ok' => true, 'message' => 'Contraseña restablecida.'];
    }

    public static function delete(int $id): array
    {
        $me = Auth::require('admin');
        if ($id === $me['id']) throw new HttpError(422, 'No puedes eliminar tu propio usuario.');
        $u = Database::one('SELECT rol, activo FROM usuarios WHERE id = ?', [$id]) ?? throw new HttpError(404, 'El usuario no existe.');
        if ($u['rol'] === 'admin' && $u['activo'] && self::activeAdmins() <= 1) throw new HttpError(422, 'Debe quedar al menos un administrador activo.');
        $used = 0;
        foreach (['entradas', 'produccion', 'cargas', 'ventas'] as $t) $used += (int) Database::value("SELECT COUNT(*) FROM $t WHERE usuario_id = ?", [$id]);
        if ($used) {
            Database::update('usuarios', $id, ['activo' => 0]);
            return ['ok' => true, 'message' => 'El usuario tiene registros, así que se desactivó en lugar de borrarse (se conserva su historial).'];
        }
        Database::run('DELETE FROM usuarios WHERE id = ?', [$id]);
        return ['ok' => true, 'message' => 'Usuario eliminado.'];
    }

    private static function activeAdmins(): int
    {
        return (int) Database::value("SELECT COUNT(*) FROM usuarios WHERE rol = 'admin' AND activo = 1");
    }
}
