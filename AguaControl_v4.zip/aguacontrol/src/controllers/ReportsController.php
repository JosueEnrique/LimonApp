<?php
declare(strict_types=1);

final class ReportsController
{
    private static function filters(): array
    {
        $q = Validator::of($_GET)->date('desde', false, 'La fecha inicial')->date('hasta', false, 'La fecha final')
            ->int('vendedor_id', false)->int('camion_id', false)->int('zona_id', false)->validate();
        $q['desde'] ??= date('Y-m-01');
        $q['hasta'] ??= today();
        if ($q['desde'] > $q['hasta']) throw new HttpError(422, 'La fecha inicial no puede ser posterior a la final.');
        return $q;
    }

    // ------------------------------------------------------------------
    // Dashboard del administrador: ventas, compras y movimiento del producto
    // ------------------------------------------------------------------
    public static function dashboard(): array
    {
        Auth::require('admin');
        $q = self::filters();
        $p = [$q['desde'], $q['hasta']];
        $costs = Inventory::costMap();

        $sales = $fuel = $std = $units = 0; $direct = 0; $fromTruck = 0;
        $ventas = Database::all('SELECT producto_id, cantidad, total, combustible, camion_id FROM ventas WHERE fecha BETWEEN ? AND ?', $p);
        foreach ($ventas as $v) {
            $sales += $v['total']; $fuel += $v['combustible']; $units += $v['cantidad'];
            $std += $v['cantidad'] * ($costs[$v['producto_id']] ?? 0);
            if ($v['camion_id']) $fromTruck += $v['cantidad']; else $direct += $v['cantidad'];
        }
        $purchases = (float) Database::value('SELECT COALESCE(SUM(total),0) FROM entradas WHERE fecha BETWEEN ? AND ?', $p);
        $nPurch = (int) Database::value('SELECT COUNT(*) FROM entradas WHERE fecha BETWEEN ? AND ?', $p);
        $prod = Database::one('SELECT COALESCE(SUM(cantidad - desperdicio),0) neta, COALESCE(SUM(desperdicio),0) desperdicio FROM produccion WHERE fecha BETWEEN ? AND ?', $p);
        $loaded = (float) Database::value('SELECT COALESCE(SUM(cantidad),0) FROM cargas WHERE fecha BETWEEN ? AND ?', $p);

        // Serie diaria de ventas y compras, con todos los días del periodo
        $vd = []; foreach (Database::all('SELECT fecha, SUM(total) t FROM ventas WHERE fecha BETWEEN ? AND ? GROUP BY fecha', $p) as $r) $vd[$r['fecha']] = (float) $r['t'];
        $cd = []; foreach (Database::all('SELECT fecha, SUM(total) t FROM entradas WHERE fecha BETWEEN ? AND ? GROUP BY fecha', $p) as $r) $cd[$r['fecha']] = (float) $r['t'];
        $daily = [];
        $days = (int) ((strtotime($q['hasta']) - strtotime($q['desde'])) / 86400);
        if ($days <= 92) {
            for ($d = strtotime($q['desde']); $d <= strtotime($q['hasta']); $d += 86400) {
                $f = date('Y-m-d', $d);
                $daily[] = ['fecha' => $f, 'ventas' => round($vd[$f] ?? 0, 2), 'compras' => round($cd[$f] ?? 0, 2)];
            }
        } else {
            foreach (array_unique([...array_keys($vd), ...array_keys($cd)]) as $f) $daily[] = ['fecha' => $f, 'ventas' => round($vd[$f] ?? 0, 2), 'compras' => round($cd[$f] ?? 0, 2)];
            usort($daily, fn($a, $b) => strcmp($a['fecha'], $b['fecha']));
        }

        $porZona = numeric_rows(Database::all("SELECT COALESCE(z.nombre, 'Venta directa') zona, COUNT(*) ventas, SUM(v.total) ingresos
            FROM ventas v LEFT JOIN vendedores vd ON vd.id = v.vendedor_id LEFT JOIN zonas z ON z.id = vd.zona_id
            WHERE v.fecha BETWEEN ? AND ? GROUP BY z.id, z.nombre ORDER BY ingresos DESC", $p), ['ventas', 'ingresos']);
        $porVendedor = numeric_rows(Database::all("SELECT vd.nombre vendedor, vd.codigo, z.nombre zona, COUNT(*) ventas, SUM(v.total) ingresos
            FROM ventas v JOIN vendedores vd ON vd.id = v.vendedor_id JOIN zonas z ON z.id = vd.zona_id
            WHERE v.fecha BETWEEN ? AND ? GROUP BY vd.id, vd.nombre, vd.codigo, z.nombre ORDER BY ingresos DESC LIMIT 8", $p), ['ventas', 'ingresos']);
        $porInsumo = numeric_rows(Database::all('SELECT tipo, COUNT(*) compras, SUM(total) total FROM entradas WHERE fecha BETWEEN ? AND ? GROUP BY tipo ORDER BY total DESC', $p), ['compras', 'total']);
        $proveedores = numeric_rows(Database::all("SELECT CASE WHEN proveedor = '' THEN '(sin proveedor)' ELSE proveedor END proveedor, COUNT(*) compras, SUM(total) total
            FROM entradas WHERE fecha BETWEEN ? AND ? GROUP BY proveedor ORDER BY total DESC LIMIT 6", $p), ['compras', 'total']);
        $ultimasCompras = numeric_rows(Database::all('SELECT fecha, proveedor, tipo, cantidad, total FROM entradas WHERE fecha BETWEEN ? AND ? ORDER BY fecha DESC, id DESC LIMIT 6', $p), ['cantidad', 'total']);

        $plant = Inventory::plant();
        return [
            'periodo' => $q,
            'ventas' => ['ingresos' => round($sales, 2), 'num' => count($ventas), 'unidades' => $units, 'combustible' => round($fuel, 2),
                         'costo_estandar' => round($std, 2), 'ticket' => count($ventas) ? round($sales / count($ventas), 2) : 0],
            'compras' => ['total' => round($purchases, 2), 'num' => $nPurch],
            'resultado' => ['utilidad' => round($sales - $std - $fuel, 2), 'flujo' => round($sales - $purchases - $fuel, 2)],
            'flujo' => ['producido' => (float) $prod['neta'], 'desperdicio' => (float) $prod['desperdicio'], 'cargado' => $loaded,
                        'vendido_camion' => $fromTruck, 'vendido_directo' => $direct,
                        'en_planta' => array_sum(array_column($plant, 'planta')), 'en_camiones' => array_sum(array_column($plant, 'en_camiones'))],
            'diario' => $daily,
            'por_zona' => $porZona, 'por_vendedor' => $porVendedor,
            'por_insumo' => $porInsumo, 'proveedores' => $proveedores, 'ultimas_compras' => $ultimasCompras,
            'planta' => $plant, 'camiones' => Inventory::trucks(),
        ];
    }

    // ------------------------------------------------------------------
    // Reporte de ventas y compras (admin y contabilidad)
    // ------------------------------------------------------------------
    public static function sales(): array
    {
        Auth::require('admin', 'contabilidad');
        return self::salesData(self::filters());
    }

    private static function salesData(array $q, ?int $limit = 1000): array
    {
        $where = 'v.fecha BETWEEN ? AND ?'; $p = [$q['desde'], $q['hasta']];
        if ($q['vendedor_id']) { $where .= ' AND v.vendedor_id = ?'; $p[] = $q['vendedor_id']; }
        if ($q['camion_id'])   { $where .= ' AND v.camion_id = ?';   $p[] = $q['camion_id']; }
        if ($q['zona_id'])     { $where .= ' AND vd.zona_id = ?';    $p[] = $q['zona_id']; }
        $costs = Inventory::costMap();

        $rows = Database::all("SELECT v.id, v.fecha, v.creado_en, v.cliente, v.producto_id, p.nombre producto, v.cantidad, v.precio_unitario, v.total, v.combustible,
                                      v.camion_id, c.codigo camion, v.vendedor_id, vd.codigo vendedor_codigo, vd.nombre vendedor, z.nombre zona, u.nombre registrado_por, v.notas
                               FROM ventas v JOIN productos p ON p.id = v.producto_id
                               LEFT JOIN camiones c ON c.id = v.camion_id LEFT JOIN vendedores vd ON vd.id = v.vendedor_id
                               LEFT JOIN zonas z ON z.id = vd.zona_id LEFT JOIN usuarios u ON u.id = v.usuario_id
                               WHERE $where ORDER BY v.fecha DESC, v.id DESC", $p);
        $rows = numeric_rows($rows, ['id', 'cantidad', 'precio_unitario', 'total', 'combustible', 'producto_id', 'camion_id', 'vendedor_id']);

        $sel = []; $zones = []; $prod = []; $days = []; $clients = [];
        $tot = ['ventas' => 0, 'unidades' => 0, 'ingresos' => 0, 'combustible' => 0, 'costo' => 0, 'utilidad' => 0];
        foreach ($rows as &$r) {
            $r['vendedor'] ??= 'Venta directa';
            $r['zona'] ??= 'Venta directa';
            $r['costo'] = round($r['cantidad'] * ($costs[$r['producto_id']] ?? 0), 2);
            $r['utilidad'] = round($r['total'] - $r['costo'] - $r['combustible'], 2);
            foreach (['ventas' => 1, 'unidades' => $r['cantidad'], 'ingresos' => $r['total'], 'combustible' => $r['combustible'], 'costo' => $r['costo'], 'utilidad' => $r['utilidad']] as $k => $v) $tot[$k] += $v;

            $k = $r['vendedor_id'] ?? 0;
            $sel[$k] ??= ['vendedor_id' => $k, 'codigo' => $r['vendedor_codigo'] ?? '', 'vendedor' => $r['vendedor'], 'zona' => $r['zona'], 'camiones' => [],
                          'ventas' => 0, 'unidades' => 0, 'ingresos' => 0, 'combustible' => 0, 'costo' => 0, 'utilidad' => 0, 'clientes' => [], 'dias' => [], 'ultima' => $r['fecha']];
            $s = &$sel[$k];
            $s['ventas']++; $s['unidades'] += $r['cantidad']; $s['ingresos'] += $r['total']; $s['combustible'] += $r['combustible'];
            $s['costo'] += $r['costo']; $s['utilidad'] += $r['utilidad'];
            if ($r['camion']) $s['camiones'][$r['camion']] = true;
            if ($r['cliente'] !== '') $s['clientes'][mb_strtolower($r['cliente'])] = true;
            $s['dias'][$r['fecha']] = true;
            unset($s);

            $zk = $r['zona'];
            $zones[$zk] ??= ['zona' => $zk, 'ventas' => 0, 'unidades' => 0, 'ingresos' => 0, 'utilidad' => 0, 'vendedores' => []];
            $zones[$zk]['ventas']++; $zones[$zk]['unidades'] += $r['cantidad']; $zones[$zk]['ingresos'] += $r['total']; $zones[$zk]['utilidad'] += $r['utilidad'];
            $zones[$zk]['vendedores'][$k] = true;

            $pk = $r['producto_id'];
            $prod[$pk] ??= ['producto' => $r['producto'], 'ventas' => 0, 'unidades' => 0, 'ingresos' => 0, 'costo' => 0, 'utilidad' => 0];
            $prod[$pk]['ventas']++; $prod[$pk]['unidades'] += $r['cantidad']; $prod[$pk]['ingresos'] += $r['total']; $prod[$pk]['costo'] += $r['costo']; $prod[$pk]['utilidad'] += $r['utilidad'];

            $days[$r['fecha']][$zk] = ($days[$r['fecha']][$zk] ?? 0) + $r['total'];

            if ($r['cliente'] !== '') {
                $ck = mb_strtolower($r['cliente']);
                $clients[$ck] ??= ['cliente' => $r['cliente'], 'vendedores' => [], 'ventas' => 0, 'ingresos' => 0, 'ultima' => $r['fecha']];
                $clients[$ck]['ventas']++; $clients[$ck]['ingresos'] += $r['total']; $clients[$ck]['vendedores'][$r['vendedor']] = true;
            }
        }
        unset($r);

        $sum = $tot['ingresos'] ?: 1;
        foreach ($sel as &$s) {
            $s['camiones'] = implode(', ', array_keys($s['camiones']));
            $s['clientes'] = count($s['clientes']);
            $s['dias_activos'] = count($s['dias']); unset($s['dias']);
            $s['ticket_promedio'] = round($s['ingresos'] / max(1, $s['ventas']), 2);
            $s['participacion'] = round($s['ingresos'] / $sum * 100, 1);
            $s['margen'] = $s['ingresos'] > 0 ? round($s['utilidad'] / $s['ingresos'] * 100, 1) : 0;
            foreach (['ingresos', 'combustible', 'costo', 'utilidad', 'unidades'] as $f) $s[$f] = round($s[$f], 2);
        }
        unset($s);
        foreach ($zones as &$z) { $z['vendedores'] = count($z['vendedores']); $z['participacion'] = round($z['ingresos'] / $sum * 100, 1); foreach (['ingresos', 'utilidad', 'unidades'] as $f) $z[$f] = round($z[$f], 2); }
        unset($z);
        foreach ($prod as &$x) { $x['precio_promedio'] = round($x['ingresos'] / max(0.001, $x['unidades']), 2); foreach (['ingresos', 'costo', 'utilidad'] as $f) $x[$f] = round($x[$f], 2); }
        unset($x);
        foreach ($clients as &$c) { $c['vendedores'] = implode(', ', array_keys($c['vendedores'])); $c['ingresos'] = round($c['ingresos'], 2); }
        unset($c);
        $byIncome = fn($a, $b) => $b['ingresos'] <=> $a['ingresos'];
        $sel = array_values($sel); usort($sel, $byIncome);
        $zones = array_values($zones); usort($zones, $byIncome);
        $prod = array_values($prod); usort($prod, $byIncome);
        $clients = array_values($clients); usort($clients, $byIncome);
        ksort($days);
        $series = []; foreach ($days as $f => $m) $series[] = ['fecha' => $f, 'por_zona' => array_map(fn($x) => round($x, 2), $m)];
        foreach ($tot as $k => $v) $tot[$k] = round($v, 2);
        $tot['ticket_promedio'] = $tot['ventas'] ? round($tot['ingresos'] / $tot['ventas'], 2) : 0;
        $tot['margen'] = $tot['ingresos'] > 0 ? round($tot['utilidad'] / $tot['ingresos'] * 100, 1) : 0;

        // Compras del periodo (no dependen de vendedor/zona)
        $pp = [$q['desde'], $q['hasta']];
        $compras = numeric_rows(Database::all('SELECT e.fecha, e.proveedor, e.tipo, e.cantidad, e.costo_unitario, e.total, e.notas, u.nombre registrado_por
                                               FROM entradas e LEFT JOIN usuarios u ON u.id = e.usuario_id WHERE e.fecha BETWEEN ? AND ? ORDER BY e.fecha DESC, e.id DESC', $pp),
                                  ['cantidad', 'costo_unitario', 'total']);
        $comprasPorTipo = numeric_rows(Database::all('SELECT tipo, COUNT(*) compras, SUM(cantidad) cantidad, SUM(total) total FROM entradas WHERE fecha BETWEEN ? AND ? GROUP BY tipo ORDER BY total DESC', $pp), ['compras', 'cantidad', 'total']);

        return ['periodo' => $q, 'totales' => $tot, 'por_vendedor' => $sel, 'por_zona' => $zones, 'por_producto' => $prod,
                'diario' => $series, 'clientes' => array_slice($clients, 0, 20), 'detalle' => $limit ? array_slice($rows, 0, $limit) : $rows, 'total_registros' => count($rows),
                'compras' => ['total' => round(array_sum(array_column($compras, 'total')), 2), 'num' => count($compras), 'por_tipo' => $comprasPorTipo, 'detalle' => $limit ? array_slice($compras, 0, $limit) : $compras]];
    }

    /** Libro de Excel con varias hojas para contabilidad. */
    public static function excel(): never
    {
        Auth::require('admin', 'contabilidad');
        $q = self::filters();
        $d = self::salesData($q, null);   // el Excel lleva todas las filas
        $all = $d['detalle'];
        $fmt = fn($s) => date('d/m/Y', strtotime($s));
        $periodo = 'Periodo: ' . $fmt($q['desde']) . ' al ' . $fmt($q['hasta']);
        if ($q['zona_id']) $periodo .= ' · Zona: ' . Database::value('SELECT nombre FROM zonas WHERE id = ?', [$q['zona_id']]);
        if ($q['vendedor_id']) $periodo .= ' · Vendedor: ' . Database::value('SELECT nombre FROM vendedores WHERE id = ?', [$q['vendedor_id']]);
        $periodo .= ' · Generado el ' . date('d/m/Y H:i');
        $t = $d['totales'];

        $x = new Xlsx();
        $x->sheet('Resumen', 'AguaControl · Resumen de ventas y compras', [['Concepto', 'text', false, 34], ['Valor', 'money', false, 18]], [
            ['Ingresos por ventas', $t['ingresos']],
            ['Número de ventas', $t['ventas']],
            ['Unidades vendidas', $t['unidades']],
            ['Ticket promedio', $t['ticket_promedio']],
            ['Combustible de envíos', $t['combustible']],
            ['Costo estándar de lo vendido', $t['costo']],
            ['Utilidad estimada', $t['utilidad']],
            ['Compras de insumos', $d['compras']['total']],
            ['Flujo (ventas − compras − combustible)', round($t['ingresos'] - $d['compras']['total'] - $t['combustible'], 2)],
        ], $periodo);
        $x->sheet('Ventas', 'Detalle de ventas', [
            ['Fecha', 'date', false, 12], ['Hora', 'text', false, 8], ['Zona', 'text'], ['Código', 'text', false, 9], ['Vendedor', 'text'], ['Camión', 'text', false, 10],
            ['Cliente', 'text'], ['Producto', 'text'], ['Cantidad', 'num', true, 11], ['Precio unitario', 'money', false, 14], ['Total', 'money', true, 13],
            ['Combustible', 'money', true, 13], ['Costo estándar', 'money', true, 14], ['Utilidad', 'money', true, 13], ['Registrado por', 'text'], ['Notas', 'text', false, 30],
        ], array_map(fn($r) => [$r['fecha'], substr((string) $r['creado_en'], 11, 5), $r['zona'], $r['vendedor_codigo'] ?? '', $r['vendedor'], $r['camion'] ?? 'Planta',
            $r['cliente'], $r['producto'], $r['cantidad'], $r['precio_unitario'], $r['total'], $r['combustible'], $r['costo'], $r['utilidad'], $r['registrado_por'] ?? '', $r['notas']], $all), $periodo);
        $x->sheet('Por vendedor', 'Ventas por vendedor', [
            ['Código', 'text', false, 9], ['Vendedor', 'text'], ['Zona', 'text'], ['Camión', 'text'], ['Ventas', 'int', true], ['Unidades', 'num', true], ['Ingresos', 'money', true],
            ['Ticket promedio', 'money'], ['Clientes', 'int'], ['Días con ventas', 'int'], ['Combustible', 'money', true], ['Utilidad', 'money', true], ['Margen %', 'num'], ['Participación %', 'num'],
        ], array_map(fn($s) => [$s['codigo'], $s['vendedor'], $s['zona'], $s['camiones'], $s['ventas'], $s['unidades'], $s['ingresos'], $s['ticket_promedio'],
            $s['clientes'], $s['dias_activos'], $s['combustible'], $s['utilidad'], $s['margen'], $s['participacion']], $d['por_vendedor']), $periodo);
        $x->sheet('Por zona', 'Ventas por zona', [['Zona', 'text'], ['Vendedores', 'int'], ['Ventas', 'int', true], ['Unidades', 'num', true], ['Ingresos', 'money', true], ['Utilidad', 'money', true], ['Participación %', 'num']],
            array_map(fn($z) => [$z['zona'], $z['vendedores'], $z['ventas'], $z['unidades'], $z['ingresos'], $z['utilidad'], $z['participacion']], $d['por_zona']), $periodo);
        $x->sheet('Por producto', 'Ventas por producto', [['Producto', 'text'], ['Ventas', 'int', true], ['Unidades', 'num', true], ['Precio promedio', 'money'], ['Ingresos', 'money', true], ['Costo estándar', 'money', true], ['Utilidad', 'money', true]],
            array_map(fn($p) => [$p['producto'], $p['ventas'], $p['unidades'], $p['precio_promedio'], $p['ingresos'], $p['costo'], $p['utilidad']], $d['por_producto']), $periodo);
        $x->sheet('Compras', 'Compras de insumos', [['Fecha', 'date', false, 12], ['Proveedor', 'text'], ['Insumo', 'text'], ['Cantidad', 'num', true], ['Costo unitario', 'money'], ['Total', 'money', true], ['Registrado por', 'text'], ['Notas', 'text', false, 30]],
            array_map(fn($c) => [$c['fecha'], $c['proveedor'], $c['tipo'], $c['cantidad'], $c['costo_unitario'], $c['total'], $c['registrado_por'] ?? '', $c['notas']], $d['compras']['detalle']), $periodo);
        $x->download('aguacontrol-reporte-' . $q['desde'] . '_' . $q['hasta'] . '.xlsx');
    }
}
