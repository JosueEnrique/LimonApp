<?php
declare(strict_types=1);

final class CostsController
{
    public static function get(): array
    {
        Auth::require('admin');
        $c = Inventory::costs();
        $tabla = [];
        foreach (Inventory::products() as $p) $tabla[] = ['producto' => $p['nombre'], 'litros' => $p['litros']] + Inventory::unitCost($p, $c);
        return ['costos' => $c, 'tabla' => $tabla];
    }

    public static function save(): array
    {
        Auth::require('admin');
        $v = Validator::of(request_body());
        foreach (DEFAULT_COSTS as $k => $_) $v->num($k, 0, $k === 'margen' ? 1000 : 10000, true, null, "El valor de “{$k}”");
        $d = $v->validate();
        $pdo = Database::pdo();
        $pdo->beginTransaction();
        foreach ($d as $k => $val) {
            Database::run('DELETE FROM costos WHERE clave = ?', [$k]);
            Database::insert('costos', ['clave' => $k, 'valor' => $val]);
        }
        $pdo->commit();
        return ['ok' => true, 'message' => 'Costos guardados.'];
    }
}
