<?php
declare(strict_types=1);

final class BackupController
{
    private const TABLES = ['entradas', 'produccion', 'cargas', 'ventas'];

    public static function export(): never
    {
        Auth::require('admin');
        $out = ['app' => 'AguaControl', 'version' => 2, 'exportado' => now_local(),
                'productos' => Database::all('SELECT * FROM productos'),
                'camiones' => Database::all('SELECT * FROM camiones'),
                'zonas' => Database::all('SELECT * FROM zonas'),
                'vendedores' => Database::all('SELECT * FROM vendedores'),
                'usuarios' => Database::all('SELECT id, username, nombre, rol, zona_id, activo FROM usuarios'),
                'costos' => Inventory::costs()];
        foreach (self::TABLES as $t) $out[$t] = Database::all("SELECT * FROM $t ORDER BY id");
        header('Content-Disposition: attachment; filename="aguacontrol-respaldo-' . today() . '.json"');
        json_out($out);
    }

    public static function csv(): never
    {
        Auth::require('admin', 'contabilidad');
        $t = Validator::of($_GET)->enum('tabla', self::TABLES, true, 'La tabla')->validate()['tabla'];
        $sql = [
            'entradas'   => "SELECT m.fecha, m.proveedor, m.tipo, m.cantidad, m.costo_unitario, m.total, m.notas, u.nombre usuario FROM entradas m LEFT JOIN usuarios u ON u.id = m.usuario_id",
            'produccion' => "SELECT m.fecha, m.turno, p.nombre producto, m.cantidad, m.desperdicio, m.lote, m.notas, u.nombre operario FROM produccion m JOIN productos p ON p.id = m.producto_id LEFT JOIN usuarios u ON u.id = m.usuario_id",
            'cargas'     => "SELECT m.fecha, z.nombre zona, vd.nombre vendedor, c.codigo camion, p.nombre producto, m.cantidad, m.notas, u.nombre registrado_por FROM cargas m JOIN productos p ON p.id = m.producto_id JOIN camiones c ON c.id = m.camion_id LEFT JOIN vendedores vd ON vd.id = m.vendedor_id LEFT JOIN zonas z ON z.id = vd.zona_id LEFT JOIN usuarios u ON u.id = m.usuario_id",
            'ventas'     => "SELECT m.fecha, z.nombre zona, vd.codigo codigo_vendedor, vd.nombre vendedor, c.codigo camion, m.cliente, p.nombre producto, m.cantidad, m.precio_unitario, m.total, m.combustible, u.nombre registrado_por, m.notas FROM ventas m JOIN productos p ON p.id = m.producto_id LEFT JOIN camiones c ON c.id = m.camion_id LEFT JOIN vendedores vd ON vd.id = m.vendedor_id LEFT JOIN zonas z ON z.id = vd.zona_id LEFT JOIN usuarios u ON u.id = m.usuario_id",
        ][$t] . ' ORDER BY m.fecha, m.id';
        $rows = Database::all($sql);
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="aguacontrol-' . $t . '-' . today() . '.csv"');
        $f = fopen('php://output', 'w');
        fwrite($f, "\xEF\xBB\xBF");
        if ($rows) fputcsv($f, array_keys($rows[0]), ';');
        // Evita que Excel/Calc ejecute fórmulas escritas en un campo de texto (inyección CSV).
        foreach ($rows as $r) fputcsv($f, array_map(fn($v) => is_string($v) && preg_match('/^[=+\-@\t\r]/', $v) && !is_numeric($v) ? "'" . $v : $v, $r), ';');
        exit;
    }

    /** Importa un respaldo de esta versión o del AguaControl anterior (HTML). */
    public static function import(): array
    {
        $me = Auth::require('admin');
        $in = request_body();
        $data = $in['datos'] ?? null;
        $mode = ($in['modo'] ?? 'agregar') === 'reemplazar' ? 'reemplazar' : 'agregar';
        if (!is_array($data)) throw new HttpError(422, 'El archivo no tiene el formato de un respaldo de AguaControl.');
        $legacy = isset($data['salidas']) && !isset($data['version']);
        $ventasKey = $legacy ? 'salidas' : 'ventas';
        foreach (['entradas', 'produccion', $ventasKey] as $k) if (isset($data[$k]) && !is_array($data[$k])) throw new HttpError(422, "La sección “{$k}” del respaldo no es válida.");

        $products = [];
        foreach (Inventory::products(false) as $p) {
            $products[self::norm($p['nombre'])] = $p['id'];
            $products[(string) $p['id']] = $p['id'];
        }
        $findProduct = fn($r) => $products[self::norm((string) ($r['producto'] ?? ''))] ?? $products[(string) ($r['producto_id'] ?? '')] ?? null;
        $trucks = [];
        foreach (Database::all('SELECT id, codigo, placa FROM camiones') as $c) { $trucks[$c['codigo']] = (int) $c['id']; if ($c['placa']) $trucks[$c['placa']] = (int) $c['id']; }

        $pdo = Database::pdo();
        $pdo->beginTransaction();
        try {
            if ($mode === 'reemplazar') foreach (array_reverse(self::TABLES) as $t) Database::run("DELETE FROM $t");
            $n = ['entradas' => 0, 'produccion' => 0, 'cargas' => 0, 'ventas' => 0, 'omitidos' => 0];
            $okDate = fn($d) => is_string($d) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $d);
            $num = fn($v) => is_numeric($v) ? (float) $v : null;
            $txt = fn($v, $max) => mb_substr(trim((string) ($v ?? '')), 0, $max);

            foreach ($data['entradas'] ?? [] as $r) {
                $q = $num($r['cantidad'] ?? null); $u = $num($r['unitario'] ?? $r['costo_unitario'] ?? null);
                if (!$okDate($r['fecha'] ?? null) || !$q || $q <= 0 || $u === null || $u < 0) { $n['omitidos']++; continue; }
                $tipo = in_array($r['tipo'] ?? '', INSUMOS, true) ? $r['tipo'] : (self::matchInsumo((string) ($r['tipo'] ?? '')) ?? 'Otro');
                Database::insert('entradas', ['fecha' => $r['fecha'], 'proveedor' => $txt($r['proveedor'] ?? '', 80), 'tipo' => $tipo, 'cantidad' => $q,
                    'costo_unitario' => $u, 'total' => round($q * $u, 2), 'notas' => $txt($r['notas'] ?? '', 500), 'usuario_id' => $me['id']]);
                $n['entradas']++;
            }
            foreach ($data['produccion'] ?? [] as $r) {
                $pid = $findProduct($r); $q = $num($r['cantidad'] ?? null); $w = $num($r['desperdicio'] ?? 0) ?? 0;
                if (!$pid || !$okDate($r['fecha'] ?? null) || !$q || $q <= 0 || $w < 0 || $w > $q) { $n['omitidos']++; continue; }
                Database::insert('produccion', ['fecha' => $r['fecha'], 'turno' => in_array($r['turno'] ?? '', TURNOS, true) ? $r['turno'] : 'Mañana',
                    'producto_id' => $pid, 'cantidad' => $q, 'desperdicio' => $w, 'lote' => $txt($r['lote'] ?? '', 40), 'notas' => $txt($r['notas'] ?? '', 500), 'usuario_id' => $me['id']]);
                $n['produccion']++;
            }
            foreach ($data['cargas'] ?? [] as $r) {
                $pid = $findProduct($r); $q = $num($r['cantidad'] ?? null);
                if (!$pid || !$okDate($r['fecha'] ?? null) || !$q || $q <= 0) { $n['omitidos']++; continue; }
                $cid = $trucks[strtoupper(trim((string) ($r['camion'] ?? '')))] ?? (isset($r['camion_id']) && in_array((int) $r['camion_id'], $trucks, true) ? (int) $r['camion_id'] : null) ?? self::importTruck($trucks);
                $vend = Database::value('SELECT id FROM vendedores WHERE camion_id = ? ORDER BY activo DESC LIMIT 1', [$cid]) ?: null;
                Database::insert('cargas', ['fecha' => $r['fecha'], 'vendedor_id' => $vend, 'camion_id' => $cid, 'producto_id' => $pid, 'cantidad' => $q,
                    'notas' => $txt(trim(($r['notas'] ?? '') . (isset($r['responsable']) && $legacy ? ' · Responsable: ' . $r['responsable'] : '')), 500), 'usuario_id' => $me['id']]);
                $n['cargas']++;
            }
            foreach ($data[$ventasKey] ?? [] as $r) {
                $pid = $findProduct($r); $q = $num($r['cantidad'] ?? null); $u = $num($r['unitario'] ?? $r['precio_unitario'] ?? null); $fuel = $num($r['combustible'] ?? 0) ?? 0;
                if (!$pid || !$okDate($r['fecha'] ?? null) || !$q || $q <= 0 || $u === null || $u < 0 || $fuel < 0) { $n['omitidos']++; continue; }
                $cid = !$legacy && isset($r['camion_id']) && in_array((int) $r['camion_id'], $trucks, true) ? (int) $r['camion_id'] : null;
                $vid = !$legacy && !empty($r['vendedor_id']) && Database::value('SELECT 1 FROM vendedores WHERE id = ?', [(int) $r['vendedor_id']]) ? (int) $r['vendedor_id'] : null;
                Database::insert('ventas', ['fecha' => $r['fecha'], 'cliente' => $txt($r['cliente'] ?? '', 80), 'producto_id' => $pid, 'cantidad' => $q,
                    'precio_unitario' => $u, 'total' => round($q * $u, 2), 'combustible' => $fuel, 'camion_id' => $cid, 'vendedor_id' => $vid, 'usuario_id' => $me['id'], 'notas' => $txt($r['notas'] ?? '', 500)]);
                $n['ventas']++;
            }
            if (isset($data['costos']) && is_array($data['costos'])) {
                $map = $legacy ? ['manoObra' => 'mano_obra', 'botella600' => 'b600', 'botella1l' => 'b1l'] : [];
                foreach ($data['costos'] as $k => $v) {
                    $k = $map[$k] ?? $k;
                    if (array_key_exists($k, DEFAULT_COSTS) && is_numeric($v) && $v >= 0 && $v <= 10000) {
                        Database::run('DELETE FROM costos WHERE clave = ?', [$k]);
                        Database::insert('costos', ['clave' => $k, 'valor' => (float) $v]);
                    }
                }
            }
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
        $msg = sprintf('Importado: %d entradas, %d producciones, %d cargas, %d ventas.', $n['entradas'], $n['produccion'], $n['cargas'], $n['ventas'])
             . ($n['omitidos'] ? " Se omitieron {$n['omitidos']} registros con datos inválidos." : '');
        return ['ok' => true, 'message' => $msg, 'resultado' => $n];
    }

    public static function wipe(): array
    {
        Auth::require('admin');
        if ((request_body()['confirmar'] ?? '') !== 'BORRAR') throw new HttpError(422, 'Escribe BORRAR para confirmar.');
        $pdo = Database::pdo();
        $pdo->beginTransaction();
        foreach (array_reverse(self::TABLES) as $t) Database::run("DELETE FROM $t");
        $pdo->commit();
        return ['ok' => true, 'message' => 'Se borraron todos los movimientos. Usuarios, camiones y costos se conservaron.'];
    }

    private static function norm(string $s): string
    {
        $s = mb_strtolower(trim($s));
        $s = strtr($s, ['á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u']);
        return preg_replace('/[^a-z0-9]/', '', $s);
    }

    private static function matchInsumo(string $t): ?string
    {
        foreach (INSUMOS as $i) if (self::norm($i) === self::norm($t)) return $i;
        return null;
    }

    private static function importTruck(array &$trucks): int
    {
        if (isset($trucks['IMPORTADO'])) return $trucks['IMPORTADO'];
        $id = Database::insert('camiones', ['codigo' => 'IMPORTADO', 'placa' => '', 'descripcion' => 'Cargas importadas del sistema anterior', 'activo' => 0]);
        return $trucks['IMPORTADO'] = $id;
    }
}
