<?php
declare(strict_types=1);

final class TrucksController
{
    public static function list(): array
    {
        Auth::require('admin', 'despacho', 'contabilidad');
        $concat = Database::driver() === 'mysql' ? "GROUP_CONCAT(nombre SEPARATOR ', ')" : "GROUP_CONCAT(nombre, ', ')";
        $rows = Database::all("SELECT c.*, (SELECT $concat FROM vendedores v WHERE v.camion_id = c.id AND v.activo = 1) AS asignado,
                               (SELECT z.nombre FROM vendedores v JOIN zonas z ON z.id = v.zona_id WHERE v.camion_id = c.id AND v.activo = 1 LIMIT 1) AS zona,
                               (SELECT COUNT(*) FROM cargas WHERE camion_id = c.id) AS cargas,
                               (SELECT COUNT(*) FROM ventas WHERE camion_id = c.id) AS ventas
                               FROM camiones c ORDER BY c.activo DESC, c.codigo");
        return ['items' => numeric_rows($rows, ['id', 'activo', 'cargas', 'ventas']), 'stock' => Inventory::trucks(), 'siguiente' => self::nextCode()];
    }

    private static function input(?int $id): array
    {
        $in = request_body();
        $in['codigo'] = strtoupper(trim((string) ($in['codigo'] ?? '')));
        $in['placa'] = strtoupper(trim((string) ($in['placa'] ?? '')));
        if ($in['codigo'] === '') $in['codigo'] = self::nextCode();
        $d = Validator::of($in)
            ->str('codigo', 20, true, 'El código', '/^[A-Z0-9-]{2,20}$/', 'El código solo admite letras, números y guiones (ej. CAM-04).')
            ->str('placa', 20, false, 'La placa', '/^[A-Z0-9 -]+$/', 'La placa solo admite letras, números, espacios y guiones.')
            ->str('descripcion', 120, false, 'La descripción')->bool('activo')->validate();
        if (!array_key_exists('activo', $in)) $d['activo'] = 1;
        if (Database::value('SELECT 1 FROM camiones WHERE codigo = ? AND id <> ?', [$d['codigo'], $id ?? 0])) throw new HttpError(422, 'Ya existe un camión con ese código.', ['errors' => ['codigo' => 'Repetido.']]);
        if ($d['placa'] !== '' && Database::value('SELECT 1 FROM camiones WHERE placa = ? AND id <> ?', [$d['placa'], $id ?? 0])) throw new HttpError(422, 'Ya existe un camión con esa placa.', ['errors' => ['placa' => 'Repetida.']]);
        return $d;
    }

    public static function create(): array
    {
        Auth::require('admin');
        $id = Database::insert('camiones', self::input(null));
        return ['ok' => true, 'id' => $id, 'message' => 'Camión agregado.'];
    }

    public static function update(int $id): array
    {
        Auth::require('admin');
        if (!Database::value('SELECT 1 FROM camiones WHERE id = ?', [$id])) throw new HttpError(404, 'El camión no existe.');
        $d = self::input($id);
        Database::update('camiones', $id, $d);
        if (!$d['activo']) Database::run('UPDATE vendedores SET camion_id = NULL WHERE camion_id = ?', [$id]);
        return ['ok' => true, 'message' => 'Camión actualizado.'];
    }

    public static function delete(int $id): array
    {
        Auth::require('admin');
        if (!Database::value('SELECT 1 FROM camiones WHERE id = ?', [$id])) throw new HttpError(404, 'El camión no existe.');
        Database::run('UPDATE vendedores SET camion_id = NULL WHERE camion_id = ?', [$id]);
        $used = (int) Database::value('SELECT (SELECT COUNT(*) FROM cargas WHERE camion_id = ?) + (SELECT COUNT(*) FROM ventas WHERE camion_id = ?)', [$id, $id]);
        if ($used) {
            Database::update('camiones', $id, ['activo' => 0]);
            return ['ok' => true, 'message' => 'El camión tiene movimientos, así que se desactivó (se conserva su historial).'];
        }
        Database::run('DELETE FROM camiones WHERE id = ?', [$id]);
        return ['ok' => true, 'message' => 'Camión eliminado.'];
    }

    private static function nextCode(): string
    {
        $n = 0;
        foreach (Database::all("SELECT codigo FROM camiones WHERE codigo LIKE 'CAM-%'") as $r) $n = max($n, (int) substr($r['codigo'], 4));
        return sprintf('CAM-%02d', $n + 1);
    }
}
