<?php
declare(strict_types=1);

/**
 * Entradas, producción, cargas y ventas: listar con filtros, crear, editar y borrar.
 *
 * Quién ve y quién escribe:
 *   entradas    ve: admin, contabilidad          escribe: admin
 *   produccion  ve: admin, supervisor (todo)      escribe: admin, supervisor (un solo supervisor activo)
 *   cargas      ve: admin, despacho (su zona)     escribe: admin, despacho
 *   ventas      ve: admin, contabilidad, despacho (su zona)   escribe: admin, despacho
 * Fuera del admin, cada quien solo corrige lo que registró el mismo día.
 */
final class MovementsController
{
    private const TYPES = [
        'entradas'   => ['read' => ['admin', 'contabilidad'], 'write' => ['admin']],
        'produccion' => ['read' => ['admin', 'supervisor'], 'write' => ['admin', 'supervisor']],
        'cargas'     => ['read' => ['admin', 'despacho'], 'write' => ['admin', 'despacho']],
        'ventas'     => ['read' => ['admin', 'contabilidad', 'despacho'], 'write' => ['admin', 'despacho']],
    ];

    private const SELECTS = [
        'entradas'   => "SELECT m.*, u.nombre AS usuario FROM entradas m LEFT JOIN usuarios u ON u.id = m.usuario_id",
        'produccion' => "SELECT m.*, p.nombre AS producto, u.nombre AS usuario FROM produccion m
                         JOIN productos p ON p.id = m.producto_id LEFT JOIN usuarios u ON u.id = m.usuario_id",
        'cargas'     => "SELECT m.*, p.nombre AS producto, c.codigo AS camion, vd.nombre AS vendedor, vd.codigo AS vendedor_codigo,
                                z.nombre AS zona, vd.zona_id, u.nombre AS usuario
                         FROM cargas m JOIN productos p ON p.id = m.producto_id JOIN camiones c ON c.id = m.camion_id
                         LEFT JOIN vendedores vd ON vd.id = m.vendedor_id LEFT JOIN zonas z ON z.id = vd.zona_id
                         LEFT JOIN usuarios u ON u.id = m.usuario_id",
        'ventas'     => "SELECT m.*, p.nombre AS producto, c.codigo AS camion, vd.nombre AS vendedor, vd.codigo AS vendedor_codigo,
                                z.nombre AS zona, vd.zona_id, u.nombre AS usuario
                         FROM ventas m JOIN productos p ON p.id = m.producto_id LEFT JOIN camiones c ON c.id = m.camion_id
                         LEFT JOIN vendedores vd ON vd.id = m.vendedor_id LEFT JOIN zonas z ON z.id = vd.zona_id
                         LEFT JOIN usuarios u ON u.id = m.usuario_id",
    ];

    private const NUMERIC = ['id', 'cantidad', 'costo_unitario', 'total', 'desperdicio', 'precio_unitario', 'combustible',
                             'producto_id', 'camion_id', 'usuario_id', 'vendedor_id', 'zona_id'];

    private static function def(string $type): array
    {
        if (!isset(self::TYPES[$type])) throw new HttpError(404, 'Recurso no encontrado.');
        return self::TYPES[$type];
    }

    public static function list(string $type): array
    {
        $def = self::def($type);
        $u = Auth::require(...$def['read']);
        $q = Validator::of($_GET)->date('desde', false, 'La fecha inicial')->date('hasta', false, 'La fecha final')
            ->str('q', 60)->int('limit', false)->int('vendedor_id', false)->int('camion_id', false)->int('zona_id', false)
            ->enum('turno', TURNOS, false, 'El turno')->validate();

        $where = []; $p = [];
        if ($u['rol'] === 'despacho')   { $where[] = 'vd.zona_id = ?'; $p[] = $u['zona_id'] ?? 0; }
        if ($q['desde']) { $where[] = 'm.fecha >= ?'; $p[] = $q['desde']; }
        if ($q['hasta']) { $where[] = 'm.fecha <= ?'; $p[] = $q['hasta']; }
        if ($type === 'produccion' && $q['turno']) { $where[] = 'm.turno = ?'; $p[] = $q['turno']; }
        if (in_array($type, ['ventas', 'cargas'], true)) {
            if ($q['vendedor_id']) { $where[] = 'm.vendedor_id = ?'; $p[] = $q['vendedor_id']; }
            if ($q['camion_id'])   { $where[] = 'm.camion_id = ?';   $p[] = $q['camion_id']; }
            if ($q['zona_id'])     { $where[] = 'vd.zona_id = ?';    $p[] = $q['zona_id']; }
        }
        if ($q['q'] !== '') {
            $like = '%' . $q['q'] . '%';
            $cols = match ($type) {
                'entradas'   => ['m.proveedor', 'm.tipo', 'm.notas'],
                'produccion' => ['p.nombre', 'm.lote', 'm.notas', 'm.turno'],
                'cargas'     => ['p.nombre', 'c.codigo', 'vd.nombre', 'm.notas'],
                'ventas'     => ['p.nombre', 'm.cliente', 'c.codigo', 'vd.nombre', 'm.notas'],
            };
            $where[] = '(' . implode(' OR ', array_map(fn($c) => "$c LIKE ?", $cols)) . ')';
            array_push($p, ...array_fill(0, count($cols), $like));
        }
        $limit = min($q['limit'] ?? 300, 2000);
        $sql = self::SELECTS[$type] . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . " ORDER BY m.fecha DESC, m.id DESC LIMIT $limit";
        $rows = numeric_rows(Database::all($sql, $p), self::NUMERIC);
        foreach ($rows as &$r) $r['editable'] = self::canModify($u, $r, $def);
        return ['items' => $rows];
    }

    public static function create(string $type): array
    {
        $def = self::def($type);
        $u = Auth::require(...$def['write']);
        $data = self::validated($type, request_body(), $u, null);
        $data['usuario_id'] = $u['id'];
        $id = Database::insert($type, $data);
        return ['ok' => true, 'id' => $id, 'message' => 'Registro guardado.'];
    }

    public static function update(string $type, int $id): array
    {
        $def = self::def($type);
        $u = Auth::require(...$def['write']);
        $old = self::findForChange($type, $id, $u, $def);
        $data = self::validated($type, request_body(), $u, $old);
        Database::update($type, $id, $data);
        return ['ok' => true, 'id' => $id, 'message' => 'Registro actualizado.'];
    }

    public static function delete(string $type, int $id): array
    {
        $def = self::def($type);
        $u = Auth::require(...$def['write']);
        self::findForChange($type, $id, $u, $def);
        Database::run("DELETE FROM $type WHERE id = ?", [$id]);
        return ['ok' => true, 'message' => 'Registro eliminado.'];
    }

    // ------------------------------------------------------------------

    private static function findForChange(string $type, int $id, array $u, array $def): array
    {
        $extra = in_array($type, ['ventas', 'cargas'], true) ? ', (SELECT zona_id FROM vendedores WHERE id = m.vendedor_id) AS zona_id' : '';
        $row = Database::one("SELECT m.*$extra FROM $type m WHERE m.id = ?", [$id]);
        if (!$row) throw new HttpError(404, 'El registro ya no existe.');
        if (!self::canModify($u, $row, $def)) {
            throw new HttpError(403, 'Solo puedes cambiar lo que registraste hoy. Para otros cambios, avisa al administrador.');
        }
        return $row;
    }

    private static function canModify(array $u, array $row, array $def): bool
    {
        if ($u['rol'] === 'admin') return true;
        if (!in_array($u['rol'], $def['write'], true)) return false;
        if ((int) ($row['usuario_id'] ?? 0) !== $u['id']) return false;
        if ($u['rol'] === 'despacho' && (int) ($row['zona_id'] ?? 0) !== (int) $u['zona_id']) return false;
        $limit = date('Y-m-d', strtotime('-' . (int) app_config('edit_window_days') . ' days'));
        return substr((string) $row['creado_en'], 0, 10) >= $limit;
    }

    /** Vendedor activo, de la zona del encargado (si es despacho) y con camión activo. */
    private static function seller(?int $id, array $u, bool $required): ?array
    {
        if (!$id) {
            if ($required) throw new HttpError(422, 'Elige el vendedor.', ['errors' => ['vendedor_id' => 'Obligatorio.']]);
            return null;
        }
        $v = Database::one('SELECT v.*, z.nombre zona, c.activo AS camion_activo FROM vendedores v JOIN zonas z ON z.id = v.zona_id
                            LEFT JOIN camiones c ON c.id = v.camion_id WHERE v.id = ?', [$id]);
        if (!$v || !$v['activo']) throw new HttpError(422, 'Ese vendedor no existe o está inactivo.', ['errors' => ['vendedor_id' => 'No válido.']]);
        if ($u['rol'] === 'despacho' && (int) $v['zona_id'] !== (int) $u['zona_id']) {
            throw new HttpError(403, "Ese vendedor es de la zona {$v['zona']}. Solo puedes trabajar con vendedores de tu zona.");
        }
        if (!$v['camion_id'] || !$v['camion_activo']) {
            throw new HttpError(422, "{$v['nombre']} no tiene un camión activo asignado. Pide al administrador que le asigne uno.", ['errors' => ['vendedor_id' => 'Sin camión.']]);
        }
        $v['camion_id'] = (int) $v['camion_id'];
        return $v;
    }

    private static function validated(string $type, array $in, array $u, ?array $old): array
    {
        $v = Validator::of($in);
        $force = $u['rol'] === 'admin' && !empty($in['forzar']);
        $isDispatch = $u['rol'] === 'despacho';

        switch ($type) {
            case 'entradas':
                $d = $v->date('fecha')->str('proveedor', 80, false, 'El proveedor')->enum('tipo', INSUMOS, true, 'El tipo de insumo')
                       ->num('cantidad', 0.001, 1e7, true, null, 'La cantidad', 3)
                       ->num('costo_unitario', 0, 1e6, true, null, 'El costo unitario')
                       ->str('notas', 500, false, 'Las notas')->validate();
                $d['total'] = round($d['cantidad'] * $d['costo_unitario'], 2);
                return $d;

            case 'produccion':
                $d = $v->date('fecha')->enum('turno', TURNOS, true, 'El turno')->exists('producto_id', 'productos', true, 'El producto')
                       ->num('cantidad', 1, 1e6, true, null, 'La cantidad producida', 3)
                       ->num('desperdicio', 0, 1e6, false, 0, 'El desperdicio', 3)
                       ->str('lote', 40, false, 'El lote')->str('notas', 500, false, 'Las observaciones')->validate();
                if ($d['desperdicio'] > $d['cantidad']) throw new HttpError(422, 'El desperdicio no puede ser mayor que la cantidad producida.', ['errors' => ['desperdicio' => 'Mayor que lo producido.']]);
                return $d;

            case 'cargas':
                $v->date('fecha')->int('vendedor_id', $isDispatch, 'El vendedor')->exists('producto_id', 'productos', true, 'El producto')
                  ->num('cantidad', 1, 1e6, true, null, 'La cantidad cargada', 3)->str('notas', 500, false, 'Las observaciones');
                if (!$isDispatch) $v->exists('camion_id', 'camiones', false, 'El camión');
                $d = $v->validate();
                $seller = self::seller($d['vendedor_id'], $u, $isDispatch);
                if ($seller) {
                    $d['camion_id'] = ($old && (int) $old['vendedor_id'] === (int) $seller['id']) ? (int) $old['camion_id'] : $seller['camion_id'];
                } elseif (!$d['camion_id']) {
                    throw new HttpError(422, 'Elige el vendedor o el camión que se carga.', ['errors' => ['vendedor_id' => 'Obligatorio.']]);
                }
                $disp = Inventory::availablePlant($d['producto_id']);
                if ($old && (int) $old['producto_id'] === $d['producto_id']) $disp += (float) $old['cantidad'];
                if ($d['cantidad'] > $disp + 1e-9 && !$force) self::stockError($disp, $d['cantidad'], 'en planta', $u);
                return $d;

            case 'ventas':
                $v->date('fecha')->str('cliente', 80, false, 'El cliente')->exists('producto_id', 'productos', true, 'El producto')
                  ->num('cantidad', 0.001, 1e6, true, null, 'La cantidad vendida', 3)
                  ->num('precio_unitario', 0, 1e5, true, null, 'El precio unitario')
                  ->num('combustible', 0, 1e4, false, 0, 'El combustible', 2)
                  ->str('notas', 500, false, 'Las notas')->int('vendedor_id', $isDispatch, 'El vendedor');
                if (!$isDispatch) $v->exists('camion_id', 'camiones', false, 'El camión');
                $d = $v->validate();
                $seller = self::seller($d['vendedor_id'], $u, $isDispatch);
                if ($seller) {
                    // La venta de un vendedor sale de su camión.
                    $d['camion_id'] = ($old && (int) $old['vendedor_id'] === (int) $seller['id'] && $old['camion_id']) ? (int) $old['camion_id'] : $seller['camion_id'];
                } else {
                    $d['camion_id'] ??= null; // sin vendedor: venta directa (planta) o desde el camión indicado
                }
                $d['total'] = round($d['cantidad'] * $d['precio_unitario'], 2);

                $sameSource = $old && (int) $old['producto_id'] === $d['producto_id'] && (int) $old['camion_id'] === (int) $d['camion_id'];
                $disp = $d['camion_id'] ? Inventory::availableTruck($d['camion_id'], $d['producto_id']) : Inventory::availablePlant($d['producto_id']);
                if ($sameSource) $disp += (float) $old['cantidad'];
                if ($d['cantidad'] > $disp + 1e-9 && !$force) self::stockError($disp, $d['cantidad'], $d['camion_id'] ? 'en el camión' : 'en planta', $u);
                return $d;
        }
        throw new HttpError(404, 'Recurso no encontrado.');
    }

    private static function stockError(float $disp, float $want, string $where, array $u): never
    {
        $fmt = fn($n) => rtrim(rtrim(number_format($n, 3, '.', ''), '0'), '.');
        $msg = sprintf('Solo hay %s unidades disponibles %s y quieres registrar %s.', $fmt(max(0, $disp)), $where, $fmt($want));
        if ($u['rol'] !== 'admin') $msg .= ' Revisa la cantidad o avisa al administrador.';
        throw new HttpError(409, $msg, ['code' => 'stock', 'disponible' => $disp, 'puede_forzar' => $u['rol'] === 'admin']);
    }
}
