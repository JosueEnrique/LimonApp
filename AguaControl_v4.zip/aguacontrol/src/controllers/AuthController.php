<?php
declare(strict_types=1);

final class AuthController
{
    public static function me(): array
    {
        return ['user' => Auth::user(), 'csrf' => Auth::csrf(), 'roles' => ROLES];
    }

    public static function login(): array
    {
        $d = Validator::of(request_body())
            ->str('username', 64, true, 'El usuario')
            ->str('password', 200, true, 'La contraseña')
            ->validate();
        $user = Auth::attempt($d['username'], (string) request_body()['password']);
        return ['ok' => true, 'user' => $user, 'csrf' => Auth::csrf()];
    }

    public static function logout(): array
    {
        Auth::logout();
        return ['ok' => true];
    }

    /** Cambiar la contraseña propia (pide la actual). */
    public static function password(): array
    {
        $u = Auth::require();
        $in = request_body();
        $min = app_config('security')['min_password'];
        $d = Validator::of($in)->str('actual', 200, true, 'La contraseña actual')->str('nueva', 200, true, 'La nueva contraseña')->validate();
        $hash = Database::value('SELECT password_hash FROM usuarios WHERE id = ?', [$u['id']]);
        if (!password_verify((string) $in['actual'], (string) $hash)) throw new HttpError(422, 'La contraseña actual no es correcta.', ['errors' => ['actual' => 'Incorrecta.']]);
        self::checkStrength((string) $in['nueva'], $u['username'], $min);
        Database::update('usuarios', $u['id'], ['password_hash' => password_hash((string) $in['nueva'], PASSWORD_DEFAULT)]);
        return ['ok' => true, 'message' => 'Contraseña actualizada.'];
    }

    public static function checkStrength(string $pw, string $username, int $min): void
    {
        $err = null;
        if (mb_strlen($pw) < $min) $err = "La contraseña debe tener al menos $min caracteres.";
        elseif (!preg_match('/[A-Za-z]/', $pw) || !preg_match('/\d/', $pw)) $err = 'La contraseña debe combinar letras y números.';
        elseif (mb_stripos($pw, $username) !== false) $err = 'La contraseña no puede contener el nombre de usuario.';
        if ($err) throw new HttpError(422, $err, ['errors' => ['nueva' => $err, 'password' => $err]]);
    }
}

final class CatalogController
{
    /** Vendedores activos con su zona y camión. Despacho solo recibe los de su zona. */
    public static function sellers(array $u, bool $activeOnly = true): array
    {
        $where = $activeOnly ? ['v.activo = 1'] : []; $p = [];
        if ($u['rol'] === 'despacho') { $where[] = 'v.zona_id = ?'; $p[] = $u['zona_id'] ?? 0; }
        $rows = Database::all('SELECT v.id, v.codigo, v.nombre, v.telefono, v.zona_id, z.nombre AS zona, v.camion_id, c.codigo AS camion, v.activo
                               FROM vendedores v JOIN zonas z ON z.id = v.zona_id LEFT JOIN camiones c ON c.id = v.camion_id AND c.activo = 1'
                               . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY z.nombre, v.nombre', $p);
        return numeric_rows($rows, ['id', 'zona_id', 'camion_id', 'activo']);
    }

    public static function index(): array
    {
        $u = Auth::require();
        $out = [
            'productos' => Inventory::products(),
            'turnos'    => TURNOS,
            'insumos'   => INSUMOS,
            'zonas'     => numeric_rows(Database::all('SELECT id, nombre FROM zonas WHERE activo = 1 ORDER BY id'), ['id']),
            'hoy'       => today(),
        ];
        if ($u['rol'] !== 'supervisor') {
            $out['vendedores'] = self::sellers($u);
            $out['camiones'] = numeric_rows(Database::all('SELECT id, codigo, placa, descripcion FROM camiones WHERE activo = 1 ORDER BY codigo'), ['id']);
            $c = Inventory::costs();
            foreach ($out['productos'] as &$p) $p['precio_sugerido'] = Inventory::unitCost($p, $c)['precio_sugerido'];
        }
        return $out;
    }

    /** Resumen del día para la pantalla de cada rol. */
    public static function myDay(): array
    {
        $u = Auth::require();
        $hoy = today();
        switch ($u['rol']) {
            case 'supervisor':
                $q = Validator::of($_GET)->date('fecha', false)->enum('turno', TURNOS, false)->validate();
                $fecha = $q['fecha'] ?? $hoy;
                $p = [$fecha]; $t = '';
                if ($q['turno']) { $t = ' AND m.turno = ?'; $p[] = $q['turno']; }
                $rows = Database::all("SELECT p.nombre producto, m.turno, SUM(m.cantidad) cantidad, SUM(m.desperdicio) desperdicio, COUNT(*) registros
                                       FROM produccion m JOIN productos p ON p.id = m.producto_id
                                       WHERE m.fecha = ?$t GROUP BY p.id, p.nombre, m.turno ORDER BY m.turno, p.id", $p);
                return ['fecha' => $fecha, 'turno' => $q['turno'], 'resumen' => numeric_rows($rows, ['cantidad', 'desperdicio', 'registros'])];
            case 'despacho':
                $z = $u['zona_id'] ?? 0;
                $cargas = Database::all('SELECT vd.nombre vendedor, c.codigo camion, p.nombre producto, SUM(m.cantidad) cantidad FROM cargas m
                                         JOIN productos p ON p.id = m.producto_id JOIN camiones c ON c.id = m.camion_id JOIN vendedores vd ON vd.id = m.vendedor_id
                                         WHERE vd.zona_id = ? AND m.fecha = ? GROUP BY vd.id, vd.nombre, c.codigo, p.id, p.nombre ORDER BY vd.nombre', [$z, $hoy]);
                $ventas = Database::one('SELECT COUNT(*) ventas, COALESCE(SUM(m.cantidad),0) unidades, COALESCE(SUM(m.total),0) ingresos FROM ventas m
                                         JOIN vendedores vd ON vd.id = m.vendedor_id WHERE vd.zona_id = ? AND m.fecha = ?', [$z, $hoy]);
                $trucks = [];
                foreach (self::sellers($u) as $s) {
                    if (!$s['camion_id']) continue;
                    $t = Inventory::trucks($s['camion_id'])[0] ?? null;
                    if ($t) $trucks[] = $t + ['vendedor' => $s['nombre'], 'vendedor_id' => $s['id']];
                }
                return ['cargas' => numeric_rows($cargas, ['cantidad']), 'ventas' => array_map('floatval', $ventas), 'planta' => Inventory::plant(), 'camiones' => $trucks];
            default:
                return [];
        }
    }
}
