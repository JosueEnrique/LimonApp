<?php
declare(strict_types=1);

/**
 * Actualiza una base SQLite de la versión 2 a la 3 sin perder datos:
 *  - Los usuarios con rol "vendedor" dejan de ser cuentas y pasan a la tabla vendedores
 *    (conservan su camión y todas sus ventas).
 *  - "operador" pasa a "supervisor" (Supervisor de producción).
 *  - Se crean las zonas y se asigna zona a los encargados de despacho.
 * Antes de cambiar nada guarda una copia del archivo en data/.
 */
final class Migrator
{
    /** Zona inicial para los datos que ya existían (se puede cambiar después en el sistema). */
    private const VENDOR_ZONE = ['juan' => 'Planta', 'pedro' => 'Planta'];
    private const DISPATCH_ZONE = ['despacho1' => 'Planta', 'despacho2' => 'San Miguel'];

    public static function sqliteV2ToV3(PDO $pdo, string $dbFile): void
    {
        $pdo->exec('PRAGMA wal_checkpoint(TRUNCATE)');
        $backup = dirname($dbFile) . '/respaldo-antes-de-v3-' . date('Ymd-His') . '.sqlite';
        if (!copy($dbFile, $backup)) throw new RuntimeException('No se pudo crear la copia de seguridad antes de actualizar la base.');

        $schema = file_get_contents(__DIR__ . '/../database/schema.sqlite.sql');
        $ddl = function (string $table) use ($schema): string {
            if (!preg_match('/CREATE TABLE ' . $table . ' \(.*?\n\);/s', $schema, $m)) throw new RuntimeException("Falta la tabla $table en el esquema.");
            return $m[0];
        };

        $pdo->exec('PRAGMA foreign_keys = OFF');
        $pdo->exec('PRAGMA legacy_alter_table = ON'); // al renombrar, no reescribe las referencias de otras tablas
        $pdo->beginTransaction();
        try {
            $now = now_local();
            $pdo->exec($ddl('meta'));
            $pdo->exec($ddl('zonas'));
            $st = $pdo->prepare('INSERT INTO zonas (nombre, creado_en) VALUES (?, ?)');
            foreach (DEFAULT_ZONES as $z) $st->execute([$z, $now]);
            $zone = fn(string $name) => (int) $pdo->query('SELECT id FROM zonas WHERE nombre = ' . $pdo->quote($name))->fetchColumn();

            // 1) Vendedores: de usuarios a su propia tabla
            $pdo->exec($ddl('vendedores'));
            $pdo->exec('CREATE TEMP TABLE vmap (old_id INTEGER PRIMARY KEY, new_id INTEGER NOT NULL)');
            $old = $pdo->query("SELECT id, username, nombre, camion_id, activo, creado_en FROM usuarios WHERE rol = 'vendedor' ORDER BY id")->fetchAll();
            $ins = $pdo->prepare('INSERT INTO vendedores (codigo, nombre, zona_id, camion_id, activo, creado_en) VALUES (?, ?, ?, ?, ?, ?)');
            $map = $pdo->prepare('INSERT INTO vmap (old_id, new_id) VALUES (?, ?)');
            foreach ($old as $i => $v) {
                $ins->execute([sprintf('V-%02d', $i + 1), $v['nombre'], $zone(self::VENDOR_ZONE[$v['username']] ?? 'Planta'), $v['camion_id'], $v['activo'], $v['creado_en']]);
                $map->execute([$v['id'], $pdo->lastInsertId()]);
            }

            // 2) Usuarios sin vendedores, con roles nuevos y zona para despacho
            $pdo->exec('ALTER TABLE usuarios RENAME TO usuarios_v2');
            $pdo->exec($ddl('usuarios'));
            $pdo->exec("INSERT INTO usuarios (id, username, nombre, rol, password_hash, zona_id, activo, ultimo_acceso, creado_en)
                        SELECT id, username, nombre, CASE rol WHEN 'operador' THEN 'supervisor' ELSE rol END, password_hash, NULL, activo, ultimo_acceso, creado_en
                        FROM usuarios_v2 WHERE rol <> 'vendedor'");
            $planta = $zone('Planta');
            $pdo->exec("UPDATE usuarios SET zona_id = $planta WHERE rol = 'despacho'");
            foreach (self::DISPATCH_ZONE as $user => $z) {
                $pdo->prepare("UPDATE usuarios SET zona_id = ? WHERE username = ? AND rol = 'despacho'")->execute([$zone($z), $user]);
            }

            // 3) Ventas: el vendedor antiguo (usuario) se convierte en el vendedor nuevo
            $pdo->exec('ALTER TABLE ventas RENAME TO ventas_v2');
            $pdo->exec($ddl('ventas'));
            $pdo->exec('INSERT INTO ventas (id, fecha, cliente, producto_id, cantidad, precio_unitario, total, combustible, camion_id, vendedor_id, usuario_id, notas, creado_en)
                        SELECT v.id, v.fecha, v.cliente, v.producto_id, v.cantidad, v.precio_unitario, v.total, v.combustible, v.camion_id,
                               m.new_id, CASE WHEN m.new_id IS NULL THEN v.vendedor_id END, v.notas, v.creado_en
                        FROM ventas_v2 v LEFT JOIN vmap m ON m.old_id = v.vendedor_id');

            // 4) Cargas: se ligan al vendedor que tenía ese camión
            $pdo->exec('ALTER TABLE cargas RENAME TO cargas_v2');
            $pdo->exec($ddl('cargas'));
            $pdo->exec('INSERT INTO cargas (id, fecha, vendedor_id, camion_id, producto_id, cantidad, notas, usuario_id, creado_en)
                        SELECT c.id, c.fecha, (SELECT id FROM vendedores WHERE camion_id = c.camion_id ORDER BY activo DESC, id LIMIT 1),
                               c.camion_id, c.producto_id, c.cantidad, c.notas, c.usuario_id, c.creado_en
                        FROM cargas_v2 c');

            // Referencias de entradas/producción a vendedores antiguos (no deberían existir) se vacían.
            foreach (['entradas', 'produccion'] as $t) $pdo->exec("UPDATE $t SET usuario_id = NULL WHERE usuario_id IN (SELECT old_id FROM vmap)");

            foreach (['usuarios_v2', 'ventas_v2', 'cargas_v2'] as $t) $pdo->exec("DROP TABLE $t");
            $pdo->exec('DROP TABLE vmap');
            preg_match_all('/^CREATE INDEX .*;$/m', $schema, $idx);
            foreach ($idx[0] as $sql) $pdo->exec(str_replace('CREATE INDEX', 'CREATE INDEX IF NOT EXISTS', $sql));
            $pdo->prepare('INSERT INTO meta (clave, valor) VALUES (?, ?)')->execute(['schema_version', '3']);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            $pdo->exec('PRAGMA legacy_alter_table = OFF');
            $pdo->exec('PRAGMA foreign_keys = ON');
            throw new RuntimeException('No se pudo actualizar la base a la versión 3 (no se cambió nada; copia en ' . basename($backup) . '): ' . $e->getMessage(), 0, $e);
        }
        $pdo->exec('PRAGMA legacy_alter_table = OFF');
        $pdo->exec('PRAGMA foreign_keys = ON');
        $bad = $pdo->query('PRAGMA foreign_key_check')->fetchAll();
        if ($bad) error_log('[AguaControl] Migración v3: referencias inconsistentes: ' . json_encode($bad));
    }
}
