<?php
declare(strict_types=1);

/**
 * Cómo se mueve el producto:
 *   Producción (− desperdicio)  →  PLANTA
 *   Carga de camión             →  PLANTA → CAMIÓN
 *   Venta con camión            →  sale del CAMIÓN
 *   Venta sin camión (directa)  →  sale de la PLANTA
 */
final class Inventory
{
    public static function costs(): array
    {
        $rows = Database::all('SELECT clave, valor FROM costos');
        $c = DEFAULT_COSTS;
        foreach ($rows as $r) $c[$r['clave']] = (float) $r['valor'];
        return $c;
    }

    public static function products(bool $activeOnly = true): array
    {
        $rows = Database::all('SELECT id, nombre, clave, litros, activo FROM productos' . ($activeOnly ? ' WHERE activo = 1' : '') . ' ORDER BY id');
        return numeric_rows($rows, ['id', 'litros', 'activo']);
    }

    /** Costo estimado de una unidad y precio sugerido según el margen. */
    public static function unitCost(array $product, ?array $c = null): array
    {
        $c ??= self::costs();
        $porLitro = $c['agua'] + $c['mano_obra'] + $c['energia'] + $c['mantenimiento'];
        $insumo = $c['tapon'] + $c['etiqueta'];
        $litros = (float) $product['litros'];

        switch ($product['clave']) {
            case 'b600':     $pack = $c['b600'] + $insumo; break;
            case 'b1l':      $pack = $c['b1l'] + $insumo; break;
            case 'galon':    $pack = $c['galon'] + $insumo; break;
            case 'garrafon': $pack = $c['garrafon'] + $insumo; break;
            case 'fardo':    $pack = 25 * ($c['b600'] + $insumo) + $c['empaque']; break;
            default:         $pack = $insumo;
        }
        $base = $porLitro * $litros;
        $total = $pack + $base;
        return ['envase' => round($pack, 4), 'operacion' => round($base, 4), 'costo' => round($total, 4),
                'precio_sugerido' => round($total * (1 + $c['margen'] / 100), 2)];
    }

    public static function costMap(): array
    {
        $c = self::costs(); $map = [];
        foreach (self::products(false) as $p) $map[$p['id']] = self::unitCost($p, $c)['costo'];
        return $map;
    }

    /** Existencias en planta por producto. */
    public static function plant(): array
    {
        $prod  = self::sumBy('SELECT producto_id k, SUM(cantidad - desperdicio) v FROM produccion GROUP BY producto_id');
        $carg  = self::sumBy('SELECT producto_id k, SUM(cantidad) v FROM cargas GROUP BY producto_id');
        $vDir  = self::sumBy('SELECT producto_id k, SUM(cantidad) v FROM ventas WHERE camion_id IS NULL GROUP BY producto_id');
        $vTot  = self::sumBy('SELECT producto_id k, SUM(cantidad) v FROM ventas GROUP BY producto_id');
        $costs = self::costMap();
        $out = [];
        foreach (self::products(false) as $p) {
            $id = $p['id'];
            $stock = ($prod[$id] ?? 0) - ($carg[$id] ?? 0) - ($vDir[$id] ?? 0);
            $enCamiones = ($carg[$id] ?? 0) - (($vTot[$id] ?? 0) - ($vDir[$id] ?? 0));
            if (!$p['activo'] && !$stock && !$enCamiones) continue;
            $out[] = ['producto_id' => $id, 'producto' => $p['nombre'], 'producido' => round($prod[$id] ?? 0, 3),
                      'cargado' => round($carg[$id] ?? 0, 3), 'vendido' => round($vTot[$id] ?? 0, 3),
                      'planta' => round($stock, 3), 'en_camiones' => round($enCamiones, 3),
                      'valor' => round(max(0, $stock + $enCamiones) * $costs[$id], 2)];
        }
        return $out;
    }

    /** Existencias por camión y producto. */
    public static function trucks(?int $camionId = null): array
    {
        $where = $camionId ? 'WHERE camion_id = ?' : 'WHERE camion_id IS NOT NULL';
        $p = $camionId ? [$camionId] : [];
        $carg = Database::all("SELECT camion_id, producto_id, SUM(cantidad) v FROM cargas $where GROUP BY camion_id, producto_id", $p);
        $vent = Database::all("SELECT camion_id, producto_id, SUM(cantidad) v FROM ventas $where GROUP BY camion_id, producto_id", $p);
        $m = [];
        foreach ($carg as $r) $m[$r['camion_id']][$r['producto_id']]['cargado'] = (float) $r['v'];
        foreach ($vent as $r) $m[$r['camion_id']][$r['producto_id']]['vendido'] = (float) $r['v'];

        $names = array_column(self::products(false), 'nombre', 'id');
        $trucks = Database::all('SELECT c.id, c.codigo, c.placa, c.activo, v.nombre AS asignado, z.nombre AS zona
                                 FROM camiones c LEFT JOIN vendedores v ON v.camion_id = c.id AND v.activo = 1 LEFT JOIN zonas z ON z.id = v.zona_id'
                                 . ($camionId ? ' WHERE c.id = ?' : '') . ' ORDER BY c.codigo', $p);
        $out = [];
        foreach ($trucks as $t) {
            $id = (int) $t['id'];
            $items = [];
            foreach ($m[$id] ?? [] as $pid => $v) {
                $c = $v['cargado'] ?? 0; $s = $v['vendido'] ?? 0;
                $items[] = ['producto_id' => (int) $pid, 'producto' => $names[$pid] ?? '?', 'cargado' => round($c, 3),
                            'vendido' => round($s, 3), 'disponible' => round($c - $s, 3)];
            }
            $key = $id;
            if (!isset($out[$key])) $out[$key] = ['id' => $id, 'codigo' => $t['codigo'], 'placa' => $t['placa'], 'activo' => (int) $t['activo'],
                                                  'asignados' => [], 'zona' => $t['zona'], 'productos' => $items];
            if ($t['asignado']) $out[$key]['asignados'][] = $t['asignado'];
        }
        return array_values($out);
    }

    public static function availablePlant(int $productId): float
    {
        foreach (self::plant() as $r) if ($r['producto_id'] === $productId) return (float) $r['planta'];
        return 0;
    }

    public static function availableTruck(int $camionId, int $productId): float
    {
        $c = (float) Database::value('SELECT COALESCE(SUM(cantidad),0) FROM cargas WHERE camion_id = ? AND producto_id = ?', [$camionId, $productId]);
        $v = (float) Database::value('SELECT COALESCE(SUM(cantidad),0) FROM ventas WHERE camion_id = ? AND producto_id = ?', [$camionId, $productId]);
        return round($c - $v, 3);
    }

    private static function sumBy(string $sql): array
    {
        $out = [];
        foreach (Database::all($sql) as $r) $out[(int) $r['k']] = (float) $r['v'];
        return $out;
    }
}
