<?php
declare(strict_types=1);

/** Conexión PDO + creación automática del esquema y datos iniciales. */
final class Database
{
    private static ?PDO $pdo = null;

    public static function pdo(): PDO
    {
        if (self::$pdo) return self::$pdo;
        $c = app_config('db');

        if ($c['driver'] === 'mysql') {
            $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $c['host'], $c['port'], $c['database']);
            $pdo = new PDO($dsn, $c['username'], $c['password']);
        } else {
            $dir = dirname($c['sqlite']);
            if (!is_dir($dir)) mkdir($dir, 0775, true);
            $pdo = new PDO('sqlite:' . $c['sqlite']);
            $pdo->exec('PRAGMA foreign_keys = ON');
            $pdo->exec('PRAGMA journal_mode = WAL');
        }
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        self::$pdo = $pdo;

        if ($c['driver'] === 'sqlite') self::migrateSqlite($pdo);
        require_once __DIR__ . '/DataPatches.php';
        DataPatches::apply($pdo);
        return $pdo;
    }

    public static function driver(): string { return app_config('db')['driver']; }

    private static function migrateSqlite(PDO $pdo): void
    {
        $exists = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='usuarios'")->fetchColumn();
        if (!$exists) {
            $file = __DIR__ . '/../database/schema.sqlite.sql';
            if (!is_file($file)) throw new RuntimeException("Falta el archivo database/schema.sqlite.sql");
            // Todo o nada: si algo falla, no queda una base a medio crear.
            $pdo->beginTransaction();
            try { $pdo->exec(file_get_contents($file)); $pdo->commit(); }
            catch (Throwable $e) { $pdo->rollBack(); throw $e; }
        } elseif (!$pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='meta'")->fetchColumn()) {
            // Base creada con la versión 2 (vendedores como usuarios): se actualiza conservando todo.
            require_once __DIR__ . '/Migrator.php';
            Migrator::sqliteV2ToV3($pdo, app_config('db')['sqlite']);
        }
        // Si las tablas existen pero no hay usuarios (instalación interrumpida), carga los datos iniciales.
        if ((int) $pdo->query('SELECT COUNT(*) FROM usuarios')->fetchColumn() === 0) {
            require_once __DIR__ . '/../database/seed.php';
            seed_database($pdo);
        }
    }

    // ---- atajos ----
    public static function all(string $sql, array $p = []): array
    {
        $st = self::pdo()->prepare($sql); $st->execute($p); return $st->fetchAll();
    }
    public static function one(string $sql, array $p = []): ?array
    {
        $st = self::pdo()->prepare($sql); $st->execute($p); $r = $st->fetch(); return $r ?: null;
    }
    public static function value(string $sql, array $p = [])
    {
        $st = self::pdo()->prepare($sql); $st->execute($p); return $st->fetchColumn();
    }
    public static function run(string $sql, array $p = []): int
    {
        $st = self::pdo()->prepare($sql); $st->execute($p); return $st->rowCount();
    }
    public static function insert(string $table, array $data): int
    {
        if (!in_array($table, ['costos', 'productos'], true) && !isset($data['creado_en'])) $data['creado_en'] = now_local();
        $cols = array_keys($data);
        $sql = sprintf('INSERT INTO %s (%s) VALUES (%s)', $table, implode(',', $cols), implode(',', array_map(fn($c) => ':' . $c, $cols)));
        self::run($sql, $data);
        return (int) self::pdo()->lastInsertId();
    }
    public static function update(string $table, int $id, array $data): void
    {
        $set = implode(',', array_map(fn($c) => "$c = :$c", array_keys($data)));
        self::run("UPDATE $table SET $set WHERE id = :__id", $data + ['__id' => $id]);
    }
}
