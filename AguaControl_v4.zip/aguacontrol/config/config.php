<?php
/**
 * Configuración de AguaControl.
 *
 * Por defecto usa SQLite (un archivo en /data), que no necesita instalar nada.
 * Para usar MySQL de XAMPP: cambia 'driver' a 'mysql', crea la base con
 * database/schema.mysql.sql y llena los datos de conexión.
 */
return [
    'app_name' => 'AguaControl',
    'timezone' => 'America/El_Salvador',

    'db' => [
        'driver'   => 'sqlite',                       // 'sqlite' o 'mysql'
        'sqlite'   => __DIR__ . '/../data/aguacontrol.sqlite',
        'host'     => '127.0.0.1',
        'port'     => 3306,
        'database' => 'aguacontrol',
        'username' => 'root',
        'password' => '',
    ],

    'session' => [
        'name'         => 'AGUACONTROLSID',
        'idle_minutes' => 480,   // cierra la sesión tras 8 horas sin actividad
    ],

    'security' => [
        'max_login_attempts' => 5,    // intentos fallidos permitidos...
        'lockout_minutes'    => 10,   // ...dentro de esta ventana de tiempo
        'min_password'       => 8,
    ],

    // Días hacia atrás que un usuario que no es admin puede editar o borrar sus propios registros (0 = solo hoy).
    'edit_window_days' => 0,
];
