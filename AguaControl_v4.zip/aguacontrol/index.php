<?php
declare(strict_types=1);
require __DIR__ . '/src/bootstrap.php';

// Crea la base (SQLite) en la primera visita y comprueba que la conexión funcione.
try { Database::pdo(); $dbError = null; }
catch (Throwable $e) { error_log('[AguaControl] ' . $e->getMessage()); $dbError = 'No se pudo conectar a la base de datos. Revisa config/config.php.'; }

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Cache-Control: no-cache');
$nonce = base64_encode(random_bytes(16));
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'nonce-$nonce' https://unpkg.com; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");

/**
 * Cada archivo CSS/JS se pide con su fecha de modificación (?v=...). Así, al actualizar el sistema,
 * el navegador descarga lo nuevo en lugar de mezclar archivos viejos guardados en caché.
 */
function asset(string $path): string
{
    $file = __DIR__ . '/' . $path;
    return $path . '?v=' . (is_file($file) ? filemtime($file) : '0');
}
// Mapa de módulos: también versiona los import entre archivos JS (ui.js, api.js, vistas…).
$modules = [];
foreach (array_merge(glob(__DIR__ . '/assets/js/*.js'), glob(__DIR__ . '/assets/js/views/*.js')) as $f) {
    $rel = substr($f, strlen(__DIR__) + 1);
    $rel = str_replace('\\', '/', $rel);
    $modules['./' . $rel] = './' . asset($rel);
}
$importMap = json_encode(['imports' => $modules], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="color-scheme" content="light dark">
  <meta name="theme-color" content="#0a6fa6">
  <title>Agua El Limón · AguaControl</title>
  <link rel="icon" type="image/png" href="<?= asset('assets/img/favicon.png') ?>">
  <link rel="apple-touch-icon" href="<?= asset('assets/img/apple-touch-icon.png') ?>">
  <link rel="preload" href="assets/fonts/archivo-latin-standard-normal.woff2" as="font" type="font/woff2" crossorigin>
  <link rel="stylesheet" href="<?= asset('assets/css/tokens.css') ?>">
  <link rel="stylesheet" href="<?= asset('assets/css/base.css') ?>">
  <link rel="stylesheet" href="<?= asset('assets/css/components.css') ?>">
  <script type="importmap" nonce="<?= $nonce ?>"><?= $importMap ?></script>
  <script type="module" src="<?= asset('assets/js/main.js') ?>"></script>
</head>
<body>

<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <symbol id="i-drop" viewBox="0 0 24 24"><path d="M12 2.7S5 10.4 5 15a7 7 0 0 0 14 0c0-4.6-7-12.3-7-12.3Z"/></symbol>
  <symbol id="i-home" viewBox="0 0 24 24"><path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></symbol>
  <symbol id="i-in" viewBox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/></symbol>
  <symbol id="i-factory" viewBox="0 0 24 24"><path d="M3 21V10l6 4V10l6 4V5h4v16zM7 17h2m4 0h2"/></symbol>
  <symbol id="i-cart" viewBox="0 0 24 24"><path d="M3 4h2l2.4 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.5L21 8H6m4 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2Zm8 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"/></symbol>
  <symbol id="i-truck" viewBox="0 0 24 24"><path d="M2 6h11v10H2zM13 9h4l4 4v3h-8M6 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm11 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/></symbol>
  <symbol id="i-chart" viewBox="0 0 24 24"><path d="M4 20V10m6 10V4m6 16v-7m4 7H2"/></symbol>
  <symbol id="i-users" viewBox="0 0 24 24"><path d="M16 20v-1.5a3.5 3.5 0 0 0-3.5-3.5h-5A3.5 3.5 0 0 0 4 18.5V20M10 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm10 9v-1.5a3.5 3.5 0 0 0-2.6-3.4M15.5 4.2a3.5 3.5 0 0 1 0 6.6"/></symbol>
  <symbol id="i-cash" viewBox="0 0 24 24"><path d="M3 6h18v12H3zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM6 9v.01M18 15v.01"/></symbol>
  <symbol id="i-db" viewBox="0 0 24 24"><path d="M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3Zm0 0v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></symbol>
  <symbol id="i-seller" viewBox="0 0 24 24"><path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 9a7 7 0 0 1 14 0M17 3l2 2 3-3"/></symbol>
  <symbol id="i-key" viewBox="0 0 24 24"><path d="M15.5 7.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM9.9 9.6 3 16.5V20h3.5l1-1v-2h2v-2h2l1.2-1.2"/></symbol>
  <symbol id="i-logout" viewBox="0 0 24 24"><path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 17l5-5-5-5m5 5H3"/></symbol>
  <symbol id="i-chev" viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></symbol>
  <symbol id="i-menu" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></symbol>
  <symbol id="i-plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
  <symbol id="i-x" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></symbol>
  <symbol id="i-eye" viewBox="0 0 24 24"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Zm10 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/></symbol>
  <symbol id="i-download" viewBox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4M4 19h16"/></symbol>
  <symbol id="i-bottle" viewBox="0 0 24 24"><path d="M10 2h4v3l1.5 2.5V21a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1V7.5L10 5zM8.5 11h7m-7 6h7"/></symbol>
  <symbol id="i-jug" viewBox="0 0 24 24"><path d="M9 2h6v3h1a3 3 0 0 1 3 3v12a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V8a3 3 0 0 1 3-3h1zM5 12h14"/></symbol>
  <symbol id="i-pack" viewBox="0 0 24 24"><path d="M3 8l9-5 9 5v8l-9 5-9-5zM3 8l9 5 9-5M12 13v8"/></symbol>
</svg>

<section id="login" class="login" aria-labelledby="loginTitle" hidden>
  <picture class="login-watermark" aria-hidden="true">
    <source srcset="<?= asset('assets/img/logo-simbolo-grande.webp') ?>" type="image/webp">
    <img src="<?= asset('assets/img/logo-simbolo-grande.png') ?>" alt="" width="900" height="1239" decoding="async">
  </picture>

  <div class="login-stack">
    <picture>
      <source srcset="<?= asset('assets/img/logo-vertical.webp') ?>" type="image/webp">
      <img class="login-logo" src="<?= asset('assets/img/logo-vertical.png') ?>" alt="Agua El Limón, Cetexsal S.A. de C.V." width="520" height="665" fetchpriority="high">
    </picture>

    <div class="login-card">
      <h1 id="loginTitle">Iniciar sesión</h1>
      <p class="login-sub">Inventario, producción y ventas</p>
      <?php if ($dbError): ?><div class="form-alert" role="alert"><?= htmlspecialchars($dbError) ?></div><?php endif; ?>
      <div id="loginError" class="form-alert" role="alert" hidden></div>
      <form id="loginForm" novalidate>
        <label class="field"><span>Usuario</span>
          <input name="username" autocomplete="username" autocapitalize="none" spellcheck="false" required maxlength="64">
        </label>
        <label class="field"><span>Contraseña</span>
          <span class="pw-wrap">
            <input name="password" type="password" autocomplete="current-password" required maxlength="200">
            <button type="button" data-toggle-pw aria-label="Mostrar contraseña"><svg class="icon"><use href="#i-eye"/></svg></button>
          </span>
        </label>
        <button class="btn btn-primary btn-lg btn-block" type="submit">Entrar</button>
      </form>
    </div>

    <p class="login-foot">¿Olvidaste tu contraseña? El administrador puede asignarte una nueva.</p>
  </div>
</section>

<div id="app" class="app" hidden>
  <aside class="sidebar" id="sidebar" aria-label="Menú principal">
    <div class="brand">
      <picture>
        <source srcset="<?= asset('assets/img/logo-horizontal.webp') ?>" type="image/webp">
        <img src="<?= asset('assets/img/logo-horizontal.png') ?>" alt="Agua El Limón" width="480" height="222">
      </picture>
      <small>Inventario, producción y ventas</small>
    </div>
    <div class="who" id="who"></div>
    <nav class="nav" id="nav"></nav>
    <div class="side-note" id="sideNote"></div>
  </aside>

  <div class="main">
    <header class="topbar">
      <button class="btn btn-ghost btn-icon menu-toggle" id="menuToggle" aria-label="Abrir menú" aria-controls="sidebar" aria-expanded="false"><svg class="icon"><use href="#i-menu"/></svg></button>
      <div class="topbar-title"><h1 id="pageTitle">AguaControl</h1><p id="pageSub"></p></div>
      <div class="topbar-right">
        <span class="date-chip" id="todayChip"></span>
        <button class="user-chip" id="userChip" popovertarget="userMenu" aria-label="Menú de usuario">
          <span class="avatar" id="userAvatar"></span>
          <span class="user-meta"><b id="userName"></b><small id="userRole"></small></span>
          <svg class="icon"><use href="#i-chev"/></svg>
        </button>
        <div id="userMenu" class="menu" popover>
          <div class="menu-head"><span class="avatar" id="menuAvatar"></span><div><b id="menuName"></b><small id="menuInfo"></small></div></div>
          <button type="button" id="btnMyPassword"><svg class="icon"><use href="#i-key"/></svg>Cambiar mi contraseña</button>
          <button type="button" id="btnLogout" class="danger"><svg class="icon"><use href="#i-logout"/></svg>Cerrar sesión</button>
        </div>
      </div>
    </header>
    <main id="view" class="content" tabindex="-1"></main>
    <footer class="footer">AguaControl para Agua El Limón. Los datos se guardan en el servidor de la planta.</footer>
  </div>
</div>

<dialog id="dlg" class="dialog" closedby="any" aria-labelledby="dlgTitle">
  <div class="dialog-body">
    <div class="dialog-head">
      <div><h2 id="dlgTitle"></h2><p id="dlgSub"></p></div>
      <button class="btn btn-ghost btn-icon" type="button" data-close aria-label="Cerrar"><svg class="icon"><use href="#i-x"/></svg></button>
    </div>
    <div id="dlgContent"></div>
  </div>
</dialog>

<div class="toasts" id="toasts" role="status" aria-live="polite"></div>

</body>
</html>
