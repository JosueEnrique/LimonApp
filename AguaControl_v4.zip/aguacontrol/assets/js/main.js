// AguaControl · arranque, sesión y navegación por rol
import { api, setCsrf, ApiError } from './api.js';
import { $, $$, esc, icon, initials, avatarColor, formValues, zoneColor } from './utils.js';
import { toast, formDialog, closeDialog } from './ui.js';

// Popover es Baseline reciente: solo carga el polyfill si el navegador no lo trae.
if (!('popover' in HTMLElement.prototype)) {
  import('https://unpkg.com/@oddbird/popover-polyfill@0.5.2/dist/popover.min.js').catch(() => {});
}

/** Rutas: quién puede verlas, cómo se llaman y qué módulo las dibuja. */
const ROUTES = {
  panel:      { roles: ['admin'], group: 'Operación', icon: 'home', title: 'Dashboard', sub: 'Ventas, compras y movimiento del producto', load: () => import('./views/panel.js') },
  produccion: { roles: ['admin', 'supervisor'], group: 'Operación', icon: 'factory', title: 'Producción', sub: 'Producto terminado por turno', load: () => import('./views/produccion.js') },
  cargas:     { roles: ['admin', 'despacho'], group: 'Operación', icon: 'truck', title: 'Carga de camiones', sub: 'Producto que sale de planta hacia cada vendedor', load: () => import('./views/cargas.js') },
  ventas:     { roles: ['admin', 'despacho'], group: 'Operación', icon: 'cart', title: 'Ventas', sub: 'Ventas directas y de ruta', load: () => import('./views/ventas.js') },
  entradas:   { roles: ['admin'], group: 'Operación', icon: 'in', title: 'Compras', sub: 'Materia prima e insumos', load: () => import('./views/movimientos.js') },
  reportes:   { roles: ['admin', 'contabilidad'], group: 'Reportes', icon: 'chart', title: 'Reportes de ventas', sub: 'Por zona, vendedor y producto, con exportación a Excel', load: () => import('./views/reportes.js') },
  vendedores: { roles: ['admin'], group: 'Administración', icon: 'seller', title: 'Vendedores y zonas', sub: 'Vendedores de ruta, su zona y su camión', load: () => import('./views/vendedores.js') },
  camiones:   { roles: ['admin'], group: 'Administración', icon: 'truck', title: 'Camiones', sub: 'Identificación y existencias', load: () => import('./views/camiones.js') },
  usuarios:   { roles: ['admin'], group: 'Administración', icon: 'users', title: 'Usuarios', sub: 'Cuentas que entran al sistema', load: () => import('./views/usuarios.js') },
  costos:     { roles: ['admin'], group: 'Administración', icon: 'cash', title: 'Costos y precios', sub: 'Costo estimado y precio sugerido', load: () => import('./views/costos.js') },
  respaldo:   { roles: ['admin'], group: 'Administración', icon: 'db', title: 'Respaldo y datos', sub: 'Exportar, importar y limpiar', load: () => import('./views/respaldo.js') },
};

// Títulos propios para los roles que solo ven su trabajo.
const ROLE_TITLES = {
  supervisor: { produccion: ['Producción del turno', 'Registra todo lo que sale de la línea en cada turno'] },
  despacho: { cargas: ['Cargar camión', 'Carga producto a los vendedores de tu zona'], ventas: ['Ventas de la ruta', 'Registra lo que vendió cada vendedor de tu zona'] },
  contabilidad: { reportes: ['Reportes de ventas', 'Consulta y exporta a Excel'] },
};
const ROLE_NOTES = {
  admin: 'Tienes acceso a todo el sistema. Descarga un respaldo cada semana.',
  contabilidad: 'Puedes consultar ventas y compras y exportarlas a Excel. No puedes modificar registros.',
  despacho: 'Solo ves a los vendedores de tu zona. Puedes corregir lo que registraste hoy.',
  supervisor: 'Eres la única persona que registra la producción: anota lo de cada turno. Puedes corregir tus registros de hoy.',
};

export const state = { user: null, roles: {}, cat: null };

const allowed = () => Object.entries(ROUTES).filter(([, r]) => r.roles.includes(state.user?.rol)).map(([k]) => k);

export async function loadCatalogs() {
  state.cat = await api('catalogos');
  return state.cat;
}

// ---------------------------------------------------------------- sesión
async function boot() {
  try {
    const me = await api('auth/me');
    setCsrf(me.csrf); state.roles = me.roles;
    if (me.user) await enterApp(me.user); else showLogin();
  } catch (err) {
    showLogin(err.message);
  }
}

function showLogin(message) {
  $('#app').hidden = true; $('#login').hidden = false;
  const box = $('#loginError');
  box.hidden = !message; box.textContent = message || '';
  $('#loginForm [name=username]').focus();
}

async function enterApp(user) {
  state.user = user;
  await loadCatalogs();
  $('#login').hidden = true; $('#app').hidden = false;
  paintUser(); paintNav();
  route();
}

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.currentTarget, btn = $('[type=submit]', form), box = $('#loginError');
  const v = formValues(form);
  if (!v.username.trim() || !v.password) { box.hidden = false; box.textContent = 'Escribe tu usuario y contraseña.'; return; }
  btn.disabled = true; btn.textContent = 'Entrando…';
  try {
    const res = await api('auth/login', { method: 'POST', body: v });
    setCsrf(res.csrf); form.reset(); box.hidden = true;
    location.hash = '';
    await enterApp(res.user);
  } catch (err) {
    box.hidden = false; box.textContent = err.message;
    $('[name=password]', form).select();
  } finally { btn.disabled = false; btn.textContent = 'Entrar'; }
});

$('[data-toggle-pw]').addEventListener('click', (e) => {
  const input = $('#loginForm [name=password]');
  input.type = input.type === 'password' ? 'text' : 'password';
  e.currentTarget.setAttribute('aria-label', input.type === 'password' ? 'Mostrar contraseña' : 'Ocultar contraseña');
});

$('#btnLogout').addEventListener('click', async () => {
  $('#userMenu').hidePopover?.();
  try { await api('auth/logout', { method: 'POST' }); } catch {}
  state.user = null;
  const me = await api('auth/me').catch(() => null);
  if (me) setCsrf(me.csrf);
  history.replaceState(null, '', location.pathname);
  showLogin();
});

$('#btnMyPassword').addEventListener('click', () => {
  $('#userMenu').hidePopover?.();
  formDialog({
    title: 'Cambiar mi contraseña', sub: 'Mínimo 8 caracteres, con letras y números.', submitText: 'Cambiar contraseña',
    fields: [
      { name: 'actual', label: 'Contraseña actual', type: 'password', required: true, full: true, autocomplete: 'current-password' },
      { name: 'nueva', label: 'Nueva contraseña', type: 'password', required: true, full: true, autocomplete: 'new-password', min: undefined },
      { name: 'confirmar', label: 'Repetir nueva contraseña', type: 'password', required: true, full: true, autocomplete: 'new-password' },
    ],
    onSubmit: (v) => {
      if (v.nueva !== v.confirmar) throw new ApiError(422, { error: 'Las contraseñas nuevas no coinciden.', errors: { confirmar: 'No coincide.' } });
      return api('auth/password', { method: 'POST', body: v });
    },
  });
});

window.addEventListener('session-expired', (e) => {
  if (!state.user) return;
  state.user = null; closeDialog();
  api('auth/me').then((me) => setCsrf(me.csrf)).catch(() => {});
  showLogin(e.detail?.message || 'Tu sesión terminó.');
});

// ---------------------------------------------------------- navegación
function paintUser() {
  const u = state.user, color = avatarColor(u.nombre);
  for (const id of ['#userAvatar', '#menuAvatar']) { const a = $(id); a.textContent = initials(u.nombre); a.style.setProperty('--avatar', color); }
  $('#userName').textContent = u.nombre;
  $('#userRole').textContent = state.roles[u.rol] + (u.zona ? `, ${u.zona}` : '');
  $('#menuName').textContent = u.nombre;
  $('#menuInfo').textContent = `@${u.username}`;
  $('#todayChip').textContent = new Intl.DateTimeFormat('es-SV', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date());
  $('#who').innerHTML = `<b>${esc(u.nombre)}</b><span class="muted">${esc(state.roles[u.rol])}</span>${u.zona ? `<div class="zone-tag" style="--zc:${zoneColor(u.zona)}">Zona ${esc(u.zona)}</div>` : ''}`;
  $('#sideNote').textContent = ROLE_NOTES[u.rol] || '';
}

function paintNav() {
  let html = '', group = '';
  const keys = allowed();
  for (const k of keys) {
    const r = ROUTES[k];
    if (keys.length > 2 && r.group !== group) { group = r.group; html += `<div class="nav-group">${esc(group)}</div>`; }
    const title = ROLE_TITLES[state.user.rol]?.[k]?.[0] ?? r.title;
    html += `<a href="#/${k}" data-route="${k}">${icon(r.icon)}<span>${esc(title)}</span></a>`;
  }
  $('#nav').innerHTML = html;
}

let renderToken = 0;
async function route() {
  if (!state.user) return;
  const keys = allowed();
  let key = location.hash.replace(/^#\/?/, '').split('?')[0];
  if (!keys.includes(key)) {
    if (key && ROUTES[key]) toast('No tienes permiso para esa sección.', 'warn');
    key = keys[0];
    history.replaceState(null, '', `#/${key}`);
  }
  const r = ROUTES[key];
  const [title, sub] = ROLE_TITLES[state.user.rol]?.[key] ?? [r.title, r.sub];
  $('#pageTitle').textContent = title; $('#pageSub').textContent = sub;
  document.title = `${title} · AguaControl`;
  $$('#nav a').forEach((a) => { if (a.dataset.route === key) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  $('#app').classList.remove('nav-open'); $('#menuToggle').setAttribute('aria-expanded', 'false');

  const view = $('#view');
  const token = ++renderToken;
  view.innerHTML = '<div class="skeleton"></div>';
  try {
    const mod = await r.load();
    if (token !== renderToken) return;
    await mod.default({ el: view, state, key, isStale: () => token !== renderToken });
  } catch (err) {
    if (token !== renderToken) return;
    if (err instanceof ApiError && err.status === 401) return;
    view.innerHTML = `<div class="card"><div class="empty"><b>No se pudo cargar esta sección</b>${esc(err.message)}</div></div>`;
    console.error(err);
  }
}

window.addEventListener('hashchange', route);
$('#menuToggle').addEventListener('click', () => {
  const open = $('#app').classList.toggle('nav-open');
  $('#menuToggle').setAttribute('aria-expanded', String(open));
});
$('#app').addEventListener('click', (e) => {
  if (e.target === $('#app') && $('#app').classList.contains('nav-open')) $('#app').classList.remove('nav-open');
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('#app').classList.remove('nav-open'); });

boot();
