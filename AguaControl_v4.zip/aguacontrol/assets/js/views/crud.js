// Página de administración con filtros, tabla, edición y borrado.
import { api } from '../api.js';
import { esc, icon, $, money, num, monthStart, today, debounce } from '../utils.js';
import { tableHtml, formDialog, confirmDialog, toast, editButtons } from '../ui.js';

/**
 * opts: {
 *   el, type, title, sub, newText,
 *   columns: [...],                 // columnas de la tabla
 *   fields: (row|null) => [...],    // campos del formulario
 *   totals: (rows) => ({key: html}),
 *   extraFilters: html, extraQuery: (form) => ({...}),
 *   above: async (container) => {}  // contenido opcional sobre la tabla
 * }
 */
export async function crudPage(opts) {
  const { el, type } = opts;
  el.innerHTML = `
    <div class="page-head">
      <div><h2>${esc(opts.title)}</h2><p>${esc(opts.sub || '')}</p></div>
      <button class="btn btn-primary" id="btnNew">${icon('plus')}${esc(opts.newText || 'Nuevo registro')}</button>
    </div>
    <div id="above"></div>
    <div class="card">
      <form class="toolbar" id="filters">
        <label class="field"><span>Desde</span><input type="date" name="desde" value="${monthStart()}" max="${today()}"></label>
        <label class="field"><span>Hasta</span><input type="date" name="hasta" value="${today()}" max="${today()}"></label>
        ${opts.extraFilters || ''}
        <label class="field grow"><span>Buscar</span><input type="search" name="q" placeholder="${esc(opts.searchHint || 'Producto, cliente, notas…')}" maxlength="60"></label>
        <span class="muted" id="count" style="padding-bottom:10px"></span>
      </form>
      <div id="tableBox"><div class="skeleton"></div></div>
    </div>`;

  const filters = $('#filters', el);
  let rows = [];

  async function load() {
    const f = Object.fromEntries(new FormData(filters));
    if (f.desde && f.hasta && f.desde > f.hasta) { $('#tableBox', el).innerHTML = '<div class="notice warn">La fecha “Desde” es posterior a “Hasta”.</div>'; return; }
    const data = await api(type, { query: { ...f, limit: 1000 } });
    rows = data.items;
    $('#count', el).textContent = `${rows.length} registro${rows.length === 1 ? '' : 's'}`;
    $('#tableBox', el).innerHTML = tableHtml({
      label: opts.title, columns: opts.columns, rows,
      empty: 'No hay registros en este periodo.',
      actions: (r) => editButtons(type, r),
      foot: rows.length && opts.totals ? opts.totals(rows) : null,
    });
    if (opts.above) await opts.above($('#above', el));
  }

  const reload = debounce(() => load().catch((e) => toast(e.message, 'error')), 250);
  filters.addEventListener('input', reload);
  filters.addEventListener('submit', (e) => e.preventDefault());

  const open = (row) => formDialog({
    title: row ? 'Editar registro' : (opts.newText || 'Nuevo registro'),
    fields: opts.fields(row), values: row || {}, wide: true,
    submitText: row ? 'Guardar cambios' : 'Guardar',
    onSubmit: (v) => api(row ? `${type}/${row.id}` : type, { method: row ? 'PUT' : 'POST', body: v }),
  }).then(load);

  $('#btnNew', el).addEventListener('click', () => open(null));
  el.addEventListener('click', async (e) => {
    const ed = e.target.closest('[data-edit]'), del = e.target.closest('[data-del]');
    if (ed) open(rows.find((r) => r.id === Number(ed.dataset.id)));
    if (del) {
      if (!(await confirmDialog('Este registro se borrará de forma permanente.', { title: '¿Borrar registro?', okText: 'Borrar', danger: true }))) return;
      try { const r = await api(`${type}/${del.dataset.id}`, { method: 'DELETE' }); toast(r.message); load(); }
      catch (err) { toast(err.message, 'error'); }
    }
  });

  await load();
  return { reload: load };
}

export const opt = (items, value, label, blank) => [...(blank ? [{ value: '', label: blank }] : []), ...items.map((i) => ({ value: i[value], label: typeof label === 'function' ? label(i) : i[label] }))];
export const sumBy = (rows, k) => rows.reduce((s, r) => s + (Number(r[k]) || 0), 0);
export { money, num };
