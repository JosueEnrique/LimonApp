// Camiones: código de identificación, placa, a quién está asignado y existencias.
import { api } from '../api.js';
import { $, esc, icon, zoneColor } from '../utils.js';
import { tableHtml, formDialog, confirmDialog, toast } from '../ui.js';
import { truckCards } from './cargas.js';
import { loadCatalogs } from '../main.js';

export default async function ({ el }) {
  el.innerHTML = `
    <div class="page-head">
      <div><h2>Camiones</h2><p>Cada camión tiene un código único (CAM-01, CAM-02…). El vendedor que lo usa se asigna en <a href="#/vendedores">Vendedores y zonas</a>.</p></div>
      <button class="btn btn-primary" id="btnNew">${icon('plus')}Agregar camión</button>
    </div>
    <div class="card" style="margin-bottom:18px"><div id="tableBox"><div class="skeleton"></div></div></div>
    <div class="card"><div class="card-head"><div><h3>Producto en cada camión</h3><p>Cargado − vendido desde cada camión</p></div></div><div id="stockBox"></div></div>`;

  let data = { items: [] };
  async function load() {
    data = await api('camiones');
    $('#tableBox', el).innerHTML = tableHtml({ label: 'Camiones', rows: data.items, columns: [
      { key: 'codigo', label: 'Código', render: (r) => `<span class="pill brand">${esc(r.codigo)}</span>` },
      { key: 'placa', label: 'Placa', render: (r) => esc(r.placa || '—') },
      { key: 'descripcion', label: 'Descripción', wrap: true, render: (r) => esc(r.descripcion) },
      { key: 'asignado', label: 'Lo usa', render: (r) => r.asignado ? `<b>${esc(r.asignado)}</b>` : '<span class="muted">Sin vendedor</span>' },
      { key: 'zona', label: 'Zona', render: (r) => r.zona ? `<span class="zone-tag" style="--zc:${zoneColor(r.zona)}">${esc(r.zona)}</span>` : '—' },
      { key: 'cargas', label: 'Cargas', num: true },
      { key: 'ventas', label: 'Ventas', num: true },
      { key: 'activo', label: 'Estado', render: (r) => r.activo ? '<span class="pill ok">Activo</span>' : '<span class="pill">Inactivo</span>' },
    ], actions: (r) => `<button class="btn btn-sm" data-edit="${r.id}">Editar</button><button class="btn btn-sm btn-danger" data-del="${r.id}">Eliminar</button>` });
    $('#stockBox', el).innerHTML = truckCards(data.stock);
  }

  const fields = (row) => [
    { name: 'codigo', label: 'Código', required: true, maxlength: 20, placeholder: row ? '' : data.siguiente, hint: row ? '' : `vacío = ${data.siguiente}`, pattern: '[A-Za-z0-9-]{2,20}' },
    { name: 'placa', label: 'Placa', maxlength: 20, placeholder: 'ej. C 123-456' },
    { name: 'descripcion', label: 'Descripción', full: true, maxlength: 120, placeholder: 'Ruta, modelo o capacidad' },
    ...(row ? [{ name: 'activo', label: 'Camión activo (disponible para cargas y ventas)', type: 'checkbox', full: true }] : []),
  ];
  const open = (row) => formDialog({ title: row ? `Editar ${row.codigo}` : 'Agregar camión', fields: fields(row), values: row || {},
    onSubmit: (v) => api(row ? `camiones/${row.id}` : 'camiones', { method: row ? 'PUT' : 'POST', body: v }) })
    .then(async () => { await loadCatalogs(); load(); });

  $('#btnNew', el).addEventListener('click', () => open(null));
  el.addEventListener('click', async (e) => {
    const ed = e.target.closest('[data-edit]'), del = e.target.closest('[data-del]');
    if (ed) open(data.items.find((r) => r.id === Number(ed.dataset.edit)));
    if (del) {
      const t = data.items.find((r) => r.id === Number(del.dataset.del));
      const msg = t.cargas || t.ventas ? 'Este camión tiene movimientos, así que se desactivará y se conservará su historial.' : 'El camión se eliminará y se quitará al vendedor que lo tenga asignado.';
      if (!(await confirmDialog(msg, { title: `¿Eliminar ${t.codigo}?`, okText: 'Eliminar', danger: true }))) return;
      try { toast((await api(`camiones/${t.id}`, { method: 'DELETE' })).message); await loadCatalogs(); load(); }
      catch (err) { toast(err.message, 'error'); }
    }
  });
  await load();
}
