// Dashboard del administrador: el producto en movimiento, ventas contra compras, zonas e inventario.
import { api } from '../api.js';
import { $, esc, money, num, pct, monthStart, today, debounce, fmtDate, zoneColor } from '../utils.js';
import { kpi, tableHtml, barList, columnChart, toast } from '../ui.js';
import { truckCards } from './cargas.js';

export default async function ({ el }) {
  el.innerHTML = `
    <div class="page-head">
      <div><h2>Resumen del negocio</h2><p>Del periodo elegido. El inventario siempre muestra lo que hay hoy.</p></div>
      <form class="toolbar" id="period" style="margin:0">
        <label class="field"><span>Desde</span><input type="date" name="desde" value="${monthStart()}" max="${today()}"></label>
        <label class="field"><span>Hasta</span><input type="date" name="hasta" value="${today()}" max="${today()}"></label>
      </form>
    </div>
    <div id="body"><div class="skeleton"></div></div>`;

  async function load() {
    const q = Object.fromEntries(new FormData($('#period', el)));
    if (q.desde > q.hasta) { $('#body', el).innerHTML = '<div class="notice warn">La fecha inicial es posterior a la final.</div>'; return; }
    const d = await api('panel', { query: q });
    const v = d.ventas, c = d.compras, f = d.flujo, r = d.resultado;
    const sold = f.vendido_camion + f.vendido_directo;
    const ratio = (a, b) => (b > 0 ? Math.min(100, (a / b) * 100) : 0);
    const negativos = d.planta.filter((p) => p.planta < 0).length;

    $('#body', el).innerHTML = `
      <section class="flow" aria-label="Movimiento del producto en el periodo" style="margin-bottom:16px">
        <div class="flow-step"><div class="k">Producido</div><div class="v">${num(f.producido)}</div><div class="s">unidades netas, ${num(f.desperdicio)} de desperdicio</div></div>
        <div class="flow-step"><div class="k">En planta hoy</div><div class="v">${num(f.en_planta)}</div><div class="s">listas para cargar</div></div>
        <div class="flow-step"><div class="k">Cargado a camiones</div><div class="v">${num(f.cargado)}</div><div class="s">${num(f.en_camiones)} siguen en ruta hoy</div>
          <div class="gauge" title="Parte de lo producido que salió en camión"><i style="width:${ratio(f.cargado, f.producido)}%"></i></div></div>
        <div class="flow-step"><div class="k">Vendido</div><div class="v">${num(sold)}</div><div class="s">${num(f.vendido_camion)} en ruta, ${num(f.vendido_directo)} en planta</div>
          <div class="gauge" title="Parte de lo cargado que ya se vendió"><i style="width:${ratio(f.vendido_camion, f.cargado)}%"></i></div></div>
      </section>

      <div class="kpis" style="margin-bottom:16px">
        ${kpi('Ingresos por ventas', money(v.ingresos), `${num(v.num)} ventas, ticket de ${money(v.ticket)}`)}
        ${kpi('Compras de insumos', money(c.total), `${num(c.num)} compras registradas`)}
        ${kpi('Utilidad estimada', money(r.utilidad), 'Ventas menos costo estándar y combustible', r.utilidad < 0 ? 'danger' : 'ok')}
        ${kpi('Flujo de caja simple', money(r.flujo), 'Ventas menos compras y combustible', r.flujo < 0 ? 'danger' : '')}
      </div>

      <section class="card" style="margin-bottom:16px">
        <div class="card-head"><div><h3>Ventas y compras por día</h3><p>Montos en dólares</p></div></div>
        ${columnChart(d.diario.map((x) => ({ fecha: x.fecha, valores: { Ventas: x.ventas, Compras: x.compras } })), ['Ventas', 'Compras'], ['var(--garrafon)', 'var(--gris)'], { stacked: false })}
      </section>

      <div class="grid-2" style="margin-bottom:16px">
        <section class="card"><div class="card-head"><div><h3>Ventas por zona</h3><p>Ingresos del periodo</p></div><a class="btn btn-sm" href="#/reportes">Ver reporte</a></div>
          ${barList(d.por_zona, { label: 'zona', value: 'ingresos', color: (i) => zoneColor(i.zona) })}
          <h4 style="font-size:14px;margin:22px 0 10px">Mejores vendedores</h4>
          ${d.por_vendedor.length ? `<div class="mini-list">${d.por_vendedor.map((s) => `<div class="mini-row"><span><b>${esc(s.vendedor)}</b> <span class="zone-tag" style="--zc:${zoneColor(s.zona)};font-weight:500">${esc(s.zona)}</span></span><span>${money(s.ingresos)} <span class="muted" style="font-size:12.5px">en ${num(s.ventas)} venta${s.ventas === 1 ? '' : 's'}</span></span></div>`).join('')}</div>` : '<div class="empty">Sin ventas de vendedores en el periodo.</div>'}
        </section>
        <section class="card"><div class="card-head"><div><h3>Compras por insumo</h3><p>En qué se gastó</p></div><a class="btn btn-sm" href="#/entradas">Ver compras</a></div>
          ${barList(d.por_insumo, { label: 'tipo', value: 'total', color: () => 'var(--gris)' })}
          <h4 style="font-size:14px;margin:22px 0 10px">Últimas compras</h4>
          ${d.ultimas_compras.length ? `<div class="mini-list">${d.ultimas_compras.map((x) => `<div class="mini-row"><span>${esc(x.tipo)}<br><span class="muted" style="font-size:12.5px">${esc(x.proveedor || 'Sin proveedor')}, ${fmtDate(x.fecha)}</span></span><b>${money(x.total)}</b></div>`).join('')}</div>` : '<div class="empty">Sin compras en el periodo.</div>'}
        </section>
      </div>

      <section class="card" style="margin-bottom:16px">
        <div class="card-head"><div><h3>Inventario de producto terminado</h3><p>En planta: producido menos cargado y ventas directas. Valor a costo estimado.</p></div>
          ${negativos ? `<span class="pill danger">${negativos} con stock negativo</span>` : ''}</div>
        ${tableHtml({ label: 'Inventario', rows: d.planta, columns: [
          { key: 'producto', label: 'Producto', render: (x) => `<b>${esc(x.producto)}</b>` },
          { key: 'producido', label: 'Producido', num: true, render: (x) => num(x.producido) },
          { key: 'cargado', label: 'Cargado', num: true, render: (x) => num(x.cargado) },
          { key: 'vendido', label: 'Vendido', num: true, render: (x) => num(x.vendido) },
          { key: 'planta', label: 'En planta', num: true, render: (x) => `<b style="color:${x.planta < 0 ? 'var(--error)' : 'inherit'}">${num(x.planta)}</b>` },
          { key: 'en_camiones', label: 'En camiones', num: true, render: (x) => num(x.en_camiones) },
          { key: 'valor', label: 'Valor', num: true, render: (x) => money(x.valor) },
        ] })}
      </section>

      <section class="card"><div class="card-head"><div><h3>Producto en ruta</h3><p>Por camión y vendedor</p></div><a class="btn btn-sm" href="#/vendedores">Vendedores</a></div>${truckCards(d.camiones)}</section>`;
  }

  $('#period', el).addEventListener('input', debounce(() => load().catch((e) => toast(e.message, 'error'))));
  await load();
}

export { pct };
