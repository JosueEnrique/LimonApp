// Producción: remisión + registro del turno para el supervisor; tabla completa para el admin.
import { api } from '../api.js';
import { $, esc, fmtDate, today, currentShift, num } from '../utils.js';
import { productTiles, stepperHtml, tableHtml, toast } from '../ui.js';
import { crudPage, opt, sumBy } from './crud.js';
import { wireCapture, wireRecent } from './captura.js';

const fieldsFor = (cat) => () => [
  { name: 'fecha', label: 'Fecha', type: 'date', required: true, value: today(), max: today() },
  { name: 'turno', label: 'Turno', type: 'select', required: true, options: opt(cat.turnos.map((t) => ({ t })), 't', 't'), value: currentShift() },
  { name: 'producto_id', label: 'Producto', type: 'select', required: true, full: true, options: opt(cat.productos, 'id', 'nombre') },
  { name: 'cantidad', label: 'Cantidad producida', type: 'number', required: true, min: 1, step: 'any', inputmode: 'numeric' },
  { name: 'desperdicio', label: 'Desperdicio (unidades)', type: 'number', min: 0, step: 'any', value: 0, inputmode: 'numeric' },
  { name: 'lote', label: 'Lote', maxlength: 40, placeholder: 'Opcional' },
  { name: 'notas', label: 'Observaciones', type: 'textarea', full: true, maxlength: 500, placeholder: 'Revisión de calidad, incidencias…' },
];

export default async function (ctx) {
  return ctx.state.user.rol === 'admin' ? adminView(ctx) : supervisorView(ctx);
}

async function adminView({ el, state }) {
  await crudPage({
    el, type: 'produccion', title: 'Producción', newText: 'Registrar producción',
    sub: 'Lo que registró el supervisor de producción en cada turno. Lo neto (producido menos desperdicio) entra al stock de planta.', searchHint: 'Producto, lote, turno…',
    extraFilters: `<label class="field"><span>Turno</span><select name="turno"><option value="">Todos</option>${state.cat.turnos.map((t) => `<option>${esc(t)}</option>`).join('')}</select></label>`,
    columns: [
      { key: 'fecha', label: 'Fecha', render: (r) => fmtDate(r.fecha) },
      { key: 'turno', label: 'Turno' },
      { key: 'producto', label: 'Producto', render: (r) => `<b>${esc(r.producto)}</b>` },
      { key: 'cantidad', label: 'Producido', num: true, render: (r) => num(r.cantidad) },
      { key: 'desperdicio', label: 'Desperdicio', num: true, render: (r) => r.desperdicio ? `<span class="pill warn">${num(r.desperdicio)}</span>` : '0' },
      { key: 'neto', label: 'Neto', num: true, render: (r) => `<b>${num(r.cantidad - r.desperdicio)}</b>` },
      { key: 'usuario', label: 'Supervisor' },
      { key: 'lote', label: 'Lote' },
      { key: 'notas', label: 'Observaciones', wrap: true, render: (r) => esc(r.notas) },
    ],
    totals: (rows) => ({ cantidad: num(sumBy(rows, 'cantidad')), desperdicio: num(sumBy(rows, 'desperdicio')), neto: `<b>${num(sumBy(rows, 'cantidad') - sumBy(rows, 'desperdicio'))}</b>` }),
    fields: fieldsFor(state.cat),
  });
}

async function supervisorView({ el, state }) {
  const cat = state.cat;
  const shift = currentShift();
  el.innerHTML = `
    <div class="grid-main">
      <form class="capture" id="capture" novalidate>
        <div class="capture-head">
          <div><h2>Remisión de producción</h2><p>Anota lo que pasó el control de calidad.</p></div>
          <div class="slip-meta"><b id="slipShift">Turno ${esc(shift)}</b>${esc(fmtDate(today()))}<br>${esc(state.user.nombre)}</div>
        </div>
        <div class="capture-body">
          <div><div class="step-label"><span class="n">1</span>Producto</div>${productTiles('producto_id', cat.productos)}</div>
          <div><div class="step-label"><span class="n">2</span>Unidades buenas</div>${stepperHtml('cantidad', { min: 1, step: 1, quick: [10, 25, 50, 100], label: 'Cantidad producida' })}</div>
          <div class="form-grid">
            <div class="field full"><span class="legend">Turno</span>
              <div class="segmented">${cat.turnos.map((t) => `<label><input type="radio" name="turno" value="${esc(t)}" ${t === shift ? 'checked' : ''}><span>${esc(t)}</span></label>`).join('')}</div>
            </div>
            <div class="field"><span>Desperdicio <span class="hint">unidades malas</span></span>${stepperHtml('desperdicio', { value: 0, min: 0, step: 1, small: true, label: 'Desperdicio' })}</div>
            <label class="field"><span>Fecha</span><input type="date" name="fecha" value="${today()}" max="${today()}" required></label>
            <label class="field"><span>Lote <span class="hint">opcional</span></span><input name="lote" maxlength="40" placeholder="ej. L-1019"></label>
            <label class="field"><span>Observaciones <span class="hint">opcional</span></span><input name="notas" maxlength="500" placeholder="Revisión de calidad"></label>
          </div>
          <div class="total-box"><span id="summary">Netas al stock</span><b id="netBox">0</b></div>
          <button class="btn btn-save btn-lg btn-block" type="submit">Guardar producción</button>
        </div>
      </form>

      <section class="card" aria-labelledby="regTitle">
        <div class="card-head"><div><h3 id="regTitle">Registro del turno</h3><p>Todo lo producido en la planta en el turno elegido</p></div></div>
        <form class="toolbar" id="regFilter" style="margin-bottom:12px">
          <label class="field"><span>Fecha</span><input type="date" name="fecha" value="${today()}" max="${today()}"></label>
          <div class="field"><span class="legend">Turno</span><div class="segmented">
            ${['', ...cat.turnos].map((t) => `<label><input type="radio" name="turno" value="${esc(t)}" ${t === shift ? 'checked' : ''}><span>${t || 'Todos'}</span></label>`).join('')}
          </div></div>
        </form>
        <div id="regTotal"></div>
        <div id="regList" style="margin-top:14px"></div>
      </section>
    </div>`;

  const form = $('#capture', el), filter = $('#regFilter', el);
  let rows = [];

  const update = () => {
    const q = Number(form.elements.namedItem('cantidad').value) || 0, w = Number(form.elements.namedItem('desperdicio').value) || 0;
    $('#netBox', el).textContent = num(Math.max(0, q - w));
    const t = form.querySelector('[name=turno]:checked')?.value;
    $('#slipShift', el).textContent = `Turno ${t}`;
  };

  async function refresh() {
    const f = Object.fromEntries(new FormData(filter));
    const query = { desde: f.fecha, hasta: f.fecha, turno: f.turno, limit: 500 };
    const [mine, list] = await Promise.all([api('mi', { query: { fecha: f.fecha, turno: f.turno } }), api('produccion', { query })]);
    rows = list.items;
    const byProduct = {};
    for (const r of mine.resumen) {
      byProduct[r.producto] ??= { producto: r.producto, cantidad: 0, desperdicio: 0 };
      byProduct[r.producto].cantidad += r.cantidad; byProduct[r.producto].desperdicio += r.desperdicio;
    }
    const items = Object.values(byProduct);
    const net = items.reduce((s, r) => s + r.cantidad - r.desperdicio, 0);
    const waste = items.reduce((s, r) => s + r.desperdicio, 0);
    $('#regTotal', el).innerHTML = `
      <div style="display:flex;align-items:baseline;gap:12px;flex-wrap:wrap"><span class="big-number">${num(net)}</span><span class="muted">unidades netas${f.turno ? ` en el turno ${esc(f.turno.toLowerCase())}` : ' en el día'}, ${num(waste)} de desperdicio</span></div>
      ${items.length ? `<div class="mini-list" style="margin-top:10px">${items.map((r) => `<div class="mini-row"><span>${esc(r.producto)}</span><span><b>${num(r.cantidad - r.desperdicio)}</b>${r.desperdicio ? ` <span class="muted" style="font-size:12.5px">(${num(r.desperdicio)} malas)</span>` : ''}</span></div>`).join('')}</div>` : ''}`;
    $('#regList', el).innerHTML = tableHtml({ label: 'Registros del turno', rows, empty: 'No hay registros en este turno.',
      columns: [
        { key: 'creado_en', label: 'Hora', render: (r) => esc((r.creado_en || '').slice(11, 16)) },
        { key: 'turno', label: 'Turno' },
        { key: 'producto', label: 'Producto', render: (r) => `<b>${esc(r.producto)}</b>` },
        { key: 'cantidad', label: 'Producido', num: true, render: (r) => num(r.cantidad) },
        { key: 'desperdicio', label: 'Malas', num: true, render: (r) => num(r.desperdicio) },
        { key: 'lote', label: 'Lote' },
      ],
      actions: (r) => r.editable ? `<button class="btn btn-sm" data-edit="produccion" data-id="${r.id}">Editar</button><button class="btn btn-sm btn-danger" data-del="produccion" data-id="${r.id}">Borrar</button>` : '<span class="muted">Cerrado</span>' });
  }

  filter.addEventListener('input', () => refresh().catch((e) => toast(e.message, 'error')));
  wireCapture(form, {
    route: 'produccion', onChange: update,
    onSaved: () => {
      for (const n of ['cantidad', 'lote', 'notas']) form.elements.namedItem(n).value = '';
      form.elements.namedItem('desperdicio').value = 0; update(); refresh(); form.elements.namedItem('cantidad').focus();
    },
  });
  wireRecent(el, { type: 'produccion', getRows: () => rows, fields: fieldsFor(cat), after: refresh });
  update();
  await refresh();
}
