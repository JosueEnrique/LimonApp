// Costos base y precio sugerido por producto.
import { api } from '../api.js';
import { $, esc, money, num } from '../utils.js';
import { tableHtml, toast, clearErrors, showErrors } from '../ui.js';
import { loadCatalogs } from '../main.js';

const GROUPS = [
  ['Costos por litro', [['agua', 'Agua tratada por litro'], ['mano_obra', 'Mano de obra por litro'], ['energia', 'Energía por litro'], ['mantenimiento', 'Mantenimiento / alquiler por litro']]],
  ['Envases y empaque (por unidad)', [['b600', 'Botella 600 ml'], ['b1l', 'Botella 1 L'], ['galon', 'Galón'], ['garrafon', 'Garrafón'], ['tapon', 'Tapón'], ['etiqueta', 'Etiqueta'], ['empaque', 'Empaque de fardo']]],
];

export default async function ({ el }) {
  const d = await api('costos');
  el.innerHTML = `
    <div class="page-head"><div><h2>Costos y precios</h2><p>Con estos valores se calcula el costo estándar, la utilidad estimada y el precio sugerido que ven los vendedores.</p></div></div>
    <div class="notice warn" style="margin-bottom:18px">Los valores iniciales son ejemplos. Reemplázalos por tus costos reales antes de decidir precios.</div>
    <form id="costForm" novalidate>
      <div class="grid-2">
        ${GROUPS.map(([title, items]) => `<div class="card"><div class="card-head"><h3>${esc(title)}</h3></div><div class="form-grid">
          ${items.map(([k, label]) => `<label class="field"><span>${esc(label)} ($)</span><input name="${k}" type="number" min="0" max="10000" step="any" inputmode="decimal" required value="${d.costos[k]}"><span class="field-error" data-error-for="${k}" hidden></span></label>`).join('')}
        </div></div>`).join('')}
      </div>
      <div class="card" style="margin-top:18px;display:flex;flex-wrap:wrap;gap:16px;align-items:flex-end;justify-content:space-between">
        <label class="field" style="max-width:260px"><span>Margen de ganancia deseado (%)</span><input name="margen" type="number" min="0" max="1000" step="1" required value="${d.costos.margen}"><span class="field-error" data-error-for="margen" hidden></span></label>
        <button class="btn btn-primary" type="submit">Guardar costos</button>
      </div>
    </form>
    <div class="card" style="margin-top:18px"><div class="card-head"><div><h3>Costo estimado y precio sugerido</h3><p>Se actualiza al guardar</p></div></div><div id="tableBox"></div></div>`;

  const paint = (tabla) => { $('#tableBox', el).innerHTML = tableHtml({ label: 'Costos por producto', rows: tabla, columns: [
    { key: 'producto', label: 'Producto', render: (r) => `<b>${esc(r.producto)}</b>` },
    { key: 'litros', label: 'Litros', num: true, render: (r) => `${num(r.litros)} L` },
    { key: 'envase', label: 'Envase / empaque', num: true, render: (r) => money(r.envase) },
    { key: 'operacion', label: 'Agua y operación', num: true, render: (r) => money(r.operacion) },
    { key: 'costo', label: 'Costo estimado', num: true, render: (r) => money(r.costo) },
    { key: 'precio_sugerido', label: 'Precio sugerido', num: true, render: (r) => `<b>${money(r.precio_sugerido)}</b>` },
  ] }); };
  paint(d.tabla);

  $('#costForm', el).addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.currentTarget; clearErrors(form);
    try {
      const res = await api('costos', { method: 'PUT', body: Object.fromEntries(new FormData(form)) });
      toast(res.message); paint((await api('costos')).tabla); loadCatalogs();
    } catch (err) { showErrors(form, err); }
  });
}
