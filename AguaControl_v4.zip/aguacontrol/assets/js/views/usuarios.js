// Usuarios: cuentas, roles y camión asignado.
import { api, ApiError } from '../api.js';
import { $, esc, icon, fmtDateTime, initials, avatarColor, zoneColor } from '../utils.js';
import { tableHtml, formDialog, confirmDialog, toast } from '../ui.js';
import { state, loadCatalogs } from '../main.js';

const ROLE_PILL = { admin: 'brand', contabilidad: '', despacho: 'warn', supervisor: 'ok' };

export default async function ({ el }) {
  el.innerHTML = `
    <div class="page-head">
      <div><h2>Usuarios del sistema</h2><p>Personas que entran a AguaControl. Los encargados de despacho necesitan una zona. Solo puede haber un supervisor de producción activo. Los vendedores de ruta se administran en <a href="#/vendedores">Vendedores y zonas</a>.</p></div>
      <button class="btn btn-primary" id="btnNew">${icon('plus')}Crear usuario</button>
    </div>
    <div class="card"><div id="tableBox"><div class="skeleton"></div></div></div>
    <p class="muted" style="font-size:12px;margin-top:12px">Las contraseñas se guardan cifradas (bcrypt); nadie, ni el administrador, puede verlas. Si alguien la olvida, usa “Contraseña” para asignarle una nueva.</p>`;

  let users = [];
  const roleOpts = Object.entries(state.roles).map(([value, label]) => ({ value, label }));
  const zoneOpts = () => [{ value: '', label: 'Sin zona (no es despacho)' }, ...state.cat.zonas.map((z) => ({ value: z.id, label: z.nombre }))];

  async function load() {
    users = (await api('usuarios')).items;
    $('#tableBox', el).innerHTML = tableHtml({ label: 'Usuarios', rows: users, columns: [
      { key: 'nombre', label: 'Persona', render: (u) => `<span style="display:inline-flex;align-items:center;gap:9px"><span class="avatar" style="--avatar:${avatarColor(u.nombre)};width:30px;height:30px;font-size:12px">${esc(initials(u.nombre))}</span><span><b>${esc(u.nombre)}</b><br><span class="muted" style="font-size:12px">@${esc(u.username)}</span></span></span>` },
      { key: 'rol', label: 'Rol', render: (u) => `<span class="pill ${ROLE_PILL[u.rol] || ''}">${esc(state.roles[u.rol])}</span>` },
      { key: 'zona', label: 'Zona', render: (u) => u.zona ? `<span class="zone-tag" style="--zc:${zoneColor(u.zona)}">${esc(u.zona)}</span>` : (u.rol === 'despacho' ? '<span class="pill danger">Falta zona</span>' : '<span class="muted">—</span>') },
      { key: 'activo', label: 'Estado', render: (u) => u.activo ? '<span class="pill ok">Activo</span>' : '<span class="pill">Inactivo</span>' },
      { key: 'ultimo_acceso', label: 'Último acceso', render: (u) => u.ultimo_acceso ? fmtDateTime(u.ultimo_acceso) : '<span class="muted">Nunca</span>' },
    ], actions: (u) => `<button class="btn btn-sm" data-edit="${u.id}">Editar</button><button class="btn btn-sm" data-pw="${u.id}">Contraseña</button>${u.id === state.user.id ? '' : `<button class="btn btn-sm btn-danger" data-del="${u.id}">Eliminar</button>`}` });
  }

  const after = async () => { await loadCatalogs(); load(); };

  $('#btnNew', el).addEventListener('click', () => formDialog({
    title: 'Crear usuario', sub: 'Mínimo 8 caracteres en la contraseña, con letras y números.', submitText: 'Crear usuario',
    fields: [
      { name: 'username', label: 'Nombre de usuario', required: true, maxlength: 32, placeholder: 'ej. despacho3', autocomplete: 'off', hint: 'minúsculas, sin espacios' },
      { name: 'nombre', label: 'Nombre de la persona', required: true, maxlength: 60 },
      { name: 'rol', label: 'Rol', type: 'select', required: true, options: roleOpts, value: 'despacho' },
      { name: 'zona_id', label: 'Zona', type: 'select', options: zoneOpts(), hint: 'solo despacho' },
      { name: 'password', label: 'Contraseña inicial', type: 'password', required: true, full: true, autocomplete: 'new-password' },
    ],
    onSubmit: (v) => api('usuarios', { method: 'POST', body: v }),
  }).then(after));

  el.addEventListener('click', async (e) => {
    const id = Number(e.target.closest('[data-edit],[data-pw],[data-del]')?.dataset.edit || e.target.closest('[data-pw]')?.dataset.pw || e.target.closest('[data-del]')?.dataset.del);
    const u = users.find((x) => x.id === id); if (!u) return;
    if (e.target.closest('[data-edit]')) {
      formDialog({ title: `Editar a ${u.nombre}`, sub: `@${u.username}`, values: u, fields: [
        { name: 'nombre', label: 'Nombre de la persona', required: true, maxlength: 60, full: true },
        { name: 'rol', label: 'Rol', type: 'select', required: true, options: roleOpts },
        { name: 'zona_id', label: 'Zona', type: 'select', options: zoneOpts(), hint: 'solo despacho' },
        { name: 'activo', label: 'Usuario activo (puede iniciar sesión)', type: 'checkbox', full: true },
      ], onSubmit: (v) => api(`usuarios/${u.id}`, { method: 'PUT', body: v }) }).then(after);
    } else if (e.target.closest('[data-pw]')) {
      formDialog({ title: 'Asignar nueva contraseña', sub: `Para ${u.nombre} (@${u.username}). Entrégasela en persona.`, submitText: 'Guardar contraseña', fields: [
        { name: 'password', label: 'Nueva contraseña', type: 'password', required: true, full: true, autocomplete: 'new-password' },
        { name: 'confirmar', label: 'Repetir contraseña', type: 'password', required: true, full: true, autocomplete: 'new-password' },
      ], onSubmit: (v) => {
        if (v.password !== v.confirmar) throw new ApiError(422, { error: 'Las contraseñas no coinciden.', errors: { confirmar: 'No coincide.' } });
        return api(`usuarios/${u.id}/password`, { method: 'POST', body: v });
      } });
    } else if (e.target.closest('[data-del]')) {
      if (!(await confirmDialog(`Si ${u.nombre} ya tiene registros, se desactivará en lugar de borrarse para conservar el historial.`, { title: `¿Eliminar a ${u.nombre}?`, okText: 'Eliminar', danger: true }))) return;
      try { toast((await api(`usuarios/${u.id}`, { method: 'DELETE' })).message); after(); }
      catch (err) { toast(err.message, 'error'); }
    }
  });
  await load();
}
