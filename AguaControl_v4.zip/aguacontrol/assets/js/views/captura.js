// Piezas compartidas por las tarjetas grandes de operario, despacho y vendedor.
import { api } from '../api.js';
import { $, esc, fmtDate, formValues, num, money } from '../utils.js';
import { clearErrors, showErrors, sendWithStockCheck, toast, wireSteppers, confirmDialog, formDialog } from '../ui.js';

/** Conecta el envío de una tarjeta de captura. */
export function wireCapture(form, { route, prepare = (v) => v, onSaved, onChange = () => {} }) {
  wireSteppers(form, onChange);
  if (!form.querySelector('.stamp')) form.insertAdjacentHTML('beforeend', '<span class="stamp" aria-hidden="true">Guardado</span>');
  form.addEventListener('input', onChange);
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); clearErrors(form);
    const btn = $('[type=submit]', form), label = btn.innerHTML;
    btn.disabled = true; btn.textContent = 'Guardando…';
    try {
      const res = await sendWithStockCheck((v) => api(route, { method: 'POST', body: v }), prepare(formValues(form)));
      if (res) {
        form.classList.remove('saved'); void form.offsetWidth; form.classList.add('saved');
        toast(res.message || 'Guardado.'); onSaved?.(res);
      }
    } catch (err) { showErrors(form, err); }
    finally { btn.disabled = false; btn.innerHTML = label; }
  });
}

/** Lista de los registros propios recientes con editar/borrar. */
export function recentList(items, { type, line, empty }) {
  if (!items.length) return `<div class="empty">${esc(empty)}</div>`;
  return `<div class="mini-list">${items.map((r) => `
    <div class="mini-row">
      <div>${line(r)}<div class="muted" style="font-size:12.5px">${fmtDate(r.fecha)}, ${esc((r.creado_en || '').slice(11, 16))}</div></div>
      <div style="display:flex;gap:4px;align-items:center">
        ${r.editable ? `<button class="btn btn-sm" data-edit="${type}" data-id="${r.id}">Editar</button><button class="btn btn-sm btn-danger" data-del="${type}" data-id="${r.id}">Borrar</button>` : '<span class="muted" style="font-size:13px">Cerrado</span>'}
      </div>
    </div>`).join('')}</div>`;
}

/** Maneja editar/borrar en la lista de recientes. */
export function wireRecent(root, { type, getRows, fields, after }) {
  root.addEventListener('click', async (e) => {
    const ed = e.target.closest(`[data-edit="${type}"]`), del = e.target.closest(`[data-del="${type}"]`);
    if (ed) {
      const row = getRows().find((r) => r.id === Number(ed.dataset.id));
      if (!row) return;
      await formDialog({ title: 'Corregir registro', fields: fields(row), values: row, submitText: 'Guardar cambios',
        onSubmit: (v) => api(`${type}/${row.id}`, { method: 'PUT', body: v }) });
      after();
    }
    if (del) {
      if (!(await confirmDialog('El registro se borrará.', { title: '¿Borrar este registro?', okText: 'Borrar', danger: true }))) return;
      try { const r = await api(`${type}/${del.dataset.id}`, { method: 'DELETE' }); toast(r.message); after(); }
      catch (err) { toast(err.message, 'error'); }
    }
  });
}

export { num, money };
