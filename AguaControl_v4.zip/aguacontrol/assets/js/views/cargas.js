// Carga de camiones: remisión del encargado de despacho (solo su zona); tabla completa para el admin.
import { api } from '../api.js';
import { $, esc, fmtDate, today, num, icon, zoneColor } from '../utils.js';
import { productTiles, sellerTiles, stepperHtml } from '../ui.js';
import { crudPage, opt, sumBy } from './crud.js';
import { wireCapture, recentList, wireRecent } from './captura.js';

const sellerLabel = (v) => `${v.nombre} (${v.codigo}, ${v.zona}${v.camion ? `, ${v.camion}` : ', sin camión'})`;

const adminFields = (cat) => () => [
  { name: 'fecha', label: 'Fecha', type: 'date', required: true, value: today(), max: today() },
  { name: 'vendedor_id', label: 'Vendedor', type: 'select', options: opt(cat.vendedores || [], 'id', sellerLabel, 'Sin vendedor (elige camión)') },
  { name: 'camion_id', label: 'Camión', type: 'select', hint: 'solo si no eliges vendedor', options: opt(cat.camiones, 'id', 'codigo', '—') },
  { name: 'producto_id', label: 'Producto', type: 'select', required: true, options: opt(cat.productos, 'id', 'nombre') },
  { name: 'cantidad', label: 'Cantidad cargada', type: 'number', required: true, min: 1, step: 'any', inputmode: 'numeric' },
  { name: 'notas', label: 'Observaciones', type: 'textarea', full: true, maxlength: 500, placeholder: 'Ruta, cliente o referencia' },
];
const dispatchFields = (cat) => () => adminFields(cat)().filter((f) => f.name !== 'camion_id').map((f) => f.name === 'vendedor_id' ? { ...f, required: true, options: opt(cat.vendedores, 'id', sellerLabel) } : f);

export function truckCards(trucks) {
  const list = trucks.filter((t) => t.activo || t.productos.some((p) => p.disponible));
  if (!list.length) return '<div class="empty">No hay camiones con producto.</div>';
  return `<div class="truck-grid">${list.map((t) => {
    const total = t.productos.reduce((s, p) => s + p.disponible, 0);
    const items = t.productos.filter((p) => p.cargado || p.vendido);
    const who = t.vendedor || t.asignados?.join(', ');
    return `<div class="truck-card" style="--zc:${t.zona ? zoneColor(t.zona) : 'var(--linea)'}">
      <h4>${icon('truck')}${esc(t.codigo)}${t.activo ? '' : ' <span class="pill">Inactivo</span>'}<span style="margin-inline-start:auto;font-stretch:112%">${num(total)} <span class="muted" style="font-weight:500;font-size:13px">en ruta</span></span></h4>
      <p class="muted" style="font-size:13px;margin:2px 0 8px">${who ? esc(who) : 'Sin vendedor'}${t.zona ? `, ${esc(t.zona)}` : ''}${t.placa ? `, placa ${esc(t.placa)}` : ''}</p>
      ${items.length ? `<div class="mini-list">${items.map((p) =>
        `<div class="mini-row"><span>${esc(p.producto)}<br><span class="muted" style="font-size:12.5px">${num(p.cargado)} cargadas, ${num(p.vendido)} vendidas</span></span><b style="font-size:17px;color:${p.disponible > 0 ? 'inherit' : 'var(--error)'}">${num(p.disponible)}</b></div>`).join('')}</div>` : '<p class="muted" style="font-size:13px">Sin producto cargado.</p>'}
    </div>`;
  }).join('')}</div>`;
}

export default async function (ctx) {
  return ctx.state.user.rol === 'admin' ? adminView(ctx) : dispatchView(ctx);
}

async function adminView({ el, state }) {
  const cat = state.cat;
  const sel = (name, items, label, blank) => `<label class="field"><span>${label}</span><select name="${name}"><option value="">${blank}</option>${items.map((i) => `<option value="${i.id}">${esc(i.codigo ? `${i.nombre ?? i.codigo}` : i.nombre)}</option>`).join('')}</select></label>`;
  await crudPage({
    el, type: 'cargas', title: 'Carga de camiones', newText: 'Registrar carga',
    sub: 'Cada carga mueve producto de la planta al camión del vendedor.', searchHint: 'Producto, vendedor, camión…',
    extraFilters: sel('zona_id', cat.zonas, 'Zona', 'Todas') + sel('vendedor_id', cat.vendedores || [], 'Vendedor', 'Todos'),
    columns: [
      { key: 'fecha', label: 'Fecha', render: (r) => fmtDate(r.fecha) },
      { key: 'zona', label: 'Zona', render: (r) => r.zona ? `<span class="zone-tag" style="--zc:${zoneColor(r.zona)}">${esc(r.zona)}</span>` : '—' },
      { key: 'vendedor', label: 'Vendedor', render: (r) => r.vendedor ? `<b>${esc(r.vendedor)}</b>` : '—' },
      { key: 'camion', label: 'Camión' },
      { key: 'producto', label: 'Producto' },
      { key: 'cantidad', label: 'Cantidad', num: true, render: (r) => `<b>${num(r.cantidad)}</b>` },
      { key: 'usuario', label: 'Registró' },
      { key: 'notas', label: 'Observaciones', wrap: true, render: (r) => esc(r.notas) },
    ],
    totals: (rows) => ({ cantidad: `<b>${num(sumBy(rows, 'cantidad'))}</b>` }),
    fields: adminFields(cat),
    above: async (box) => {
      const t = await api('camiones');
      box.innerHTML = `<section class="card" style="margin-bottom:16px"><div class="card-head"><div><h3>Producto en cada camión</h3><p>Cargado menos vendido. La franja de color indica la zona del vendedor.</p></div></div>${truckCards(t.stock)}</section>`;
    },
  });
}

async function dispatchView({ el, state }) {
  const cat = state.cat, u = state.user;
  el.innerHTML = `
    <div class="grid-main">
      <form class="capture" id="capture" novalidate>
        <div class="capture-head">
          <div><h2>Remisión de carga</h2><p>Producto que sale de planta hacia un vendedor de tu zona.</p></div>
          <div class="slip-meta"><b><span class="zone-tag" style="--zc:${zoneColor(u.zona)}">Zona ${esc(u.zona || '')}</span></b>${esc(fmtDate(today()))}<br>${esc(u.nombre)}</div>
        </div>
        <div class="capture-body">
          <div><div class="step-label"><span class="n">1</span>Vendedor</div>${sellerTiles('vendedor_id', cat.vendedores)}<span class="field-error" data-error-for="vendedor_id" hidden></span></div>
          <div><div class="step-label"><span class="n">2</span>Producto <span class="muted" style="font-weight:400">(cifra = disponible en planta)</span></div><div id="productTiles"></div><span class="field-error" data-error-for="producto_id" hidden></span></div>
          <div><div class="step-label"><span class="n">3</span>Unidades que se cargan</div>${stepperHtml('cantidad', { min: 1, quick: [10, 25, 50, 100], label: 'Cantidad cargada' })}</div>
          <div class="form-grid">
            <label class="field"><span>Fecha</span><input type="date" name="fecha" value="${today()}" max="${today()}" required></label>
            <label class="field"><span>Observaciones <span class="hint">opcional</span></span><input name="notas" maxlength="500" placeholder="Ruta o referencia"></label>
          </div>
          <button class="btn btn-save btn-lg btn-block" type="submit">Guardar carga</button>
        </div>
      </form>
      <div class="stack">
        <section class="card"><div class="card-head"><div><h3>Camiones de tu zona</h3><p>Lo que lleva cada vendedor ahora</p></div></div><div id="trucksBox"><div class="skeleton"></div></div></section>
        <section class="card"><div class="card-head"><div><h3>Cargas de hoy</h3></div></div><div id="todayBox"></div></section>
        <section class="card"><div class="card-head"><div><h3>Tus últimos registros</h3><p>Puedes corregir los de hoy</p></div></div><div id="recentBox"></div></section>
      </div>
    </div>`;

  const form = $('#capture', el);
  let recent = [];

  async function refresh() {
    const keep = form.elements.namedItem('producto_id')?.value;
    const [mine, list] = await Promise.all([api('mi'), api('cargas', { query: { limit: 8 } })]);
    recent = list.items;
    const stockOf = (p) => mine.planta.find((x) => x.producto_id === p.id)?.planta ?? 0;
    $('#productTiles', el).innerHTML = productTiles('producto_id', cat.productos, { selected: keep, badge: stockOf });
    $('#todayBox', el).innerHTML = mine.cargas.length
      ? `<div class="mini-list">${mine.cargas.map((r) => `<div class="mini-row"><span><b>${esc(r.vendedor)}</b>, ${esc(r.producto)}</span><b>${num(r.cantidad)}</b></div>`).join('')}</div>`
      : '<div class="empty">Aún no hay cargas hoy en tu zona.</div>';
    $('#trucksBox', el).innerHTML = truckCards(mine.camiones);
    $('#recentBox', el).innerHTML = recentList(recent, { type: 'cargas', empty: 'Sin registros todavía.',
      line: (r) => `<b>${esc(r.vendedor || r.camion)}</b>, ${esc(r.producto)}: ${num(r.cantidad)}` });
  }

  wireCapture(form, {
    route: 'cargas',
    onSaved: () => { form.elements.namedItem('cantidad').value = ''; form.elements.namedItem('notas').value = ''; refresh(); },
  });
  wireRecent(el, { type: 'cargas', getRows: () => recent, fields: dispatchFields(cat), after: refresh });
  await refresh();
}
