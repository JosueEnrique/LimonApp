// Entradas y compras (solo administrador)
import { esc, fmtDate, today } from '../utils.js';
import { crudPage, opt, sumBy, money, num } from './crud.js';

export default async function ({ el, state }) {
  const cat = state.cat;
  await crudPage({
    el, type: 'entradas', title: 'Compras de insumos', newText: 'Registrar compra',
    sub: 'Compras de agua, envases, etiquetas y otros insumos.', searchHint: 'Proveedor, insumo, notas…',
    columns: [
      { key: 'fecha', label: 'Fecha', render: (r) => fmtDate(r.fecha) },
      { key: 'proveedor', label: 'Proveedor' },
      { key: 'tipo', label: 'Insumo' },
      { key: 'cantidad', label: 'Cantidad', num: true, render: (r) => num(r.cantidad) },
      { key: 'costo_unitario', label: 'Costo unit.', num: true, render: (r) => money(r.costo_unitario) },
      { key: 'total', label: 'Total', num: true, render: (r) => `<b>${money(r.total)}</b>` },
      { key: 'notas', label: 'Notas', wrap: true, render: (r) => esc(r.notas) },
    ],
    totals: (rows) => ({ total: `<b>${money(sumBy(rows, 'total'))}</b>` }),
    fields: () => [
      { name: 'fecha', label: 'Fecha', type: 'date', required: true, value: today(), max: today() },
      { name: 'proveedor', label: 'Proveedor', maxlength: 80, placeholder: 'Nombre del proveedor' },
      { name: 'tipo', label: 'Tipo de insumo', type: 'select', required: true, full: true, options: opt(cat.insumos.map((i) => ({ i })), 'i', 'i', 'Selecciona un insumo') },
      { name: 'cantidad', label: 'Cantidad', type: 'number', required: true, min: 0.001, step: 'any', inputmode: 'decimal' },
      { name: 'costo_unitario', label: 'Costo unitario ($)', type: 'number', required: true, min: 0, step: 'any', inputmode: 'decimal' },
      { name: 'notas', label: 'Notas', type: 'textarea', full: true, maxlength: 500, placeholder: 'Factura, referencia u observaciones' },
    ],
  });
}
