// Vendedores de ruta y zonas. Los vendedores no entran al sistema; sus ventas las registra el encargado de su zona.
import { api } from '../api.js';
import { $, esc, icon, money, num, fmtDate, zoneColor } from '../utils.js';
import { tableHtml, formDialog, confirmDialog, toast } from '../ui.js';
import { state, loadCatalogs } from '../main.js';

export default async function ({ el }) {
  el.innerHTML = `
    <div class="page-head">
      <div><h2>Vendedores y zonas</h2><p>Cada vendedor pertenece a una zona y usa un camión. El encargado de despacho de esa zona le carga producto y registra sus ventas.</p></div>
      <button class="btn btn-primary" id="btnNew">${icon('plus')}Agregar vendedor</button>
    </div>
    <section class="card" style="margin-bottom:16px"><div id="sellersBox"><div class="skeleton"></div></div></section>
    <section class="card">
      <div class="card-head"><div><h3>Zonas</h3><p>Los encargados de despacho solo ven a los vendedores de su zona</p></div><button class="btn btn-sm" id="btnZone">${icon('plus')}Nueva zona</button></div>
      <div id="zonesBox"></div>
    </section>`;

  let sellers = [], zones = [], next = 'V-01';
  const truckOpts = () => [{ value: '', label: 'Sin camión' }, ...state.cat.camiones.map((c) => ({ value: c.id, label: `${c.codigo}${c.descripcion ? `, ${c.descripcion}` : ''}` }))];
  const zoneOpts = () => zones.filter((z) => z.activo).map((z) => ({ value: z.id, label: z.nombre }));

  async function load() {
    const [s, z] = await Promise.all([api('vendedores'), api('zonas')]);
    sellers = s.items; zones = z.items; next = s.siguiente;
    $('#sellersBox', el).innerHTML = tableHtml({ label: 'Vendedores', rows: sellers, empty: 'Todavía no hay vendedores.', columns: [
      { key: 'codigo', label: 'Código', render: (v) => `<b>${esc(v.codigo)}</b>` },
      { key: 'nombre', label: 'Vendedor', render: (v) => `<b>${esc(v.nombre)}</b>${v.telefono ? `<br><span class="muted" style="font-size:12.5px">${esc(v.telefono)}</span>` : ''}` },
      { key: 'zona', label: 'Zona', render: (v) => `<span class="zone-tag" style="--zc:${zoneColor(v.zona)}">${esc(v.zona)}</span>` },
      { key: 'camion', label: 'Camión', render: (v) => v.camion ? esc(v.camion) : (v.activo ? '<span class="pill danger">Sin camión</span>' : '—') },
      { key: 'stock', label: 'En su camión', num: true, render: (v) => num(v.stock.reduce((s, p) => s + p.disponible, 0)) },
      { key: 'ingresos_mes', label: 'Vendido este mes', num: true, render: (v) => money(v.ingresos_mes) },
      { key: 'ventas_total', label: 'Ventas totales', num: true },
      { key: 'ultima_venta', label: 'Última venta', render: (v) => v.ultima_venta ? fmtDate(v.ultima_venta) : '—' },
      { key: 'activo', label: 'Estado', render: (v) => v.activo ? '<span class="pill ok">Activo</span>' : '<span class="pill">Inactivo</span>' },
    ], actions: (v) => `<button class="btn btn-sm" data-edit="${v.id}">Editar</button>${v.activo ? `<button class="btn btn-sm btn-danger" data-del="${v.id}">Dar de baja</button>` : ''}` });
    $('#zonesBox', el).innerHTML = tableHtml({ label: 'Zonas', rows: zones, columns: [
      { key: 'nombre', label: 'Zona', render: (z) => `<span class="zone-tag" style="--zc:${zoneColor(z.nombre)}">${esc(z.nombre)}</span>` },
      { key: 'vendedores', label: 'Vendedores activos', num: true },
      { key: 'encargados', label: 'Encargados de despacho', num: true, render: (z) => z.encargados ? num(z.encargados) : '<span class="pill warn">Sin encargado</span>' },
      { key: 'activo', label: 'Estado', render: (z) => z.activo ? '<span class="pill ok">Activa</span>' : '<span class="pill">Inactiva</span>' },
    ], actions: (z) => `<button class="btn btn-sm" data-zone="${z.id}">Editar</button>` });
  }

  const after = async () => { await loadCatalogs(); await load(); };
  const sellerFields = (v) => [
    { name: 'codigo', label: 'Código', maxlength: 20, placeholder: v ? '' : next, hint: v ? '' : `vacío = ${next}` },
    { name: 'nombre', label: 'Nombre', required: true, maxlength: 60 },
    { name: 'zona_id', label: 'Zona', type: 'select', required: true, options: zoneOpts() },
    { name: 'camion_id', label: 'Camión que usa', type: 'select', options: truckOpts() },
    { name: 'telefono', label: 'Teléfono', maxlength: 20, placeholder: 'ej. 7777-1234', inputmode: 'tel' },
    ...(v ? [{ name: 'activo', label: 'Vendedor activo', type: 'checkbox', full: true }] : []),
  ];
  const openSeller = (v) => formDialog({ title: v ? `Editar a ${v.nombre}` : 'Agregar vendedor', sub: v ? v.codigo : 'No necesita usuario ni contraseña.',
    fields: sellerFields(v), values: v || {}, submitText: v ? 'Guardar cambios' : 'Agregar vendedor',
    onSubmit: (x) => api(v ? `vendedores/${v.id}` : 'vendedores', { method: v ? 'PUT' : 'POST', body: x }) }).then(after);
  const openZone = (z) => formDialog({ title: z ? `Editar zona ${z.nombre}` : 'Nueva zona', values: z || {},
    fields: [{ name: 'nombre', label: 'Nombre de la zona', required: true, maxlength: 60, full: true }, ...(z ? [{ name: 'activo', label: 'Zona activa', type: 'checkbox', full: true }] : [])],
    onSubmit: (x) => api(z ? `zonas/${z.id}` : 'zonas', { method: z ? 'PUT' : 'POST', body: x }) }).then(after);

  $('#btnNew', el).addEventListener('click', () => openSeller(null));
  $('#btnZone', el).addEventListener('click', () => openZone(null));
  el.addEventListener('click', async (e) => {
    const ed = e.target.closest('[data-edit]'), del = e.target.closest('[data-del]'), zb = e.target.closest('[data-zone]');
    if (ed) openSeller(sellers.find((v) => v.id === Number(ed.dataset.edit)));
    if (zb) openZone(zones.find((z) => z.id === Number(zb.dataset.zone)));
    if (del) {
      const v = sellers.find((x) => x.id === Number(del.dataset.del));
      const msg = v.ventas_total ? 'Tiene ventas registradas: se marca como inactivo, se le quita el camión y su historial se conserva en los reportes.' : 'Todavía no tiene ventas, así que se elimina.';
      if (!(await confirmDialog(msg, { title: `¿Dar de baja a ${v.nombre}?`, okText: 'Dar de baja', danger: true }))) return;
      try { toast((await api(`vendedores/${v.id}`, { method: 'DELETE' })).message); after(); }
      catch (err) { toast(err.message, 'error'); }
    }
  });
  await load();
}
