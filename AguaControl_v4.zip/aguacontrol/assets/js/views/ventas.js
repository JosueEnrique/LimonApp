// Ventas: remisión del encargado de despacho (ventas de los vendedores de su zona); tabla para el admin.
import { api } from '../api.js';
import { $, esc, fmtDate, today, num, money, zoneColor } from '../utils.js';
import { productTiles, sellerTiles, stepperHtml, kpi } from '../ui.js';
import { crudPage, opt, sumBy } from './crud.js';
import { wireCapture, recentList, wireRecent } from './captura.js';

const sellerLabel = (v) => `${v.nombre} (${v.codigo}, ${v.zona})`;

const adminFields = (cat) => () => [
  { name: 'fecha', label: 'Fecha', type: 'date', required: true, value: today(), max: today() },
  { name: 'cliente', label: 'Cliente', maxlength: 80, placeholder: 'Nombre del cliente' },
  { name: 'vendedor_id', label: 'Vendedor', type: 'select', hint: 'vacío = venta directa', options: opt(cat.vendedores || [], 'id', sellerLabel, 'Venta directa en planta') },
  { name: 'producto_id', label: 'Producto', type: 'select', required: true, options: opt(cat.productos, 'id', 'nombre') },
  { name: 'cantidad', label: 'Cantidad', type: 'number', required: true, min: 0.001, step: 'any', inputmode: 'decimal' },
  { name: 'precio_unitario', label: 'Precio unitario ($)', type: 'number', required: true, min: 0, step: 'any', inputmode: 'decimal' },
  { name: 'combustible', label: 'Combustible del envío ($)', type: 'number', min: 0, step: 'any', value: 0, inputmode: 'decimal' },
  { name: 'notas', label: 'Notas', type: 'textarea', full: true, maxlength: 500 },
];
const dispatchFields = (cat) => () => adminFields(cat)().map((f) => f.name === 'vendedor_id' ? { ...f, hint: '', required: true, options: opt(cat.vendedores, 'id', sellerLabel) } : f);

export default async function (ctx) {
  return ctx.state.user.rol === 'admin' ? adminView(ctx) : dispatchView(ctx);
}

async function adminView({ el, state }) {
  const cat = state.cat;
  const sel = (name, items, label, blank) => `<label class="field"><span>${label}</span><select name="${name}"><option value="">${blank}</option>${items.map((i) => `<option value="${i.id}">${esc(i.nombre ?? i.codigo)}</option>`).join('')}</select></label>`;
  await crudPage({
    el, type: 'ventas', title: 'Ventas', newText: 'Registrar venta',
    sub: 'Las ventas de un vendedor salen de su camión; las ventas directas, de la planta.', searchHint: 'Cliente, producto, vendedor…',
    extraFilters: sel('zona_id', cat.zonas, 'Zona', 'Todas') + sel('vendedor_id', cat.vendedores || [], 'Vendedor', 'Todos'),
    columns: [
      { key: 'fecha', label: 'Fecha', render: (r) => fmtDate(r.fecha) },
      { key: 'zona', label: 'Zona', render: (r) => r.zona ? `<span class="zone-tag" style="--zc:${zoneColor(r.zona)}">${esc(r.zona)}</span>` : '<span class="muted">Directa</span>' },
      { key: 'vendedor', label: 'Vendedor', render: (r) => r.vendedor ? `<b>${esc(r.vendedor)}</b>` : '—' },
      { key: 'cliente', label: 'Cliente' },
      { key: 'producto', label: 'Producto' },
      { key: 'cantidad', label: 'Cant.', num: true, render: (r) => num(r.cantidad) },
      { key: 'precio_unitario', label: 'Precio', num: true, render: (r) => money(r.precio_unitario) },
      { key: 'total', label: 'Total', num: true, render: (r) => `<b>${money(r.total)}</b>` },
      { key: 'combustible', label: 'Combustible', num: true, render: (r) => money(r.combustible) },
      { key: 'camion', label: 'Sale de', render: (r) => esc(r.camion || 'Planta') },
      { key: 'usuario', label: 'Registró' },
    ],
    totals: (rows) => ({ cantidad: num(sumBy(rows, 'cantidad')), total: `<b>${money(sumBy(rows, 'total'))}</b>`, combustible: money(sumBy(rows, 'combustible')) }),
    fields: adminFields(cat),
  });
}

async function dispatchView({ el, state }) {
  const cat = state.cat, u = state.user;
  el.innerHTML = `
    <div class="kpis" id="kpis" style="margin-bottom:16px"><div class="kpi"><div class="kpi-label">Cargando…</div></div></div>
    <div class="grid-main">
      <form class="capture" id="capture" novalidate>
        <div class="capture-head">
          <div><h2>Remisión de venta</h2><p>Lo que vendió el vendedor en su ruta. Sale de su camión.</p></div>
          <div class="slip-meta"><b><span class="zone-tag" style="--zc:${zoneColor(u.zona)}">Zona ${esc(u.zona || '')}</span></b>${esc(fmtDate(today()))}<br>${esc(u.nombre)}</div>
        </div>
        <div class="capture-body">
          <div><div class="step-label"><span class="n">1</span>Vendedor</div>${sellerTiles('vendedor_id', cat.vendedores)}<span class="field-error" data-error-for="vendedor_id" hidden></span></div>
          <div><div class="step-label"><span class="n">2</span>Producto <span class="muted" style="font-weight:400">(cifra = queda en su camión)</span></div><div id="productTiles"></div><span class="field-error" data-error-for="producto_id" hidden></span></div>
          <div><div class="step-label"><span class="n">3</span>Unidades vendidas</div>${stepperHtml('cantidad', { min: 1, quick: [5, 10, 25], label: 'Cantidad vendida' })}</div>
          <div class="form-grid">
            <label class="field"><span>Precio unitario ($)</span><input name="precio_unitario" type="number" min="0" step="any" inputmode="decimal" required><span class="field-error" data-error-for="precio_unitario" hidden></span></label>
            <label class="field"><span>Cliente</span><input name="cliente" maxlength="80" placeholder="Nombre del cliente o negocio"></label>
            <label class="field"><span>Combustible ($) <span class="hint">opcional</span></span><input name="combustible" type="number" min="0" step="any" value="0" inputmode="decimal"><span class="field-error" data-error-for="combustible" hidden></span></label>
            <label class="field"><span>Fecha</span><input type="date" name="fecha" value="${today()}" max="${today()}" required></label>
            <label class="field full"><span>Notas <span class="hint">opcional</span></span><input name="notas" maxlength="500" placeholder="Forma de pago o referencia"></label>
          </div>
          <div class="total-box"><span id="summary">Total de la venta</span><b id="totalBox">$0.00</b></div>
          <button class="btn btn-save btn-lg btn-block" type="submit">Guardar venta</button>
        </div>
      </form>
      <div class="stack">
        <section class="card"><div class="card-head"><div><h3>Camión del vendedor</h3><p id="truckSub">Lo que le queda para vender</p></div></div><div id="truckBox"></div></section>
        <section class="card"><div class="card-head"><div><h3>Tus últimas ventas registradas</h3><p>Puedes corregir las de hoy</p></div></div><div id="recentBox"></div></section>
      </div>
    </div>`;

  const form = $('#capture', el);
  const price = form.elements.namedItem('precio_unitario');
  let recent = [], trucks = [];
  price.addEventListener('input', () => { price.dataset.touched = '1'; });

  const sellerId = () => form.querySelector('[name=vendedor_id]:checked')?.value;
  const truckOf = () => trucks.find((t) => String(t.vendedor_id) === String(sellerId()));
  const dispOf = (p) => truckOf()?.productos.find((x) => x.producto_id === p.id)?.disponible ?? 0;

  function paintSeller() {
    const keep = form.querySelector('[name=producto_id]:checked')?.value;
    const first = cat.productos.find((p) => dispOf(p) > 0)?.id;
    $('#productTiles', el).innerHTML = productTiles('producto_id', cat.productos, { selected: keep && dispOf({ id: Number(keep) }) > 0 ? keep : first, badge: dispOf });
    const t = truckOf();
    const v = cat.vendedores.find((x) => String(x.id) === String(sellerId()));
    $('#truckSub', el).textContent = v ? `${v.nombre}, camión ${v.camion || '—'}` : 'Elige un vendedor';
    const items = t?.productos.filter((p) => p.cargado || p.vendido) ?? [];
    $('#truckBox', el).innerHTML = items.length
      ? `<div class="mini-list">${items.map((p) => `<div class="mini-row"><span>${esc(p.producto)}<br><span class="muted" style="font-size:12.5px">${num(p.cargado)} cargadas, ${num(p.vendido)} vendidas</span></span><b style="font-size:20px;font-stretch:112%;color:${p.disponible > 0 ? 'inherit' : 'var(--error)'}">${num(p.disponible)}</b></div>`).join('')}</div>`
      : '<div class="empty"><b>Camión vacío</b>Primero carga producto a este vendedor en “Cargar camión”.</div>';
    delete price.dataset.touched;
    update();
  }

  function update() {
    const pid = form.querySelector('[name=producto_id]:checked')?.value;
    const p = cat.productos.find((x) => String(x.id) === String(pid));
    if (p && !price.dataset.touched) price.value = p.precio_sugerido ?? '';
    const q = Number(form.elements.namedItem('cantidad').value) || 0;
    $('#totalBox', el).textContent = money(q * (Number(price.value) || 0));
    $('#summary', el).textContent = p ? `${p.nombre}, quedan ${num(dispOf(p))} en el camión` : 'Total de la venta';
  }

  async function refresh() {
    const [mine, list] = await Promise.all([api('mi'), api('ventas', { query: { limit: 10 } })]);
    trucks = mine.camiones; recent = list.items;
    $('#kpis', el).innerHTML = kpi(`Ventas de hoy en ${u.zona}`, num(mine.ventas.ventas), `${num(mine.ventas.unidades)} unidades`)
      + kpi('Ingresos de hoy', money(mine.ventas.ingresos), 'Registrados en tu zona')
      + kpi('Producto en ruta', num(trucks.reduce((s, t) => s + t.productos.reduce((a, p) => a + p.disponible, 0), 0)), 'En los camiones de tu zona');
    $('#recentBox', el).innerHTML = recentList(recent, { type: 'ventas', empty: 'Aún no registras ventas.',
      line: (r) => `<b>${esc(r.vendedor || '—')}</b>: ${esc(r.producto)} × ${num(r.cantidad)}, <b>${money(r.total)}</b><br><span class="muted" style="font-size:12.5px">${esc(r.cliente || 'Cliente sin nombre')}</span>` });
    paintSeller();
  }

  wireCapture(form, {
    route: 'ventas', onChange: update,
    onSaved: () => { for (const n of ['cantidad', 'cliente', 'notas']) form.elements.namedItem(n).value = ''; form.elements.namedItem('combustible').value = 0; refresh(); },
  });
  form.addEventListener('change', (e) => {
    if (e.target.name === 'vendedor_id') paintSeller();
    if (e.target.name === 'producto_id') { delete price.dataset.touched; update(); }
  });
  wireRecent(el, { type: 'ventas', getRows: () => recent, fields: dispatchFields(cat), after: refresh });
  await refresh();
}
