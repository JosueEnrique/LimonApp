// Respaldo, importación (incluye el AguaControl HTML anterior) y limpieza.
import { api, apiUrl } from '../api.js';
import { $, icon, downloadFile } from '../utils.js';
import { toast, confirmDialog } from '../ui.js';

export default async function ({ el }) {
  el.innerHTML = `
    <div class="page-head"><div><h2>Respaldo y datos</h2><p>La información vive en la base de datos del servidor. Descarga respaldos con regularidad.</p></div></div>
    <div class="grid-2">
      <div class="card"><div class="card-head"><div><h3>Descargar respaldo completo</h3><p>Archivo JSON con todos los movimientos, camiones, usuarios (sin contraseñas) y costos.</p></div></div>
        <button class="btn btn-primary" id="btnJson">${icon('download')}Descargar respaldo JSON</button></div>

      <div class="card"><div class="card-head"><div><h3>Exportar tablas para Excel / Calc</h3><p>Archivos CSV separados por punto y coma.</p></div></div>
        <div style="display:flex;flex-wrap:wrap;gap:8px">
          ${['entradas', 'produccion', 'cargas', 'ventas'].map((t) => `<button class="btn" data-csv="${t}">${icon('download')}${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}
        </div></div>

      <div class="card"><div class="card-head"><div><h3>Importar datos</h3><p>Acepta respaldos de esta versión y también el JSON del AguaControl HTML anterior.</p></div></div>
        <div class="stack" style="gap:12px">
          <label class="field"><span>Archivo de respaldo (.json)</span><input type="file" id="file" accept=".json,application/json"></label>
          <div class="segmented"><label><input type="radio" name="modo" value="agregar" checked><span>Agregar a lo existente</span></label><label><input type="radio" name="modo" value="reemplazar"><span>Reemplazar movimientos</span></label></div>
          <div><button class="btn" id="btnImport">Importar</button></div>
        </div></div>

      <div class="card"><div class="card-head"><div><h3 style="color:var(--danger)">Borrar movimientos</h3><p>Elimina entradas, producción, cargas y ventas. Usuarios, camiones y costos se conservan. No se puede deshacer sin un respaldo.</p></div></div>
        <button class="btn btn-danger" id="btnWipe">Borrar todos los movimientos</button></div>
    </div>`;

  const dl = (route, q, name) => downloadFile(apiUrl(route, q), name).catch((e) => toast(e.message, 'error'));
  $('#btnJson', el).addEventListener('click', () => dl('respaldo', {}, 'aguacontrol-respaldo.json'));
  el.addEventListener('click', (e) => { const b = e.target.closest('[data-csv]'); if (b) dl('respaldo/csv', { tabla: b.dataset.csv }, `${b.dataset.csv}.csv`); });

  $('#btnImport', el).addEventListener('click', async () => {
    const file = $('#file', el).files[0];
    if (!file) return toast('Selecciona primero un archivo JSON.', 'warn');
    if (file.size > 8 * 1024 * 1024) return toast('El archivo es demasiado grande (máximo 8 MB).', 'error');
    let datos;
    try { datos = JSON.parse(await file.text()); } catch { return toast('El archivo no es un JSON válido.', 'error'); }
    const modo = el.querySelector('[name=modo]:checked').value;
    if (modo === 'reemplazar' && !(await confirmDialog('Se borrarán todos los movimientos actuales y se reemplazarán por los del archivo.', { title: '¿Reemplazar datos?', okText: 'Reemplazar', danger: true }))) return;
    try { const r = await api('respaldo/importar', { method: 'POST', body: { datos, modo } }); toast(r.message, 'ok', 7000); $('#file', el).value = ''; }
    catch (err) { toast(err.message, 'error'); }
  });

  $('#btnWipe', el).addEventListener('click', async () => {
    const ok = await confirmDialog('Se borrarán todos los movimientos. Descarga un respaldo antes si no lo tienes.', { title: 'Borrar movimientos', okText: 'Borrar todo', danger: true, input: { label: 'Escribe BORRAR para confirmar', expect: 'BORRAR', placeholder: 'BORRAR' } });
    if (!ok) return;
    try { toast((await api('respaldo/borrar', { method: 'POST', body: { confirmar: 'BORRAR' } })).message); }
    catch (err) { toast(err.message, 'error'); }
  });
}
