// AguaControl · componentes de interfaz reutilizables
import { esc, icon, $, $$, formValues, money, num, productIcon, zoneColor } from './utils.js';

const SERIES = ['var(--garrafon)', 'var(--z-sanmiguel)', 'var(--z-morazan)', 'var(--z-otra)', 'var(--senal)'];
import { ApiError } from './api.js';

// ---------------------------------------------------------------- avisos
export function toast(message, type = 'ok', ms = 3800) {
  const box = $('#toasts');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  box.append(el);
  setTimeout(() => el.remove(), ms);
}

// --------------------------------------------------------------- diálogo
const dlg = () => $('#dlg');

export function openDialog({ title, sub = '', html = '', wide = false }) {
  const d = dlg();
  $('#dlgTitle').textContent = title;
  $('#dlgSub').textContent = sub;
  $('#dlgSub').hidden = !sub;
  $('#dlgContent').innerHTML = html;
  d.classList.toggle('wide', wide);
  if (!d.open) d.showModal();
  const first = $('#dlgContent [autofocus], #dlgContent input:not([type=hidden]):not([readonly]), #dlgContent select, #dlgContent button');
  first?.focus();
  return $('#dlgContent');
}
export function closeDialog() { if (dlg().open) dlg().close(); }

document.addEventListener('click', (e) => { if (e.target.closest('#dlg [data-close]')) closeDialog(); });

/** Confirmación con botones propios (en lugar de window.confirm). */
export function confirmDialog(message, { title = '¿Confirmas?', okText = 'Confirmar', danger = false, input = null } = {}) {
  return new Promise((resolve) => {
    const c = openDialog({ title, html: `
      <p style="color:var(--ink-2)">${esc(message)}</p>
      ${input ? `<label class="field" style="margin-top:14px"><span>${esc(input.label)}</span><input name="confirmText" autocomplete="off" placeholder="${esc(input.placeholder || '')}"></label>` : ''}
      <div class="form-actions">
        <button class="btn" type="button" data-answer="0">Cancelar</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" type="button" data-answer="1">${esc(okText)}</button>
      </div>` });
    let done = false;
    const finish = (v) => { if (done) return; done = true; dlg().removeEventListener('close', onClose); closeDialog(); resolve(v); };
    const onClose = () => finish(false);
    dlg().addEventListener('close', onClose);
    c.addEventListener('click', (e) => {
      const b = e.target.closest('[data-answer]'); if (!b) return;
      if (b.dataset.answer === '1' && input) {
        const val = $('[name=confirmText]', c).value.trim();
        if (val !== input.expect) { $('[name=confirmText]', c).setAttribute('aria-invalid', 'true'); return; }
      }
      finish(b.dataset.answer === '1');
    });
  });
}

// ------------------------------------------------------------- campos
export function fieldHtml(f, value) {
  const v = value ?? f.value ?? '';
  const req = f.required ? 'required' : '';
  const attrs = [
    f.min !== undefined ? `min="${f.min}"` : '', f.max !== undefined ? `max="${f.max}"` : '',
    f.step !== undefined ? `step="${f.step}"` : '', f.maxlength ? `maxlength="${f.maxlength}"` : '',
    f.placeholder ? `placeholder="${esc(f.placeholder)}"` : '', f.readonly ? 'readonly' : '',
    f.autocomplete ? `autocomplete="${f.autocomplete}"` : '', f.pattern ? `pattern="${esc(f.pattern)}"` : '',
    f.inputmode ? `inputmode="${f.inputmode}"` : '',
  ].join(' ');
  let control;
  if (f.type === 'select') {
    control = `<select name="${f.name}" ${req}>${(f.options || []).map((o) =>
      `<option value="${esc(o.value)}" ${String(o.value) === String(v) ? 'selected' : ''}>${esc(o.label)}</option>`).join('')}</select>`;
  } else if (f.type === 'textarea') {
    control = `<textarea name="${f.name}" ${req} ${attrs}>${esc(v)}</textarea>`;
  } else if (f.type === 'checkbox') {
    return `<label class="field ${f.full ? 'full' : ''}" style="grid-auto-flow:column;justify-content:start;align-items:center;gap:8px">
      <input type="checkbox" name="${f.name}" ${v ? 'checked' : ''} style="width:18px;min-height:18px"><span>${esc(f.label)}</span></label>`;
  } else {
    control = `<input name="${f.name}" type="${f.type || 'text'}" value="${esc(v)}" ${req} ${attrs}>`;
  }
  return `<label class="field ${f.full ? 'full' : ''}"><span>${esc(f.label)}${f.hint ? ` <span class="hint">${esc(f.hint)}</span>` : ''}</span>${control}<span class="field-error" data-error-for="${f.name}" hidden></span></label>`;
}

export function clearErrors(form) {
  $$('[aria-invalid]', form).forEach((el) => el.removeAttribute('aria-invalid'));
  $$('[data-error-for]', form).forEach((el) => { el.hidden = true; el.textContent = ''; });
  const a = $('.form-alert', form); if (a) a.hidden = true;
}

export function showErrors(form, err) {
  const errors = err?.data?.errors || {};
  let placed = false;
  for (const [name, msg] of Object.entries(errors)) {
    const input = form.elements.namedItem(name);
    const slot = $(`[data-error-for="${name}"]`, form);
    if (input?.setAttribute) input.setAttribute('aria-invalid', 'true');
    if (slot) { slot.textContent = msg; slot.hidden = false; placed = true; }
  }
  let alert = $('.form-alert', form);
  if (!alert) {
    alert = document.createElement('div'); alert.className = 'form-alert'; alert.setAttribute('role', 'alert');
    const submit = form.querySelector('.capture-body [type=submit]');
    if (submit) submit.before(alert); else form.prepend(alert);
  }
  alert.textContent = err.message; alert.hidden = placed && Object.keys(errors).length === 1;
  form.querySelector('[aria-invalid="true"]')?.focus();
}

/**
 * Envía datos y resuelve el aviso de stock insuficiente:
 * si el admin puede forzarlo, pregunta y reintenta con forzar=true.
 */
export async function sendWithStockCheck(send, values) {
  try { return await send(values); }
  catch (err) {
    if (err instanceof ApiError && err.status === 409 && err.data?.code === 'stock' && err.data.puede_forzar) {
      const ok = await confirmDialog(`${err.message} ¿Quieres guardarlo de todos modos?`, { title: 'Stock insuficiente', okText: 'Guardar igual' });
      if (ok) return await send({ ...values, forzar: true });
      return null;
    }
    throw err;
  }
}

/** Abre un formulario en diálogo. onSubmit recibe los valores y debe devolver la respuesta de la API. */
export function formDialog({ title, sub, fields, values = {}, submitText = 'Guardar', onSubmit, wide = false }) {
  const c = openDialog({ title, sub, wide, html: `
    <form novalidate>
      <div class="form-grid">${fields.map((f) => fieldHtml(f, values[f.name])).join('')}</div>
      <div class="form-actions"><button class="btn" type="button" data-close>Cancelar</button><button class="btn btn-primary" type="submit">${esc(submitText)}</button></div>
    </form>` });
  const form = $('form', c);
  return new Promise((resolve) => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); clearErrors(form);
      const btn = $('[type=submit]', form); btn.disabled = true;
      try {
        const res = await sendWithStockCheck(onSubmit, formValues(form));
        if (res) { closeDialog(); if (res.message) toast(res.message); resolve(res); }
      } catch (err) { showErrors(form, err); }
      finally { btn.disabled = false; }
    });
  });
}

// --------------------------------------------------------------- tablas
/**
 * columns: [{ key, label, num, wrap, render(row) }]
 * actions(row) → HTML de botones
 */
export function tableHtml({ label, columns, rows, empty = 'Todavía no hay registros.', actions, foot }) {
  if (!rows?.length) return `<div class="table-wrap"><div class="empty"><b>Sin datos</b>${esc(empty)}</div></div>`;
  const head = columns.map((c) => `<th scope="col" class="${c.num ? 'num' : ''}">${esc(c.label)}</th>`).join('') + (actions ? '<th scope="col" class="num">Acciones</th>' : '');
  const body = rows.map((r) => `<tr>${columns.map((c) => {
    const v = c.render ? c.render(r) : esc(r[c.key] ?? '—');
    return `<td data-label="${esc(c.label)}" class="${c.num ? 'num' : ''} ${c.wrap ? 'wrap' : ''}">${v === '' ? '—' : v}</td>`;
  }).join('')}${actions ? `<td class="actions">${actions(r)}</td>` : ''}</tr>`).join('');
  const footer = foot ? `<tfoot><tr>${columns.map((c, i) => `<td data-label="${esc(c.label)}" class="${c.num ? 'num' : ''}">${foot[c.key] ?? (i === 0 ? 'Total' : '')}</td>`).join('')}${actions ? '<td></td>' : ''}</tr></tfoot>` : '';
  return `<div class="table-wrap" tabindex="0" role="region" aria-label="${esc(label)}"><table class="table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody>${footer}</table></div>`;
}

export const kpi = (label, value, sub = '', tone = '') =>
  `<div class="kpi ${tone}"><div class="kpi-label">${esc(label)}</div><div class="kpi-value">${value}</div><div class="kpi-sub">${sub}</div></div>`;

export const editButtons = (type, row) => row.editable === false ? '<span class="muted" style="font-size:12px">Cerrado</span>' :
  `<button class="btn btn-sm" data-edit="${type}" data-id="${row.id}">Editar</button><button class="btn btn-sm btn-danger" data-del="${type}" data-id="${row.id}">Borrar</button>`;

// --------------------------------------------------- tarjeta de captura
export function productTiles(name, products, { selected, badge } = {}) {
  return `<div class="tiles" role="radiogroup">${products.map((p, i) => {
    const b = badge ? badge(p) : null;
    return `<label class="tile">
      <input type="radio" name="${name}" value="${p.id}" ${String(selected ?? (i === 0 ? p.id : '')) === String(p.id) ? 'checked' : ''} required>
      <span class="tile-box">${icon(productIcon(p), '')}<b>${esc(p.nombre)}</b><small>${num(p.litros)} L</small></span>
      ${b !== null && b !== undefined ? `<span class="badge ${Number(b) <= 0 ? 'zero' : ''}">${num(b)} disp.</span>` : ''}
    </label>`;
  }).join('')}</div>`;
}

/** Vendedores como fichas: la franja izquierda es el color de su zona. */
export function sellerTiles(name, sellers, { selected, sub } = {}) {
  if (!sellers.length) return '<div class="notice warn">No hay vendedores activos en tu zona. Pide al administrador que los registre.</div>';
  return `<div class="tiles wide" role="radiogroup">${sellers.map((v, i) => `<label class="tile">
      <input type="radio" name="${name}" value="${v.id}" ${String(selected ?? (i === 0 ? v.id : '')) === String(v.id) ? 'checked' : ''} ${v.camion_id ? '' : 'disabled'} required>
      <span class="tile-box" style="--zc:${zoneColor(v.zona)}"><b>${esc(v.nombre)}</b><small>${esc(v.codigo)}, ${v.camion ? `camión ${esc(v.camion)}` : 'sin camión'}</small>${sub ? `<small>${sub(v)}</small>` : ''}</span>
    </label>`).join('')}</div>`;
}

export function stepperHtml(name, { value = '', min = 1, step = 1, label = 'Cantidad', small = false, quick = [] } = {}) {
  return `<div class="stepper ${small ? 'sm' : ''}">
      <button type="button" data-step="-${step}" aria-label="Restar">−</button>
      <input name="${name}" type="number" inputmode="decimal" min="${min}" step="any" value="${value}" placeholder="0" aria-label="${esc(label)}" required>
      <button type="button" data-step="${step}" aria-label="Sumar">+</button>
    </div>${quick.length ? `<div class="quick-adds">${quick.map((q) => `<button type="button" class="btn btn-sm" data-add="${q}">+${q}</button>`).join('')}</div>` : ''}
    <span class="field-error" data-error-for="${name}" hidden></span>`;
}

/** Hace funcionar los botones − / + / +N dentro de un contenedor. */
export function wireSteppers(root, onChange = () => {}) {
  root.addEventListener('click', (e) => {
    const b = e.target.closest('[data-step],[data-add]'); if (!b) return;
    const wrap = b.closest('.stepper') || b.closest('.quick-adds')?.previousElementSibling;
    const input = $('input', wrap);
    const min = Number(input.min || 0);
    const delta = Number(b.dataset.step ?? b.dataset.add);
    input.value = String(Math.max(min, Math.round(((Number(input.value) || 0) + delta) * 1000) / 1000));
    input.dispatchEvent(new Event('input', { bubbles: true }));
    onChange();
  });
}

// -------------------------------------------------------------- gráficos
export function barList(items, { value = 'value', label = 'label', fmt = money, color } = {}) {
  if (!items.length) return '<div class="empty">Sin datos en el periodo.</div>';
  const max = Math.max(...items.map((i) => Number(i[value]) || 0), 1);
  return `<div class="bars">${items.map((i, n) => `<div class="bar-row">
    <span>${esc(i[label])}</span>
    <span class="bar-track"><span class="bar-fill" style="width:${Math.max(2, (Number(i[value]) || 0) / max * 100)}%;--c:${color ? color(i, n) : 'var(--garrafon)'}"></span></span>
    <b>${fmt(i[value])}</b></div>`).join('')}</div>`;
}

/** Columnas por día (apiladas por serie). data: [{fecha, valores:{serie: n}}] */
export function columnChart(data, series, colors = SERIES, { stacked = true } = {}) {
  const col = (k, si) => (typeof colors === 'function' ? colors(k, si) : colors[si % colors.length]);
  if (!data.length) return '<div class="empty">Sin ventas en el periodo.</div>';
  const W = 720, H = 220, pad = { l: 46, r: 8, t: 10, b: 26 };
  const totals = data.map((d) => stacked ? series.reduce((s, k) => s + (d.valores[k] || 0), 0) : Math.max(0, ...series.map((k) => d.valores[k] || 0)));
  const max = Math.max(...totals, 1);
  const bw = (W - pad.l - pad.r) / data.length;
  const y = (v) => H - pad.b - (v / max) * (H - pad.t - pad.b);
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((t) => max * t);
  const labelEvery = Math.ceil(data.length / 10);
  let bars = '';
  data.forEach((d, i) => {
    let acc = 0;
    const slot = Math.min(bw * 0.72, stacked ? 34 : 44);
    const x0 = pad.l + i * bw + (bw - slot) / 2;
    series.forEach((k, si) => {
      const v = d.valores[k] || 0; if (!v) return;
      let x = x0, w = slot, y1, y0;
      if (stacked) { y1 = y(acc + v); y0 = y(acc); acc += v; }
      else { w = slot / series.length; x = x0 + si * w; y1 = y(v); y0 = y(0); }
      bars += `<rect x="${x}" y="${y1}" width="${Math.max(1, w - (stacked ? 0 : 1))}" height="${Math.max(0.5, y0 - y1)}" rx="1.5" fill="${col(k, si)}"><title>${esc(d.fecha)}, ${esc(k)}: ${money(v)}</title></rect>`;
    });
    if (i % labelEvery === 0) bars += `<text x="${pad.l + i * bw + bw / 2}" y="${H - 8}" text-anchor="middle">${esc(d.fecha.slice(8, 10))}/${esc(d.fecha.slice(5, 7))}</text>`;
  });
  const grid = ticks.map((t) => `<line x1="${pad.l}" x2="${W - pad.r}" y1="${y(t)}" y2="${y(t)}"/><text x="${pad.l - 6}" y="${y(t) + 3}" text-anchor="end">$${Math.round(t)}</text>`).join('');
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Montos por día"><g class="grid">${grid}</g>${bars}</svg>
    ${series.length > 1 ? `<div class="legend">${series.map((s, i) => `<span><i style="background:${col(s, i)}"></i>${esc(s)}</span>`).join('')}</div>` : ''}`;
}
