// AguaControl · utilidades de formato y DOM

const moneyFmt = new Intl.NumberFormat('es-SV', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2 });
const numFmt = new Intl.NumberFormat('es-SV', { maximumFractionDigits: 3 });
const dateFmt = new Intl.DateTimeFormat('es-SV', { day: '2-digit', month: 'short', year: 'numeric' });

export const money = (n) => moneyFmt.format(Number(n) || 0);
export const num = (n) => numFmt.format(Number(n) || 0);
const pctFmt = new Intl.NumberFormat('es-SV', { maximumFractionDigits: 1 });
export const pct = (n) => `${pctFmt.format(Number(n) || 0)} %`;

/** Escapa texto para insertarlo en HTML. Úsalo con TODO dato que venga del usuario o del servidor. */
export const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function isoDate(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
export const today = () => isoDate();
export const monthStart = () => { const d = new Date(); return isoDate(new Date(d.getFullYear(), d.getMonth(), 1)); };
export function fmtDate(iso) {
  if (!iso) return '—';
  const [y, m, d] = String(iso).slice(0, 10).split('-').map(Number);
  return dateFmt.format(new Date(y, m - 1, d));
}
export function fmtDateTime(s) {
  if (!s) return '—';
  const [d, t] = String(s).split(' ');
  return `${fmtDate(d)} ${t ? t.slice(0, 5) : ''}`;
}

export function currentShift() {
  const h = new Date().getHours();
  return h < 12 ? 'Mañana' : h < 19 ? 'Tarde' : 'Noche';
}

export function initials(name = '') {
  const p = name.trim().split(/\s+/).filter(Boolean);
  return ((p[0]?.[0] ?? '?') + (p.length > 1 ? p[p.length - 1][0] : (p[0]?.[1] ?? ''))).toUpperCase();
}

/** Color estable por nombre, para avatares. */
export function avatarColor(name = '') {
  const palette = ['#1d4e9e', '#2f7d4f', '#c25a2c', '#6b5ca5', '#8a6d1d', '#2b6f7e', '#9c3d5c'];
  let h = 0; for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return palette[h % palette.length];
}

export const icon = (id, cls = 'icon') => `<svg class="${cls}" aria-hidden="true"><use href="#i-${id}"/></svg>`;

export function debounce(fn, ms = 250) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

/** Datos de un formulario como objeto (los checkbox salen true/false). */
export function formValues(form) {
  const out = {};
  for (const el of form.elements) {
    if (!el.name || el.disabled) continue;
    if (el.type === 'checkbox') out[el.name] = el.checked;
    else if (el.type === 'radio') { if (el.checked) out[el.name] = el.value; }
    else out[el.name] = el.value;
  }
  return out;
}

export function productIcon(p) {
  const k = p?.clave ?? '';
  return k === 'fardo' ? 'pack' : (k === 'galon' || k === 'garrafon') ? 'jug' : 'bottle';
}

/** Descarga un archivo generado por la API respetando la sesión. */
export async function downloadFile(url, fallbackName) {
  const res = await fetch(url, { credentials: 'same-origin' });
  if (!res.ok) {
    let msg = 'No se pudo descargar el archivo.';
    try { msg = (await res.json()).error || msg; } catch {}
    throw new Error(msg);
  }
  const blob = await res.blob();
  const name = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') || '')?.[1] || fallbackName;
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1500);
}

/** Color de cada zona (también usado en gráficos). */
export function zoneColor(name = '') {
  const n = String(name).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (n.includes('planta')) return 'var(--z-planta)';
  if (n.includes('morazan')) return 'var(--z-morazan)';
  if (n.includes('miguel')) return 'var(--z-sanmiguel)';
  if (n.includes('directa')) return 'var(--gris)';
  return 'var(--z-otra)';
}
