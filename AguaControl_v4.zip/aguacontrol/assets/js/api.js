// AguaControl · cliente de la API PHP

let csrf = '';
export const setCsrf = (t) => { csrf = t || ''; };

export class ApiError extends Error {
  constructor(status, data) {
    super(data?.error || `Error ${status}`);
    this.status = status;
    this.data = data || {};
  }
}

/**
 * api('ventas')                        → GET  api/?r=ventas
 * api('ventas', { query: {desde} })    → GET  con filtros
 * api('ventas', { method: 'POST', body })
 */
export async function api(route, { method = 'GET', body, query } = {}) {
  const qs = new URLSearchParams({ r: route });
  for (const [k, v] of Object.entries(query || {})) if (v !== undefined && v !== null && v !== '') qs.set(k, v);
  const opts = { method, credentials: 'same-origin', headers: { Accept: 'application/json' } };
  if (method !== 'GET') {
    opts.headers['Content-Type'] = 'application/json';
    opts.headers['X-CSRF-Token'] = csrf;
    opts.body = JSON.stringify(body ?? {});
  }

  let res;
  try { res = await fetch(`api/?${qs}`, opts); }
  catch { throw new ApiError(0, { error: 'No hay conexión con el servidor. Revisa que XAMPP/PHP esté encendido.' }); }

  let data = null;
  try { data = await res.json(); } catch { data = { error: 'Respuesta inválida del servidor.' }; }
  if (!res.ok) {
    const err = new ApiError(res.status, data);
    if (res.status === 401 || res.status === 419) window.dispatchEvent(new CustomEvent('session-expired', { detail: err }));
    throw err;
  }
  return data;
}

export const apiUrl = (route, query = {}) => `api/?${new URLSearchParams({ r: route, ...query })}`;
