<?php
/**
 * API de AguaControl. Todas las llamadas pasan por aquí:
 *   api/?r=ventas            GET lista · POST crea
 *   api/?r=ventas/15         PUT edita · DELETE borra
 *   api/?r=usuarios/3/password  POST restablece contraseña
 */
declare(strict_types=1);

require __DIR__ . '/../src/bootstrap.php';

header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
header('Referrer-Policy: same-origin');

try {
    Auth::start();
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $route = trim((string) ($_GET['r'] ?? ''), '/');
    if (!preg_match('#^[a-z]+(/\d+)?(/[a-z]+)?$#', $route)) throw new HttpError(404, 'Ruta no encontrada.');
    $parts = explode('/', $route);
    $res = $parts[0];
    $id = isset($parts[1]) && ctype_digit($parts[1]) ? (int) $parts[1] : null;
    $action = $parts[2] ?? ($id === null ? ($parts[1] ?? null) : null);

    // Todo lo que modifica datos exige el token CSRF (excepto iniciar sesión).
    if ($method !== 'GET' && !($res === 'auth' && $action === 'login')) Auth::checkCsrf();

    $movement = ['entradas', 'produccion', 'cargas', 'ventas'];
    $key = "$method $res" . ($action ? "/$action" : '') . ($id !== null ? ' :id' : '');

    $out = match (true) {
        $key === 'GET auth/me'       => AuthController::me(),
        $key === 'POST auth/login'   => AuthController::login(),
        $key === 'POST auth/logout'  => AuthController::logout(),
        $key === 'POST auth/password'=> AuthController::password(),

        $key === 'GET catalogos'     => CatalogController::index(),
        $key === 'GET mi'            => CatalogController::myDay(),

        in_array($res, $movement, true) && $key === "GET $res"         => MovementsController::list($res),
        in_array($res, $movement, true) && $key === "POST $res"        => MovementsController::create($res),
        in_array($res, $movement, true) && $key === "PUT $res :id"     => MovementsController::update($res, $id),
        in_array($res, $movement, true) && $key === "DELETE $res :id"  => MovementsController::delete($res, $id),

        $key === 'GET usuarios'                 => UsersController::list(),
        $key === 'POST usuarios'                => UsersController::create(),
        $key === 'PUT usuarios :id'             => UsersController::update($id),
        $key === 'DELETE usuarios :id'          => UsersController::delete($id),
        $key === 'POST usuarios/password :id'   => UsersController::resetPassword($id),

        $key === 'GET vendedores'          => SellersController::list(),
        $key === 'POST vendedores'         => SellersController::create(),
        $key === 'PUT vendedores :id'      => SellersController::update($id),
        $key === 'DELETE vendedores :id'   => SellersController::delete($id),

        $key === 'GET zonas'          => ZonesController::list(),
        $key === 'POST zonas'         => ZonesController::create(),
        $key === 'PUT zonas :id'      => ZonesController::update($id),

        $key === 'GET camiones'          => TrucksController::list(),
        $key === 'POST camiones'         => TrucksController::create(),
        $key === 'PUT camiones :id'      => TrucksController::update($id),
        $key === 'DELETE camiones :id'   => TrucksController::delete($id),

        $key === 'GET costos'   => CostsController::get(),
        $key === 'PUT costos'   => CostsController::save(),

        $key === 'GET panel'           => ReportsController::dashboard(),
        $key === 'GET reportes'        => ReportsController::sales(),
        $key === 'GET reportes/excel'  => ReportsController::excel(),

        $key === 'GET respaldo'          => BackupController::export(),
        $key === 'GET respaldo/csv'      => BackupController::csv(),
        $key === 'POST respaldo/importar'=> BackupController::import(),
        $key === 'POST respaldo/borrar'  => BackupController::wipe(),

        default => throw new HttpError(404, 'Ruta no encontrada.'),
    };
    json_out($out);
} catch (HttpError $e) {
    json_out(['ok' => false, 'error' => $e->getMessage()] + $e->extra, $e->getCode());
} catch (PDOException $e) {
    error_log('[AguaControl] ' . $e->getMessage());
    $msg = str_contains($e->getMessage(), 'UNIQUE') || str_contains($e->getMessage(), 'Duplicate')
        ? 'Ya existe un registro con esos datos.'
        : 'Error de base de datos. Revisa la configuración en config/config.php.';
    json_out(['ok' => false, 'error' => $msg], 500);
} catch (Throwable $e) {
    error_log('[AguaControl] ' . $e);
    json_out(['ok' => false, 'error' => 'Error interno del servidor.'], 500);
}
