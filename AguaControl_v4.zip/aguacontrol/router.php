<?php
// Solo para pruebas con el servidor integrado:  php -S localhost:8000 router.php
// Imita las reglas .htaccess bloqueando las carpetas internas.
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (preg_match('#^/(config|src|data|database)(/|$)|\.(sqlite|sql|md)$#', $path)) { http_response_code(403); exit('Prohibido'); }
return false;
