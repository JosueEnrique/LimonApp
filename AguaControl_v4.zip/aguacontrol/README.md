# AguaControl 3.0

Sistema de inventario, producción, carga de camiones y ventas para una purificadora de agua.
PHP 8 + base de datos (SQLite por defecto, o MySQL de XAMPP) + HTML/CSS/JS separados, sin frameworks.

## Cómo arrancarlo

### Opción A — XAMPP (recomendada)
1. Copia la carpeta `aguacontrol` dentro de `C:\xampp\htdocs\`.
2. Enciende **Apache** en el panel de XAMPP.
3. Abre `http://localhost/aguacontrol/`.

Con eso basta: la base de datos SQLite se crea sola en `data/aguacontrol.sqlite` la primera vez,
con los productos, camiones, costos y usuarios iniciales.

### Opción B — Usar MySQL de XAMPP en lugar de SQLite
1. Enciende **Apache** y **MySQL**.
2. En phpMyAdmin → pestaña **SQL**, ejecuta `database/schema.mysql.sql`.
3. En `config/config.php` cambia `'driver' => 'sqlite'` por `'driver' => 'mysql'` (y la contraseña si tu root tiene una).
4. Desde la carpeta del proyecto ejecuta una vez: `C:\xampp\php\php.exe database\install.php`.

### Opción C — Sin XAMPP (servidor integrado de PHP)
```
cd aguacontrol
php -S localhost:8000 router.php
```
y abre `http://localhost:8000`.

> Requisitos: PHP 8.1 o superior con la extensión `pdo_sqlite` (o `pdo_mysql`). XAMPP ya las trae.

## Roles

| Rol | Ve | Puede |
|---|---|---|
| **Administrador** | Todo | Dashboard de ventas y compras, todos los movimientos, vendedores, zonas, camiones, usuarios, costos y respaldos. Puede forzar una venta o carga sin stock (se le pide confirmar). |
| **Contabilidad** | Reportes de ventas | Consultar ventas y compras por periodo, zona y vendedor, y **exportarlas a Excel (.xlsx)**. No modifica nada. |
| **Despacho** (encargado de zona) | Cargar camión, Ventas de la ruta | Solo ve a los vendedores de **su zona** (Planta, Morazán o San Miguel). Les carga producto y registra sus ventas. Corrige solo lo que registró hoy. |
| **Supervisor de producción** | Producción del turno | Una sola persona (reemplaza a las cuentas de operario). Registra toda la producción y ve el registro completo de cada turno (Mañana, Tarde o Noche). El sistema no permite un segundo supervisor activo. |

### Vendedores de ruta
Los vendedores **no entran al sistema**: están en la tabla `vendedores` con su código (V-01, V-02…),
zona y camión. Se administran en **Vendedores y zonas**. Si un vendedor deja de trabajar, se da de baja:
queda inactivo con todas sus ventas, que siguen apareciendo en los reportes.

### Vendedores iniciales
| Código | Vendedor | Zona | Camión |
|---|---|---|---|
| V-01 | Juan | Planta | CAM-01 |
| V-02 | Pedro | Planta | CAM-02 |
| V-03 | Luis | San Miguel | CAM-04 |
| V-04 | Julio | San Miguel | CAM-05 |

CAM-03 queda de reserva. En una base ya instalada este reparto se aplica solo una vez al abrir el sistema.

### Zonas
Planta, Morazán y San Miguel vienen creadas. Cada encargado de despacho tiene una zona y solo ve
a los vendedores de ella. Morazán todavía no tiene encargado: créalo en **Usuarios** con rol Despacho y zona Morazán.

## Actualización desde la versión 2
Al abrir la versión 3 con una base de la versión 2, se actualiza sola:
- Antes de cambiar nada guarda una copia en `data/respaldo-antes-de-v3-FECHA.sqlite`.
- Los usuarios con rol vendedor pasan a la tabla de vendedores con su camión y sus ventas. Ya no pueden iniciar sesión.
- "Operario" pasa a "Supervisor de producción" y queda un solo supervisor activo (salvador). Los demás se desactivan y conservan su historial.
- Walner queda en la zona Planta y Ezequiel en San Miguel. Juan y Pedro quedan en Planta con sus camiones.

## Cómo se mueve el inventario

```
Producción (− desperdicio) ──► PLANTA ──carga al vendedor──► CAMIÓN ──venta──► cliente
                                  └──────────── venta directa ────────────► cliente
```

- No se puede cargar más de lo que hay en planta, ni vender más de lo que le queda al vendedor en su camión.
- Cada camión tiene un código único (`CAM-01`, `CAM-02`…) y lo usa un solo vendedor activo.

## Exportación a Excel
En **Reportes de ventas**, el botón *Exportar a Excel* genera un libro con 6 hojas: Resumen, Ventas (detalle completo),
Por vendedor, Por zona, Por producto y Compras. Las fechas son fechas reales y los montos tienen formato de dinero, con totales calculados por fórmula.
No necesita ninguna extensión adicional de PHP.

## Estructura

```
aguacontrol/
├── index.php              HTML de la aplicación (login + estructura)
├── api/index.php          API JSON: todas las rutas pasan por aquí
├── assets/
│   ├── css/               tokens.css (paleta) · base.css (estructura) · components.css
│   └── js/
│       ├── main.js        sesión, menú por rol y navegación
│       ├── api.js         cliente de la API (token CSRF incluido)
│       ├── ui.js          diálogos, tablas, avisos, gráficos, tarjetas de captura
│       ├── utils.js       formato de dinero, fechas, colores de zona, escape de HTML
│       └── views/         una pantalla por archivo
├── assets/fonts/          tipografía Archivo (licencia OFL), alojada localmente
├── assets/img/            logos de Agua El Limón (horizontal, vertical, símbolo y favicon)
├── src/
│   ├── bootstrap.php      carga todo
│   ├── Database.php       conexión PDO y creación automática de SQLite
│   ├── Auth.php           sesiones, login con bloqueo por intentos, CSRF
│   ├── Validator.php      validación de cada parámetro recibido
│   ├── Inventory.php      stock de planta y por camión, costos
│   ├── Xlsx.php           generador de archivos Excel
│   ├── Migrator.php       actualización automática desde la versión 2
│   └── controllers/       un archivo por módulo, con los permisos por rol y zona
├── database/              esquemas SQLite y MySQL, datos iniciales, instalador
├── config/config.php      configuración (motor de base de datos, sesión, seguridad)
└── data/                  aquí vive el archivo SQLite (protegido)
```

## Seguridad incluida
- Contraseñas con **bcrypt** (`password_hash`); nadie puede leerlas.
- Sesión en el servidor (cookie `HttpOnly`, `SameSite=Strict`), se cierra tras 8 h sin actividad.
- Token **CSRF** en cada operación que cambia datos.
- Bloqueo de 10 minutos tras 5 contraseñas incorrectas.
- Permisos verificados en el servidor en cada petición (no solo ocultando botones).
- Consultas preparadas (sin inyección SQL), escape de HTML en la interfaz, CSV protegido contra fórmulas.
- Carpetas `config/`, `src/`, `data/` y `database/` bloqueadas desde el navegador (`.htaccess`).

## Respaldos
**Respaldo y datos** permite descargar un JSON completo, exportar CSV para Excel/Calc
e **importar el JSON del AguaControl HTML anterior** (los datos que tenías en el navegador).
Si usas SQLite, copiar el archivo `data/aguacontrol.sqlite` también es un respaldo completo.
